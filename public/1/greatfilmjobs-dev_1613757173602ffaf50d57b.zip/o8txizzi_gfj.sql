-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 10, 2020 at 03:31 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `o8txizzi_gfj`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrators`
--

CREATE TABLE `administrators` (
  `ADMINID` bigint(20) NOT NULL,
  `email` varchar(80) NOT NULL DEFAULT '',
  `username` varchar(80) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `administrators`
--

INSERT INTO `administrators` (`ADMINID`, `email`, `username`, `password`) VALUES
(1, 'design@madhurebba.com', 'admin', 'a9d402bfcde5792a8b531b3a82669585'),
(2, 'pay@madhurebba.com', 'rmunni', 'a9d402bfcde5792a8b531b3a82669585'),
(3, 'newtest@rebba.net', 'newadmin', 'a9d402bfcde5792a8b531b3a82669585');

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

CREATE TABLE `advertisements` (
  `AID` bigint(30) NOT NULL,
  `description` varchar(200) NOT NULL DEFAULT '',
  `code` text NOT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `advertisements`
--

INSERT INTO `advertisements` (`AID`, `description`, `code`, `active`) VALUES
(1, '468 x 60 pixels', '<div style=\"width:468px; height:60px; border:1px solid #DFDFDF;\" align=\"center\"><br/>Insert Your<br/>Advertisement Here</div>', '0'),
(2, '120 x 728 pixels', '<div style=\"width:120px; height:728px; border:1px solid #DFDFDF;\" align=\"center\"><br/><br/>Insert Your Advertisement Here</div>', '0'),
(3, '600 x 30 pixels', '<div style=\"width:600px; height:30px; border:1px solid #DFDFDF;\" align=\"center\"><div style=\"padding-top: 5px\">Insert Your Advertisement Here</div></div>', '0'),
(4, '300 x 300 pixels', '<div style=\"width:350px; height:300px; border: 1px solid #068DBB; background-color: #049bcf; color: #fff;\" align=\"center\"><br /><br /><br /><br /><br />Insert Your Advertisement Here</div>', '0'),
(5, '218 x 881 pixels', '<div style=\"width:218px; height:881px; border: 1px solid #222222; background-color: #111111; color: #fff;\" align=\"center\"><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />Insert Your<br />Advertisement Here</div>', '0');

-- --------------------------------------------------------

--
-- Table structure for table `archive`
--

CREATE TABLE `archive` (
  `ID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `AID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bans_ips`
--

CREATE TABLE `bans_ips` (
  `ip` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bans_words`
--

CREATE TABLE `bans_words` (
  `word` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bookmarks`
--

CREATE TABLE `bookmarks` (
  `BID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `PID` bigint(20) NOT NULL DEFAULT '0',
  `time_added` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `CATID` bigint(20) NOT NULL,
  `name` varchar(120) NOT NULL DEFAULT '',
  `seo` varchar(200) NOT NULL,
  `parent` bigint(20) NOT NULL DEFAULT '0',
  `details` text NOT NULL,
  `mtitle` text NOT NULL,
  `mdesc` text NOT NULL,
  `mtags` text NOT NULL,
  `scriptolution_catimage` varchar(40) NOT NULL DEFAULT 'scriptolution_default_category.jpg',
  `scriptolution_featuredcat` int(1) NOT NULL DEFAULT '0',
  `scriptolution_cattag1` varchar(50) NOT NULL DEFAULT 'default',
  `scriptolution_cattag2` varchar(50) NOT NULL DEFAULT 'category',
  `scriptolution_cattag3` varchar(50) NOT NULL DEFAULT 'tags',
  `scriptolution_bigimage` varchar(40) NOT NULL DEFAULT 'scriptolution_default_bigimage.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `scriptolution_catimage`, `scriptolution_featuredcat`, `scriptolution_cattag1`, `scriptolution_cattag2`, `scriptolution_cattag3`, `scriptolution_bigimage`) VALUES
(1, 'Others', 'all-other-services', 0, 'Other Services', 'Other Services', 'Other Services', 'Live WebCam Classes ', '1.jpg', 0, 'For Everyone', '', '', 'scriptolution_default_bigimage.jpg'),
(2, 'Graphics &amp; Design', 'Graphics-Design', 0, 'Graphics &amp; Design', 'Graphics &amp; Design', 'Graphics &amp; Design', 'Logo Illustrations Cartoons Flyers Posters Web Mobile Photoshop 3D &amp; 2D Models T-Shirts Invitations', '2.jpg', 1, 'Logo', 'Posters', '3D &amp; 2D Models', 'big-2.jpg'),
(3, 'Special Effects', 'Film-Shooting-Special-Effects', 30, 'Film Shooting Special Effects', 'Film Shooting Special Effects', 'Film Shooting Special Effects', 'Film Shooting Special Effects', '3.jpg', 0, 'default', 'category', 'tags', 'big-3.jpg'),
(4, 'Dummy Props', 'Fake-Props-for-Film-Shooting', 30, 'Fake Props for Film Shooting', 'Fake Props for Film Shooting', 'Fake Props for Film Shooting', 'Fake Props for Film Shooting', '4.jpg', 0, 'default', 'category', 'tags', 'big-4.jpg'),
(5, 'Props', 'Properties-for-film-shooting', 30, 'Properties for film shooting', 'Properties for film shooting', 'Properties for film shooting', 'Properties for film shooting', '5.jpg', 0, 'default', 'category', 'tags', 'big-5.jpg'),
(6, 'Sets', 'Event-Film-and-TV-Set-Elements', 30, 'Event Film and TV Set Elements', 'Event Film and TV Set Elements', 'Event Film and TV Set Elements', 'Event Film and TV Set Elements', '6.jpg', 0, 'default', 'category', 'tags', 'big-6.jpg'),
(7, 'Costumes', 'Costumes', 30, 'Costumes', 'Costumes', 'Costumes', 'Costumes', '7.jpg', 0, 'default', 'category', 'tags', 'big-7.jpg'),
(8, 'Makeup', 'Makeup', 30, 'Makeup', 'Makeup', 'Makeup', 'Makeup', '8.jpg', 0, 'default', 'category', 'tags', 'big-8.jpg'),
(9, 'Lights', 'Lights', 39, 'Lights', 'Lights', 'Lights', 'Lights', 'scriptolution_default_category.jpg', 0, 'default', 'category', 'tags', 'scriptolution_default_bigimage.jpg'),
(10, 'Cameras', 'Cameras', 39, 'Cameras', 'Cameras', 'Cameras', 'Cameras', 'scriptolution_default_category.jpg', 0, 'default', 'category', 'tags', 'scriptolution_default_bigimage.jpg'),
(11, 'Vehicles', 'Vehicles', 30, 'Vehicles', 'Vehicles', 'Vehicles', 'Vehicles', 'scriptolution_default_category.jpg', 0, 'default', 'category', 'tags', 'scriptolution_default_bigimage.jpg'),
(12, 'Ambiance Actors', 'Living-crowd', 42, 'Living', 'Living', 'Living', 'Living', '12.jpg', 0, 'default', 'category', 'tags', 'big-12.jpg'),
(28, 'Legal Consulting', 'Legal-Consulting', 62, 'Legal Services like agreements opinions advises by Lawyers, advocates etc.,', 'Legal Consulting', 'Legal Services like agreements opinions advises by Lawyers, advocates etc.,', 'Legal Services agreements opinions advises Lawyers, advocates', '28.jpg', 0, 'Legal Services', '', '', 'scriptolution_default_bigimage.jpg'),
(29, 'Locations', 'Film-Shooting-Locations', 30, 'Film Shooting Locations', 'Film Shooting Locations', 'Film Shooting Locations', 'Film Shooting Locations', '29.jpg', 1, 'Film Shooting', 'ready', 'Global Locations', 'big-29.jpg'),
(30, 'Art Direction', 'ArtDirection', 0, 'Art Direction and Production Design Services', 'Art Direction and Production Design Services', 'Art Direction and Production Design Services', 'Art Direction 	Storyboard Artists 	Props 	Dummy Props 	Special Effects 	Locations 	Vehicles 	SET DESIGN 	Animals 	Animatronics  Puppets 	Dummies 	Costumes  Rental / Sale 	FASHION DESIGNERS 	Arts &amp; Crafts 	Handmade Jewellery 	Makeup 	Styling &amp; Beauty', '30.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(31, 'Storyboarding', 'Storyboarding', 30, 'Storyboarding Storyboard Artists', 'Storyboard Artists', 'Storyboarding', 'Storyboarding Storyboard Artists', '31.jpg', 1, 'Storyboards', 'shooting', 'pre-visualizing', 'big-31.jpg'),
(32, 'Animatronics  Puppets', 'AnimatronicsPuppets', 30, 'Animatronics  Puppets', 'Animatronics  Puppets', 'Animatronics  Puppets', 'Animatronics  Puppets', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(33, 'Costumes  Rental / Sale', 'CostumesRental-Sale', 30, 'Costumes  Rental / Sale', 'Costumes  Rental / Sale', 'Costumes  Rental / Sale', 'Costumes  Rental / Sale', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(34, 'Fashion Designers', 'FashionDesigners', 30, 'Fashion Designers', 'Fashion Designers', 'Fashion Designers', 'Fashion Designers', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(35, 'Arts &amp; Crafts', 'ArtsCrafts', 30, 'Arts &amp; Crafts', 'Arts &amp; Crafts', 'Arts &amp; Crafts', 'Arts &amp; Crafts', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(36, 'Styling &amp; Beauty', 'StylingBeauty', 30, 'Styling &amp; Beauty', 'Styling &amp; Beauty', 'Styling &amp; Beauty', 'Styling &amp; Beauty', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(37, 'Handmade Jewellery', 'HandmadeJewellery', 30, 'Handmade Jewellery', 'Handmade Jewellery', 'Handmade Jewellery', 'Handmade Jewellery', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(38, 'Animals', 'Animals', 30, 'Animals', 'Animals', 'Animals', 'Animals', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(39, 'Equipment', 'Equipment', 0, 'Equipment', 'Equipment', 'Equipment', 'Equipment', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(40, 'Cranes', 'Cranes', 39, 'Cranes', 'Cranes', 'Cranes', 'Cranes', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(41, 'Audio', 'Audio', 39, 'Audio', 'Audio', 'Audio', 'Audio', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(42, 'Artistes / Models', 'Artistes-Models', 0, 'Artistes / Models', 'Artistes / Models', 'Artistes / Models', 'Artistes / Models', '42.jpg', 0, 'Actors', 'Juniors', 'Dancers', 'big-42.jpg'),
(43, 'Male', 'Male', 42, 'Male', 'Male', 'Male', 'Male', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(44, 'Female', 'Female', 42, 'Female', 'Female', 'Female', 'Female', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(45, 'Male Child', 'MaleChild', 42, 'Male Child', 'Male Child', 'Male Child', 'Male Child', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(46, 'Female Child', 'FemaleChild', 42, 'Female Child', 'Female Child', 'Female Child', 'Female Child', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(47, 'Comedians', 'Comedians', 42, 'Comedians', 'Comedians', 'Comedians', 'Comedians', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(48, 'Anchors', 'Anchors', 42, 'Anchors', 'Anchors', 'Anchors', 'Anchors', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(49, 'Junior Artistes', 'JuniorArtistes', 42, 'Junior Artistes', 'Junior Artistes', 'Junior Artistes', 'Junior Artistes', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(50, 'Stunt People', 'StuntPeople', 42, 'Stunt People', 'Stunt People', 'Stunt People', 'Stunt People', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(51, 'Dancers', 'Dancers', 42, 'Dancers', 'Dancers', 'Dancers', 'Dancers', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(52, 'Choreographers', 'Choreographers', 42, 'Choreographers', 'Choreographers', 'Choreographers', 'Choreographers', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(53, 'Lifestyle', 'Lifestyle', 0, 'Lifestyle', 'Lifestyle', 'Lifestyle', 'Lifestyle', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-53.jpg'),
(54, 'Relationship Advice', 'RelationshipAdvice', 53, 'Relationship Advice', 'Relationship Advice', 'Relationship Advice', 'Relationship Advice', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-54.jpg'),
(55, 'Diet &amp; Weight Loss', 'DietWeightLoss', 53, 'Diet &amp; Weight Loss', 'Diet &amp; Weight Loss', 'Diet &amp; Weight Loss', 'Diet &amp; Weight Loss', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-55.jpg'),
(56, 'Health &amp; Fitness', 'HealthFitness', 53, 'Health &amp; Fitness', 'Health &amp; Fitness', 'Health &amp; Fitness', 'Health &amp; Fitness', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-56.jpg'),
(57, 'Cooking Recipes', 'CookingRecipes', 53, 'Cooking Recipes', 'Cooking Recipes', 'Cooking Recipes', 'Cooking Recipes', '57.jpg', 0, '', '', '', 'big-57.jpg'),
(59, 'Others - Art Direction', 'OthersinArtDirection', 30, 'Others in Art Direction', 'Others in Art Direction', 'Others in Art Direction', 'Others in Art Direction', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(60, 'Others - Artistes / Models', 'OthersinArtistes-Models', 42, 'Others in Artistes / Models', 'Others in Artistes / Models', 'Others in Artistes / Models', 'Others in Artistes / Models', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(61, 'Other Equipments', 'OtherEquipments', 39, 'Other Equipments', 'Other Equipments', 'Other Equipments', 'Other Equipments', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(62, 'Business', 'Business', 0, 'Business', 'Business', 'Business', 'Business', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(63, 'Virtual Assistants', 'VirtualAssistants', 62, 'Virtual Assistants', 'Virtual Assistants', 'Virtual Assistants', 'Virtual Assistants', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(64, 'Market Research', 'MarketResearch', 62, 'Market Research', 'Market Research', 'Market Research', 'Market Research', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(65, 'Business Plans', 'BusinessPlans', 62, 'Business Plans', 'Business Plans', 'Business Plans', 'Business Plans', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(66, 'Branding Services', 'BrandingServices', 62, 'Branding Services', 'Branding Services', 'Branding Services', 'Branding Services', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(67, 'Financial Consulting', 'FinancialConsulting', 62, 'Financial Consulting', 'Financial Consulting', 'Financial Consulting', 'Financial Consulting', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(68, 'Business Tips', 'BusinessTips', 62, 'Business Tips', 'Business Tips', 'Business Tips', 'Business Tips', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(69, 'Presentations', 'Presentations', 62, 'Presentations', 'Presentations', 'Presentations', 'Presentations', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(70, 'Career Advice', 'CareerAdvice', 62, 'Career Advice', 'Career Advice', 'Career Advice', 'Career Advice', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(71, 'Box Office Reports / Reviews', 'BoxOfficeReports-Reviews', 62, 'Box Office Reports / Reviews', 'Box Office Reports / Reviews', 'Box Office Reports / Reviews', 'Box Office Reports / Reviews', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(72, 'Business - Others', 'BusinessOthers', 62, 'BusinessOthers', 'BusinessOthers', 'BusinessOthers', 'BusinessOthers', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(73, 'Software', 'Programming---Tech', 0, 'Programming &amp; Tech', 'Programming &amp; Tech', 'Programming &amp; Tech', 'Programming &amp; Tech', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(74, 'Promotion', 'Promotion', 0, 'Promotion', 'Promotion', 'Promotion', 'Promotion', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(75, 'Writing &amp; Translation', 'WritingTranslation', 0, 'Writing &amp; Translation', 'Writing &amp; Translation', 'Writing &amp; Translation', 'Writing &amp; Translation', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(76, 'Music &amp; Audio', 'MusicAudio', 0, 'Music &amp; Audio', 'Music &amp; Audio', 'Music &amp; Audio', 'Music &amp; Audio', '76.jpg', 1, 'Singers', 'Voice Over', 'Sound Effects', 'big-76.jpg'),
(77, 'Crew', 'Crew', 0, 'Crew', 'Crew', 'Crew', 'Crew', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(78, 'Animation &amp; Video', 'Cinematography---Animation', 0, 'Cinematography &amp; Animation', 'Cinematography &amp; Animation', 'Cinematography &amp; Animation', 'Cinematography &amp; Animation', '78.jpg', 1, 'Video stocks', 'Editing', 'Logo Animations', 'big-78.jpg'),
(79, 'Whiteboard &amp; Explainer Videos', 'WhiteboardExplainerVideos', 78, 'Whiteboard &amp; Explainer Videos', 'Whiteboard &amp; Explainer Videos', 'Whiteboard &amp; Explainer Videos', 'Whiteboard &amp; Explainer Videos', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(80, 'Intro &amp; Animated Logos', 'IntroAnimatedLogos', 78, 'Intro &amp; Animated Logos', 'Intro &amp; Animated Logos', 'Intro &amp; Animated Logos', 'Intro &amp; Animated Logos', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(81, 'Promotional &amp; Branded Videos', 'PromotionalBrandedVideos', 78, 'Promotional &amp; Branded Videos', 'Promotional &amp; Branded Videos', 'Promotional &amp; Branded Videos', 'Promotional &amp; Branded Videos', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(82, 'Editing &amp; Post Production', 'EditingPostProduction', 78, 'Editing &amp; Post Production', 'Editing &amp; Post Production', 'Editing &amp; Post Production', 'Editing &amp; Post Production', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(83, 'After Effects', 'AfterEffects(templates)', 78, 'After Effects (templates)', 'After Effects (templates)', 'After Effects (templates)', 'After Effects (templates)', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(84, 'Lyrics &amp; Music Videos', 'LyricsMusicVideos', 78, 'Lyrics &amp; Music Videos', 'Lyrics &amp; Music Videos', 'Lyrics &amp; Music Videos', 'Lyrics &amp; Music Videos', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(85, 'Spokespersons &amp; Testimonials', 'SpokespersonsTestimonials', 78, 'Spokespersons &amp; Testimonials', 'Spokespersons &amp; Testimonials', 'Spokespersons &amp; Testimonials', 'Spokespersons &amp; Testimonials', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(86, 'Animated Characters &amp; Modeling', 'AnimatedCharactersModeling', 78, 'Animated Characters &amp; Modeling', 'Animated Characters &amp; Modeling', 'Animated Characters &amp; Modeling', 'Animated Characters &amp; Modeling', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(87, 'Video Greetings', 'VideoGreetings', 78, 'Video Greetings', 'Video Greetings', 'Video Greetings', 'Video Greetings', '87.jpg', 1, 'Happy Birthday', 'Anniversary', 'Valentine', 'big-87.jpg'),
(88, 'Games Developers', 'GamesDevelopers', 78, 'Games Developers', 'Games Developers', 'Games Developers', 'Games Developers', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(89, 'Video Stocks', 'VideoStocks', 78, 'Video Stocks', 'Video Stocks', 'Video Stocks', 'Video Stocks', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(90, 'Audio Stocks', 'AudioStocks', 78, 'Audio Stocks', 'Audio Stocks', 'Audio Stocks', 'Audio Stocks', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(91, 'Others - Video &amp; Animation', 'Others-VideoAnimation', 78, 'Others - Video &amp; Animation', 'Others - Video &amp; Animation', 'Others - Video &amp; Animation', 'Others - Video &amp; Animation', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(92, 'Voice Over', 'VoiceOver', 76, 'Voice Over', 'Voice Over', 'Voice Over', 'Voice Over', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(93, 'Mixing &amp; Mastering', 'MixingMastering', 76, 'Mixing &amp; Mastering', 'Mixing &amp; Mastering', 'Mixing &amp; Mastering', 'Mixing &amp; Mastering', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(94, 'Producers &amp; Composers', 'ProducersComposers', 76, 'Producers &amp; Composers', 'Producers &amp; Composers', 'Producers &amp; Composers', 'Producers &amp; Composers', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(95, 'Singer - Songwriters', 'Singer-Songwriters', 76, 'Singer - Songwriters', 'Singer - Songwriters', 'Singer - Songwriters', 'Singer - Songwriters', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(96, 'Session Musicians &amp; Singers', 'SessionMusiciansSingers', 76, 'Session Musicians &amp; Singers', 'Session Musicians &amp; Singers', 'Session Musicians &amp; Singers', 'Session Musicians &amp; Singers', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(97, 'Jingles &amp; Drops', 'JinglesDrops', 76, 'Jingles &amp; Drops', 'Jingles &amp; Drops', 'Jingles &amp; Drops', 'Jingles &amp; Drops', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(98, 'Sound Effects', 'SoundEffects', 76, 'Sound Effects', 'Sound Effects', 'Sound Effects', 'Sound Effects', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(99, 'Sound Recordist / Sound Assist', 'SoundRecordist-SoundAssist', 76, 'Sound Recordist / Sound Assist', 'Sound Recordist / Sound Assist', 'Sound Recordist / Sound Assist', 'Sound Recordist / Sound Assist', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(100, 'Music Direction', 'MusicDirection', 76, 'Music Direction', 'Music Direction', 'Music Direction', 'Music Direction', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(101, 'Others - Music &amp; Audio', 'Others-MusicAudio', 76, 'Others - Music &amp; Audio', 'Others - Music &amp; Audio', 'Others - Music &amp; Audio', 'Others - Music &amp; Audio', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(102, 'Logo Design', 'LogoDesign', 2, 'Logo Design', 'Logo Design', 'Logo Design', 'Logo Design', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-102.jpg'),
(103, 'Business Cards &amp; Stationery', 'BusinessCardsStationery', 2, 'Business Cards &amp; Stationery', 'Business Cards &amp; Stationery', 'Business Cards &amp; Stationery', 'Business Cards &amp; Stationery', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-103.jpg'),
(104, 'Illustrations', 'Illustrations', 2, 'Illustrations', 'Illustrations', 'Illustrations', 'Illustrations', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-104.jpg'),
(105, 'Cartoons &amp; Caricatures', 'CartoonsCaricatures', 2, 'Cartoons &amp; Caricatures', 'Cartoons &amp; Caricatures', 'Cartoons &amp; Caricatures', 'Cartoons &amp; Caricatures', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-105.jpg'),
(106, 'Flyers &amp; Posters', 'FlyersPosters', 2, 'Flyers &amp; Posters', 'Flyers &amp; Posters', 'Flyers &amp; Posters', 'Flyers &amp; Posters', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-106.jpg'),
(107, 'Book Covers &amp; Packaging', 'BookCoversPackaging', 2, 'Book Covers &amp; Packaging', 'Book Covers &amp; Packaging', 'Book Covers &amp; Packaging', 'Book Covers &amp; Packaging', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-107.jpg'),
(108, 'Web &amp; Mobile Design', 'WebMobileDesign', 2, 'Web &amp; Mobile Design', 'Web &amp; Mobile Design', 'Web &amp; Mobile Design', 'Web &amp; Mobile Design', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-108.jpg'),
(109, 'Social Media Design', 'SocialMediaDesign', 2, 'Social Media Design', 'Social Media Design', 'Social Media Design', 'Social Media Design', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-109.jpg'),
(110, 'Banner Ads', 'BannerAds', 2, 'Banner Ads', 'Banner Ads', 'Banner Ads', 'Banner Ads', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-110.jpg'),
(111, 'Photoshop Editing', 'PhotoshopEditing', 2, 'Photoshop Editing', 'Photoshop Editing', 'Photoshop Editing', 'Photoshop Editing', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-111.jpg'),
(112, '3D &amp; 2D Models', '3D2DModels', 2, '3D &amp; 2D Models', '3D &amp; 2D Models', '3D &amp; 2D Models', '3D &amp; 2D Models', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-112.jpg'),
(113, 'T-Shirts', 'T-Shirts', 2, 'T-Shirts', 'T-Shirts', 'T-Shirts', 'T-Shirts', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-113.jpg'),
(114, 'Presentation Design', 'PresentationDesign', 2, 'Presentation Design', 'Presentation Design', 'Presentation Design', 'Presentation Design', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-114.jpg'),
(115, 'Infographics', 'Infographics', 2, 'Infographics', 'Infographics', 'Infographics', 'Infographics', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-115.jpg'),
(116, 'Vector Tracing', 'VectorTracing', 2, 'Vector Tracing', 'Vector Tracing', 'Vector Tracing', 'Vector Tracing', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-116.jpg'),
(117, 'Invitations', 'Invitations', 2, 'Invitations', 'Invitations', 'Invitations', 'Invitations', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-117.jpg'),
(118, 'Others - Graphics &amp; Design', 'Others-GraphicsDesign', 2, 'Others - Graphics &amp; Design', 'Others - Graphics &amp; Design', 'Others - Graphics &amp; Design', 'Others - Graphics &amp; Design', 'scriptolution_default_category.jpg', 0, '', '', '', 'big-118.jpg'),
(119, 'Script Writing', 'ScriptWriting', 75, 'Script Writing', 'Script Writing', 'Script Writing', 'Script Writing', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(120, 'Song Writing / Lyricist', 'SongWriting-Lyricist', 75, 'Song Writing / Lyricist', 'Song Writing / Lyricist', 'Song Writing / Lyricist', 'Song Writing / Lyricist', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(121, 'Resumes &amp; Cover Letters', 'ResumesCoverLetters', 75, 'Resumes &amp; Cover Letters', 'Resumes &amp; Cover Letters', 'Resumes &amp; Cover Letters', 'Resumes &amp; Cover Letters', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(122, 'Proofreading &amp; Editing', 'ProofreadingEditing', 75, 'Proofreading &amp; Editing', 'Proofreading &amp; Editing', 'Proofreading &amp; Editing', 'Proofreading &amp; Editing', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(123, 'Translation', 'Translation', 75, 'Translation', 'Translation', 'Translation', 'Translation', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(124, 'Creative Writing', 'CreativeWriting', 75, 'Creative Writing', 'Creative Writing', 'Creative Writing', 'Creative Writing', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(125, 'Business Copywriting', 'BusinessCopywriting', 75, 'Business Copywriting', 'Business Copywriting', 'Business Copywriting', 'Business Copywriting', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(126, 'Research &amp; Summaries', 'ResearchSummaries', 75, 'Research &amp; Summaries', 'Research &amp; Summaries', 'Research &amp; Summaries', 'Research &amp; Summaries', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(127, 'Articles &amp; Blog Posts', 'ArticlesBlogPosts', 75, 'Articles &amp; Blog Posts', 'Articles &amp; Blog Posts', 'Articles &amp; Blog Posts', 'Articles &amp; Blog Posts', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(128, 'Press Releases', 'PressReleases', 75, 'Press Releases', 'Press Releases', 'Press Releases', 'Press Releases', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(129, 'Transcription', 'Transcription', 75, 'Transcription', 'Transcription', 'Transcription', 'Transcription', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(130, 'Legal writing', 'Legalwriting', 75, 'Legal writing', 'Legal writing', 'Legal writing', 'Legal writing', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(131, 'Others - Writing &amp; Translation', 'Others-WritingTranslation', 75, 'Others - Writing &amp; Translation', 'Others - Writing &amp; Translation', 'Others - Writing &amp; Translation', 'Others - Writing &amp; Translation', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(132, 'WordPress', 'WordPress', 73, 'WordPress', 'WordPress', 'WordPress', 'WordPress', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(133, 'Website Builders &amp; CMS', 'WebsiteBuildersCMS', 73, 'Website Builders &amp; CMS', 'Website Builders &amp; CMS', 'Website Builders &amp; CMS', 'Website Builders &amp; CMS', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(134, 'Web Programming', 'WebProgramming', 73, 'Web Programming', 'Web Programming', 'Web Programming', 'Web Programming', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(135, 'Ecommerce', 'Ecommerce', 73, 'Ecommerce', 'Ecommerce', 'Ecommerce', 'Ecommerce', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(136, 'Mobile Apps &amp; Web', 'MobileAppsWeb', 73, 'Mobile Apps &amp; Web', 'Mobile Apps &amp; Web', 'Mobile Apps &amp; Web', 'Mobile Apps &amp; Web', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(137, 'Desktop Applications', 'Desktopapplications', 73, 'Desktop applications', 'Desktop applications', 'Desktop applications', 'Desktop applications', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(138, 'Support &amp; IT', 'SupportIT', 73, 'Support &amp; IT', 'Support &amp; IT', 'Support &amp; IT', 'Support &amp; IT', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(139, 'Data Analysis &amp; Reports', 'DataAnalysisReports', 73, 'Data Analysis &amp; Reports', 'Data Analysis &amp; Reports', 'Data Analysis &amp; Reports', 'Data Analysis &amp; Reports', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(140, 'Convert Files', 'ConvertFiles', 73, 'Convert Files', 'Convert Files', 'Convert Files', 'Convert Files', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(141, 'Databases', 'Databases', 73, 'Databases', 'Databases', 'Databases', 'Databases', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(142, 'User Testing', 'UserTesting', 73, 'User Testing', 'User Testing', 'User Testing', 'User Testing', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(143, 'QA', 'QA', 73, 'QA', 'QA', 'QA', 'QA', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(144, 'Gaming', 'Gaming', 73, 'Gaming', 'Gaming', 'Gaming', 'Gaming', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(145, 'Others - Programming &amp; Tech', 'Others-ProgrammingTech', 73, 'Others - Programming &amp; Tech', 'Others - Programming &amp; Tech', 'Others - Programming &amp; Tech', 'Others - Programming &amp; Tech', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(146, 'InFilm Branding', 'InFilmBranding', 74, 'InFilm Branding', 'InFilm Branding', 'InFilm Branding', 'InFilm Branding', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(147, 'Social Media Marketing', 'SocialMediaMarketing', 74, 'Social Media Marketing', 'Social Media Marketing', 'Social Media Marketing', 'Social Media Marketing', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(148, 'SEO', 'SEO', 74, 'SEO', 'SEO', 'SEO', 'SEO', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(149, 'Web Traffic', 'WebTraffic', 74, 'Web Traffic', 'Web Traffic', 'Web Traffic', 'Web Traffic', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(150, 'Content Marketing', 'ContentMarketing', 74, 'Content Marketing', 'Content Marketing', 'Content Marketing', 'Content Marketing', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(151, 'Video Advertising', 'VideoAdvertising', 74, 'Video Advertising', 'Video Advertising', 'Video Advertising', 'Video Advertising', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(152, 'Email Marketing', 'EmailMarketing', 74, 'Email Marketing', 'Email Marketing', 'Email Marketing', 'Email Marketing', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(153, 'SEM', 'SEM', 74, 'SEM', 'SEM', 'SEM', 'SEM', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(154, 'Marketing Strategy', 'MarketingStrategy', 74, 'Marketing Strategy', 'Marketing Strategy', 'Marketing Strategy', 'Marketing Strategy', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(155, 'Web Analytics', 'WebAnalytics', 74, 'Web Analytics', 'Web Analytics', 'Web Analytics', 'Web Analytics', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(156, 'Influencer Marketing', 'InfluencerMarketing', 74, 'Influencer Marketing', 'Influencer Marketing', 'Influencer Marketing', 'Influencer Marketing', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(157, 'Local Listings', 'LocalListings', 74, 'Local Listings', 'Local Listings', 'Local Listings', 'Local Listings', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(158, 'Domain Research', 'DomainResearch', 74, 'Domain Research', 'Domain Research', 'Domain Research', 'Domain Research', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(159, 'Mobile Advertising', 'MobileAdvertising', 74, 'Mobile Advertising', 'Mobile Advertising', 'Mobile Advertising', 'Mobile Advertising', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(160, 'Music Promotion', 'MusicPromotion', 74, 'Music Promotion', 'Music Promotion', 'Music Promotion', 'Music Promotion', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(161, 'Radio Advertising', 'RadioAdvertising', 74, 'Radio Advertising', 'Radio Advertising', 'Radio Advertising', 'Radio Advertising', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(162, 'Banner Advertising', 'BannerAdvertising', 74, 'Banner Advertising', 'Banner Advertising', 'Banner Advertising', 'Banner Advertising', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(163, 'Outdoor Advertising', 'OutdoorAdvertising', 74, 'Outdoor Advertising', 'Outdoor Advertising', 'Outdoor Advertising', 'Outdoor Advertising', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(164, 'Flyers &amp; Handouts', 'FlyersHandouts', 74, 'Flyers &amp; Handouts', 'Flyers &amp; Handouts', 'Flyers &amp; Handouts', 'Flyers &amp; Handouts', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(165, 'Hold Your Sign', 'HoldYourSign', 74, 'Hold Your Sign', 'Hold Your Sign', 'Hold Your Sign', 'Hold Your Sign', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(166, 'Human Billboards', 'HumanBillboards', 74, 'Human Billboards', 'Human Billboards', 'Human Billboards', 'Human Billboards', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(167, 'Pet Models', 'PetModels', 74, 'Pet Models', 'Pet Models', 'Pet Models', 'Pet Models', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(168, 'Others - Promotion', 'Others-Promotion', 74, 'Others - Promotion', 'Others - Promotion', 'Others - Promotion', 'Others - Promotion', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(169, 'Art Director', 'ArtDirectors', 77, 'Art Directors', 'Art Directors', 'Art Directors', 'Art Directors', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(170, 'Electrician', 'Electricians', 77, 'Electricians', 'Electricians', 'Electricians', 'Electricians', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(171, 'Director', 'Director', 77, 'Director', 'Director', 'Director', 'Director', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(172, 'Producer', 'Producer', 77, 'Producer', 'Producer', 'Producer', 'Producer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(173, 'Cinematographer', 'Cinematographer', 77, 'Cinematographer', 'Cinematographer', 'Cinematographer', 'Cinematographer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(174, 'Asst Director', 'AsstDirector', 77, 'Asst Director', 'Asst Director', 'Asst Director', 'Asst Director', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(175, 'Camera Operator', 'CameraOperator', 77, 'Camera Operator', 'Camera Operator', 'Camera Operator', 'Camera Operator', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(176, 'Unit Production Manager', 'UnitProductionManager', 77, 'Unit Production Manager', 'Unit Production Manager', 'Unit Production Manager', 'Unit Production Manager', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(177, 'Post-Production', 'Post-Production', 77, 'Post-Production', 'Post-Production', 'Post-Production', 'Post-Production', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(178, 'Sound Mixer', 'SoundMixer', 77, 'Sound Mixer', 'Sound Mixer', 'Sound Mixer', 'Sound Mixer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(179, 'Sound', 'Sound', 77, 'Sound', 'Sound', 'Sound', 'Sound', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(180, 'Production Assistant', 'ProductionAssistant', 77, 'Production Assistant', 'Production Assistant', 'Production Assistant', 'Production Assistant', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(181, 'Line Producer', 'LineProducer', 77, 'Line Producer', 'Line Producer', 'Line Producer', 'Line Producer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(182, 'Location Manager', 'LocationManager', 77, 'Location Manager', 'Location Manager', 'Location Manager', 'Location Manager', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(183, 'Visual Effects', 'VisualEffects', 77, 'Visual Effects', 'Visual Effects', 'Visual Effects', 'Visual Effects', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(184, 'Costume Designer', 'CostumeDesigner', 77, 'Costume Designer', 'Costume Designer', 'Costume Designer', 'Costume Designer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(185, 'Make-up Artist', 'Make-upartist', 77, 'Make-up artist', 'Make-up artist', 'Make-up artist', 'Make-up artist', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(186, 'TV Writer', 'TVWriter', 77, 'TV Writer', 'TV Writer', 'TV Writer', 'TV Writer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(187, 'Set Decorator', 'SetDecorator', 77, 'Set Decorator', 'Set Decorator', 'Set Decorator', 'Set Decorator', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(188, 'Script Supervisor', 'Scriptsupervisor', 77, 'Script supervisor', 'Script supervisor', 'Script supervisor', 'Script supervisor', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(189, 'Boom Operator', 'BoomOperator', 77, 'Boom Operator', 'Boom Operator', 'Boom Operator', 'Boom Operator', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(190, 'Best Boy', 'BestBoy', 77, 'Best Boy', 'Best Boy', 'Best Boy', 'Best Boy', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(191, 'Lighting Technician', 'Lightingtechnician', 77, 'Lighting technician', 'Lighting technician', 'Lighting technician', 'Lighting technician', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(192, 'Production Coordinator', 'ProductionCoordinator', 77, 'Production Coordinator', 'Production Coordinator', 'Production Coordinator', 'Production Coordinator', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(193, 'Technician', 'Technician', 77, 'Technician', 'Technician', 'Technician', 'Technician', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(194, 'Artist', 'Artist', 77, 'Artist', 'Artist', 'Artist', 'Artist', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(195, 'Stunt Performer', 'StuntPerformer', 77, 'Stunt Performer', 'Stunt Performer', 'Stunt Performer', 'Stunt Performer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(196, 'Hair Dresser', 'HairDresser', 77, 'Hair Dresser', 'Hair Dresser', 'Hair Dresser', 'Hair Dresser', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(197, 'Executive Producer', 'ExecutiveProducer', 77, 'Executive Producer', 'Executive Producer', 'Executive Producer', 'Executive Producer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(198, 'Audio Engineer', 'AudioEngineer', 77, 'Audio Engineer', 'Audio Engineer', 'Audio Engineer', 'Audio Engineer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(199, 'Choreopgrapher', 'Choreopgrapher', 77, 'Choreopgrapher', 'Choreopgrapher', 'Choreopgrapher', 'Choreopgrapher', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(200, 'Composer', 'Composer', 77, 'Composer', 'Composer', 'Composer', 'Composer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(201, 'Designer', 'Designer', 77, 'Designer', 'Designer', 'Designer', 'Designer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(202, 'Location Scouter', 'LocationScouter', 77, 'Location Scouter', 'Location Scouter', 'Location Scouter', 'Location Scouter', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(203, 'Countinuity', 'Countinuity', 77, 'Countinuity', 'Countinuity', 'Countinuity', 'Countinuity', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(204, 'Videographer', 'Videographer', 77, 'Videographer', 'Videographer', 'Videographer', 'Videographer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(205, 'Special Effects Supervisor', 'SpecialEffectsSupervisor', 77, 'Special Effects Supervisor', 'Special Effects Supervisor', 'Special Effects Supervisor', 'Special Effects Supervisor', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(206, 'Stunt Coordinator', 'StuntCoordinator', 77, 'Stunt Coordinator', 'Stunt Coordinator', 'Stunt Coordinator', 'Stunt Coordinator', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(207, 'Utility Sound Technician', 'UtilitySoundTechnician', 77, 'Utility Sound Technician', 'Utility Sound Technician', 'Utility Sound Technician', 'Utility Sound Technician', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(208, 'Sound Editor', 'SoundEditor', 77, 'Sound Editor', 'Sound Editor', 'Sound Editor', 'Sound Editor', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(209, 'Visual Effects Supervisor', 'VisualEffectsSupervisor', 77, 'Visual Effects Supervisor', 'Visual Effects Supervisor', 'Visual Effects Supervisor', 'Visual Effects Supervisor', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(210, 'Lighting Designer', 'LightingDesigner', 77, 'Lighting Designer', 'Lighting Designer', 'Lighting Designer', 'Lighting Designer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(211, 'Helpers', 'Helpers', 77, 'Helpers', 'Helpers', 'Helpers', 'Helpers', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(212, 'Outdoor Unit Technicians', 'OutdoorUnitTechnicians', 77, 'Outdoor Unit Technicians', 'Outdoor Unit Technicians', 'Outdoor Unit Technicians', 'Outdoor Unit Technicians', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(213, 'Generator Operator', 'GeneratorOperator', 77, 'Generator Operator', 'Generator Operator', 'Generator Operator', 'Generator Operator', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(214, 'Drivers', 'Drivers', 77, 'Drivers', 'Drivers', 'Drivers', 'Drivers', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(215, 'Grip', 'Grip', 77, 'Grip', 'Grip', 'Grip', 'Grip', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(216, 'Gaffer', 'Gaffer', 77, 'Gaffer', 'Gaffer', 'Gaffer', 'Gaffer', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(217, 'Focus Puller', 'Focuspuller', 77, 'Focus puller', 'Focus puller', 'Focus puller', 'Focus puller', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(218, 'Key Grip', 'KeyGrip', 77, 'Key Grip', 'Key Grip', 'Key Grip', 'Key Grip', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg'),
(219, 'Dolly Grip', 'DollyGrip', 77, 'Dolly Grip', 'Dolly Grip', 'Dolly Grip', 'Dolly Grip', 'scriptolution_default_category.jpg', 0, '', '', '', 'scriptolution_default_bigimage.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `setting` varchar(60) NOT NULL DEFAULT '',
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`setting`, `value`) VALUES
('site_email', 'design@madhurebba.com'),
('site_name', 'GreatFilmJobs.com'),
('max_syndicate_results', '25'),
('maximum_results', '1000000'),
('emailsender', 'Admin'),
('max_suggest', '14'),
('items_per_page', '16'),
('site_slogan', 'GreatFilmJobs.com: Buy. Sell. Have fun!'),
('approve_stories', '1'),
('metadescription', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun!'),
('metakeywords', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun! Film Jobs Great Micro Jobs\r\nGig Extra Gig Video Greeting Props Director Movie audio music\r\nAnimation &amp; Video\r\nAfter Effects\r\nAnimated Characters &amp; Modeling\r\nAudio Stocks\r\nEditing &amp; Post Production\r\nGames Developers\r\nIntro &amp; Animated Logos\r\nLyrics &amp; Music Videos\r\nOthers - Video &amp; Animation\r\nPromotional &amp; Branded Videos\r\nSpokespersons &amp; Testimonials\r\nVideo Greetings\r\nVideo Stocks\r\nWhiteboard &amp; Explainer Videos\r\nArt Direction\r\nAnimals\r\nAnimatronics Puppets\r\nArts &amp; Crafts\r\nCostumes\r\nCostumes Rental / Sale\r\nDummy Props\r\nFashion Designers\r\nHandmade Jewellery\r\nLocations\r\nMakeup\r\nOthers - Art Direction\r\nProps\r\nSets\r\nSpecial Effects\r\nStoryboarding\r\nStyling &amp; Beauty\r\nVehicles\r\nArtistes / Models\r\nAnchors\r\nChoreographers\r\nComedians\r\nCrowd\r\nDancers\r\nFemale\r\nFemale Child\r\nJunior Artistes\r\nMale\r\nMale Child\r\nOthers - Artistes / Models\r\nStunt People\r\nBusiness\r\nBox Office Reports / Reviews\r\nBranding Services\r\nBusiness - Others\r\nBusiness Plans\r\nBusiness Tips\r\nCareer Advice\r\nFinancial Consulting\r\nLegal Consulting\r\nMarket Research\r\nPresentations\r\nVirtual Assistants\r\nCrew\r\nArt Director\r\nArtist\r\nAsst Director\r\nAudio Engineer\r\nBest Boy\r\nBoom Operator\r\nCamera Operator\r\nChoreopgrapher\r\nCinematographer\r\nComposer\r\nCostume Designer\r\nCountinuity\r\nDesigner\r\nDirector\r\nDolly Grip\r\nDrivers\r\nElectrician\r\nExecutive Producer\r\nFocus Puller\r\nGaffer\r\nGenerator Operator\r\nGrip\r\nHair Dresser\r\nHelpers\r\nKey Grip\r\nLighting Designer\r\nLighting Technician\r\nLine Producer\r\nLocation Manager\r\nLocation Scouter\r\nMake-up Artist\r\nOutdoor Unit Technicians\r\nPost-Production\r\nProducer\r\nProduction Assistant\r\nProduction Coordinator\r\nScript Supervisor\r\nSet Decorator\r\nSound\r\nSound Editor\r\nSound Mixer\r\nSpecial Effects Supervisor\r\nStunt Coordinator\r\nStunt Performer\r\nTechnician\r\nTV Writer\r\nUnit Production Manager\r\nUtility Sound Technician\r\nVideographer\r\nVisual Effects\r\nVisual Effects Supervisor\r\nEquipment\r\nAudio\r\nCameras\r\nCranes\r\nLights\r\nOther Equipments\r\nGraphics &amp; Design\r\n3D &amp; 2D Models\r\nBanner Ads\r\nBook Covers &amp; Packaging\r\nBusiness Cards &amp; Stationery\r\nCartoons &amp; Caricatures\r\nFlyers &amp; Posters\r\nIllustrations\r\nInfographics\r\nInvitations\r\nLogo Design\r\nOthers - Graphics &amp; Design\r\nPhotoshop Editing\r\nPresentation Design\r\nSocial Media Design\r\nT-Shirts\r\nVector Tracing\r\nWeb &amp; Mobile Design\r\nLifestyle\r\nCooking Recipes\r\nDiet &amp; Weight Loss\r\nHealth &amp; Fitness\r\nRelationship Advice\r\nMusic &amp; Audio\r\nJingles &amp; Drops\r\nMixing &amp; Mastering\r\nMusic Direction\r\nOthers - Music &amp; Audio\r\nProducers &amp; Composers\r\nSession Musicians &amp; Singers\r\nSinger - Songwriters\r\nSound Effects\r\nSound Recordist / Sound Assist\r\nVoice Over\r\nOthers\r\nPromotion\r\nBanner Advertising\r\nContent Marketing\r\nDomain Research\r\nEmail Marketing\r\nFlyers &amp; Handouts\r\nHold Your Sign\r\nHuman Billboards\r\nInFilm Branding\r\nInfluencer Marketing\r\nLocal Listings\r\nMarketing Strategy\r\nMobile Advertising\r\nMusic Promotion\r\nOthers - Promotion\r\nOutdoor Advertising\r\nPet Models\r\nRadio Advertising\r\nSEM\r\nSEO\r\nSocial Media Marketing\r\nVideo Advertising\r\nWeb Analytics\r\nWeb Traffic\r\nSoftware\r\nConvert Files\r\nData Analysis &amp; Reports\r\nDatabases\r\nDesktop Applications\r\nEcommerce\r\nGaming\r\nMobile Apps &amp; Web\r\nOthers - Programming &amp; Tech\r\nQA\r\nSupport &amp; IT\r\nUser Testing\r\nWeb Programming\r\nWebsite Builders &amp; CMS\r\nWordPress\r\nWriting &amp; Translation\r\nArticles &amp; Blog Posts\r\nBusiness Copywriting\r\nCreative Writing\r\nLegal writing\r\nOthers - Writing &amp; Translation\r\nPress Releases\r\nProofreading &amp; Editing\r\nResearch &amp; Summaries\r\nResumes &amp; Cover Letters\r\nScript Writing\r\nSong Writing / Lyricist\r\nTranscription\r\nTranslation'),
('price', '5'),
('ver', '7.5.1'),
('price_mode', '1'),
('approve_suggests', '1'),
('view_rel_max', '7'),
('view_more_max', '7'),
('paypal_email', 'pay@greatfilmjobs.com'),
('notify_email', 'design@madhurebba.com'),
('currency', 'USD'),
('days_before_withdraw', '14'),
('commission', '1'),
('FACEBOOK_APP_ID', '1750802685183844'),
('FACEBOOK_SECRET', '6cd284acfa345e9f4ee91d56a3a1b73d'),
('enable_fc', '1'),
('commission_percent', '20'),
('short_urls', '1'),
('twitter', 'GreatFilmJobs'),
('vonly', '1'),
('enable_alertpay', '0'),
('enable_paypal', '1'),
('alertpay_email', 'design@madhurebba.com'),
('alertpay_currency', 'USD'),
('ap_code', 'E8mvjWycoCBCeP1P'),
('fprice', '10'),
('fdays', '30'),
('scriptolution_toprated_rating', '60'),
('scriptolution_toprated_count', '10'),
('verify_pm', '1'),
('def_country', 'US'),
('enable_levels', '0'),
('level1job', '1'),
('level2job', '3'),
('level3job', ''),
('level2num', '10'),
('level2rate', '90'),
('level3num', '20'),
('level3rate', '90'),
('scriptolution_proxy_block', '0'),
('enable_ref', '0'),
('ref_price', '1'),
('scriptolution_paypal_confirm', '0'),
('items_per_page_new', '28'),
('hide_catnav', '0'),
('enable_captcha', '4'),
('fiverrscript_dotcom_home_featcats', '1'),
('scriptolution_notify_gigval', '1'),
('scriptolution_notify_gigval_email', 'design@madhurebba.com'),
('scriptolution_solve_c', 'rxM0Add9QYj6fbcgs58nL7-ivKWj8HqF'),
('scriptolution_solve_v', 'jzRpiw11DA6MsTHWEMwfAZUdKRa61Pa9'),
('scriptolution_solve_h', 'McHmHSLWzKDzGtbC-y8fcUHwHzWNDeYh'),
('recaptcha_pubkey', ''),
('recaptcha_privkey', ''),
('scriptolution_cur_pos', '0'),
('scriptolution_launch_mode', '0'),
('scriptolution_mail_from_name', 'Great Film Jobs'),
('scriptolutionstripeenable', '0'),
('scriptolutionstripesecret', ''),
('scriptolutionstripepublishable', ''),
('scriptolutionstripecurrency', 'USD'),
('enablescriptolutionlocations', '1'),
('scriptolution_map_key', 'AIzaSyDFCanjNysDz9MiZTLxm4rguA-KiOV3TBY'),
('scriptolution_enable_processing_fee', '1'),
('scriptolution_processing_fee', '1.00'),
('enable_scriptolutionminwd', '1'),
('scriptolutionminwd', '10'),
('scriptolution_local', ''),
('scriptolution_bankinfo', ''),
('re_mobile', '1'),
('m_url', 'http://m.fiverrscript.com'),
('site_email', 'design@madhurebba.com'),
('site_name', 'GreatFilmJobs.com'),
('max_syndicate_results', '25'),
('maximum_results', '1000000'),
('emailsender', 'Admin'),
('max_suggest', '14'),
('items_per_page', '16'),
('site_slogan', 'GreatFilmJobs.com: Buy. Sell. Have fun!'),
('approve_stories', '1'),
('metadescription', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun!'),
('metakeywords', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun! Film Jobs Great Micro Jobs\r\nGig Extra Gig Video Greeting Props Director Movie audio music\r\nAnimation &amp; Video\r\nAfter Effects\r\nAnimated Characters &amp; Modeling\r\nAudio Stocks\r\nEditing &amp; Post Production\r\nGames Developers\r\nIntro &amp; Animated Logos\r\nLyrics &amp; Music Videos\r\nOthers - Video &amp; Animation\r\nPromotional &amp; Branded Videos\r\nSpokespersons &amp; Testimonials\r\nVideo Greetings\r\nVideo Stocks\r\nWhiteboard &amp; Explainer Videos\r\nArt Direction\r\nAnimals\r\nAnimatronics Puppets\r\nArts &amp; Crafts\r\nCostumes\r\nCostumes Rental / Sale\r\nDummy Props\r\nFashion Designers\r\nHandmade Jewellery\r\nLocations\r\nMakeup\r\nOthers - Art Direction\r\nProps\r\nSets\r\nSpecial Effects\r\nStoryboarding\r\nStyling &amp; Beauty\r\nVehicles\r\nArtistes / Models\r\nAnchors\r\nChoreographers\r\nComedians\r\nCrowd\r\nDancers\r\nFemale\r\nFemale Child\r\nJunior Artistes\r\nMale\r\nMale Child\r\nOthers - Artistes / Models\r\nStunt People\r\nBusiness\r\nBox Office Reports / Reviews\r\nBranding Services\r\nBusiness - Others\r\nBusiness Plans\r\nBusiness Tips\r\nCareer Advice\r\nFinancial Consulting\r\nLegal Consulting\r\nMarket Research\r\nPresentations\r\nVirtual Assistants\r\nCrew\r\nArt Director\r\nArtist\r\nAsst Director\r\nAudio Engineer\r\nBest Boy\r\nBoom Operator\r\nCamera Operator\r\nChoreopgrapher\r\nCinematographer\r\nComposer\r\nCostume Designer\r\nCountinuity\r\nDesigner\r\nDirector\r\nDolly Grip\r\nDrivers\r\nElectrician\r\nExecutive Producer\r\nFocus Puller\r\nGaffer\r\nGenerator Operator\r\nGrip\r\nHair Dresser\r\nHelpers\r\nKey Grip\r\nLighting Designer\r\nLighting Technician\r\nLine Producer\r\nLocation Manager\r\nLocation Scouter\r\nMake-up Artist\r\nOutdoor Unit Technicians\r\nPost-Production\r\nProducer\r\nProduction Assistant\r\nProduction Coordinator\r\nScript Supervisor\r\nSet Decorator\r\nSound\r\nSound Editor\r\nSound Mixer\r\nSpecial Effects Supervisor\r\nStunt Coordinator\r\nStunt Performer\r\nTechnician\r\nTV Writer\r\nUnit Production Manager\r\nUtility Sound Technician\r\nVideographer\r\nVisual Effects\r\nVisual Effects Supervisor\r\nEquipment\r\nAudio\r\nCameras\r\nCranes\r\nLights\r\nOther Equipments\r\nGraphics &amp; Design\r\n3D &amp; 2D Models\r\nBanner Ads\r\nBook Covers &amp; Packaging\r\nBusiness Cards &amp; Stationery\r\nCartoons &amp; Caricatures\r\nFlyers &amp; Posters\r\nIllustrations\r\nInfographics\r\nInvitations\r\nLogo Design\r\nOthers - Graphics &amp; Design\r\nPhotoshop Editing\r\nPresentation Design\r\nSocial Media Design\r\nT-Shirts\r\nVector Tracing\r\nWeb &amp; Mobile Design\r\nLifestyle\r\nCooking Recipes\r\nDiet &amp; Weight Loss\r\nHealth &amp; Fitness\r\nRelationship Advice\r\nMusic &amp; Audio\r\nJingles &amp; Drops\r\nMixing &amp; Mastering\r\nMusic Direction\r\nOthers - Music &amp; Audio\r\nProducers &amp; Composers\r\nSession Musicians &amp; Singers\r\nSinger - Songwriters\r\nSound Effects\r\nSound Recordist / Sound Assist\r\nVoice Over\r\nOthers\r\nPromotion\r\nBanner Advertising\r\nContent Marketing\r\nDomain Research\r\nEmail Marketing\r\nFlyers &amp; Handouts\r\nHold Your Sign\r\nHuman Billboards\r\nInFilm Branding\r\nInfluencer Marketing\r\nLocal Listings\r\nMarketing Strategy\r\nMobile Advertising\r\nMusic Promotion\r\nOthers - Promotion\r\nOutdoor Advertising\r\nPet Models\r\nRadio Advertising\r\nSEM\r\nSEO\r\nSocial Media Marketing\r\nVideo Advertising\r\nWeb Analytics\r\nWeb Traffic\r\nSoftware\r\nConvert Files\r\nData Analysis &amp; Reports\r\nDatabases\r\nDesktop Applications\r\nEcommerce\r\nGaming\r\nMobile Apps &amp; Web\r\nOthers - Programming &amp; Tech\r\nQA\r\nSupport &amp; IT\r\nUser Testing\r\nWeb Programming\r\nWebsite Builders &amp; CMS\r\nWordPress\r\nWriting &amp; Translation\r\nArticles &amp; Blog Posts\r\nBusiness Copywriting\r\nCreative Writing\r\nLegal writing\r\nOthers - Writing &amp; Translation\r\nPress Releases\r\nProofreading &amp; Editing\r\nResearch &amp; Summaries\r\nResumes &amp; Cover Letters\r\nScript Writing\r\nSong Writing / Lyricist\r\nTranscription\r\nTranslation'),
('price', '5'),
('ver', '7.0'),
('price_mode', '1'),
('approve_suggests', '1'),
('view_rel_max', '7'),
('view_more_max', '7'),
('paypal_email', 'pay@greatfilmjobs.com'),
('notify_email', 'design@madhurebba.com'),
('currency', 'USD'),
('days_before_withdraw', '14'),
('commission', '1'),
('FACEBOOK_APP_ID', '1750802685183844'),
('FACEBOOK_SECRET', '6cd284acfa345e9f4ee91d56a3a1b73d'),
('enable_fc', '1'),
('commission_percent', '20'),
('short_urls', '1'),
('twitter', 'GreatFilmJobs'),
('vonly', '1'),
('enable_alertpay', '0'),
('enable_paypal', '1'),
('alertpay_email', 'design@madhurebba.com'),
('alertpay_currency', 'USD'),
('ap_code', 'E8mvjWycoCBCeP1P'),
('fprice', '10'),
('fdays', '30'),
('scriptolution_toprated_rating', '60'),
('scriptolution_toprated_count', '10'),
('verify_pm', '1'),
('def_country', 'US'),
('enable_levels', '0'),
('level1job', ''),
('level2job', ''),
('level3job', ''),
('level2num', '10'),
('level2rate', '90'),
('level3num', '20'),
('level3rate', '90'),
('scriptolution_proxy_block', '0'),
('enable_ref', '0'),
('ref_price', '1'),
('scriptolution_paypal_confirm', '0'),
('items_per_page_new', '28'),
('hide_catnav', '1'),
('enable_captcha', '4'),
('fiverrscript_dotcom_home_featcats', '1'),
('scriptolution_notify_gigval', '1'),
('scriptolution_notify_gigval_email', 'design@madhurebba.com'),
('scriptolution_solve_c', 'rxM0Add9QYj6fbcgs58nL7-ivKWj8HqF'),
('scriptolution_solve_v', 'jzRpiw11DA6MsTHWEMwfAZUdKRa61Pa9'),
('scriptolution_solve_h', 'McHmHSLWzKDzGtbC-y8fcUHwHzWNDeYh'),
('recaptcha_pubkey', ''),
('recaptcha_privkey', ''),
('re_mobile', '1'),
('m_url', 'http://m.greatfilmprops.com'),
('scriptolution_local', ''),
('scriptolution_bankinfo', ''),
('enable_payu', '1'),
('payu_merchant_id', '5040266'),
('payu_merchant_key', '5R3pYh'),
('payu_merchant_salt', '8cedt3ps'),
('scriptolution_enable_processing_fee', '1'),
('scriptolution_processing_fee', '1.00'),
('site_email', 'design@madhurebba.com'),
('site_name', 'GreatFilmJobs.com'),
('max_syndicate_results', '25'),
('maximum_results', '1000000'),
('emailsender', 'Admin'),
('max_suggest', '14'),
('items_per_page', '16'),
('site_slogan', 'GreatFilmJobs.com: Buy. Sell. Have fun!'),
('approve_stories', '1'),
('metadescription', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun!'),
('metakeywords', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun! Film Jobs Great Micro Jobs\r\nGig Extra Gig Video Greeting Props Director Movie audio music\r\nAnimation &amp; Video\r\nAfter Effects\r\nAnimated Characters &amp; Modeling\r\nAudio Stocks\r\nEditing &amp; Post Production\r\nGames Developers\r\nIntro &amp; Animated Logos\r\nLyrics &amp; Music Videos\r\nOthers - Video &amp; Animation\r\nPromotional &amp; Branded Videos\r\nSpokespersons &amp; Testimonials\r\nVideo Greetings\r\nVideo Stocks\r\nWhiteboard &amp; Explainer Videos\r\nArt Direction\r\nAnimals\r\nAnimatronics Puppets\r\nArts &amp; Crafts\r\nCostumes\r\nCostumes Rental / Sale\r\nDummy Props\r\nFashion Designers\r\nHandmade Jewellery\r\nLocations\r\nMakeup\r\nOthers - Art Direction\r\nProps\r\nSets\r\nSpecial Effects\r\nStoryboarding\r\nStyling &amp; Beauty\r\nVehicles\r\nArtistes / Models\r\nAnchors\r\nChoreographers\r\nComedians\r\nCrowd\r\nDancers\r\nFemale\r\nFemale Child\r\nJunior Artistes\r\nMale\r\nMale Child\r\nOthers - Artistes / Models\r\nStunt People\r\nBusiness\r\nBox Office Reports / Reviews\r\nBranding Services\r\nBusiness - Others\r\nBusiness Plans\r\nBusiness Tips\r\nCareer Advice\r\nFinancial Consulting\r\nLegal Consulting\r\nMarket Research\r\nPresentations\r\nVirtual Assistants\r\nCrew\r\nArt Director\r\nArtist\r\nAsst Director\r\nAudio Engineer\r\nBest Boy\r\nBoom Operator\r\nCamera Operator\r\nChoreopgrapher\r\nCinematographer\r\nComposer\r\nCostume Designer\r\nCountinuity\r\nDesigner\r\nDirector\r\nDolly Grip\r\nDrivers\r\nElectrician\r\nExecutive Producer\r\nFocus Puller\r\nGaffer\r\nGenerator Operator\r\nGrip\r\nHair Dresser\r\nHelpers\r\nKey Grip\r\nLighting Designer\r\nLighting Technician\r\nLine Producer\r\nLocation Manager\r\nLocation Scouter\r\nMake-up Artist\r\nOutdoor Unit Technicians\r\nPost-Production\r\nProducer\r\nProduction Assistant\r\nProduction Coordinator\r\nScript Supervisor\r\nSet Decorator\r\nSound\r\nSound Editor\r\nSound Mixer\r\nSpecial Effects Supervisor\r\nStunt Coordinator\r\nStunt Performer\r\nTechnician\r\nTV Writer\r\nUnit Production Manager\r\nUtility Sound Technician\r\nVideographer\r\nVisual Effects\r\nVisual Effects Supervisor\r\nEquipment\r\nAudio\r\nCameras\r\nCranes\r\nLights\r\nOther Equipments\r\nGraphics &amp; Design\r\n3D &amp; 2D Models\r\nBanner Ads\r\nBook Covers &amp; Packaging\r\nBusiness Cards &amp; Stationery\r\nCartoons &amp; Caricatures\r\nFlyers &amp; Posters\r\nIllustrations\r\nInfographics\r\nInvitations\r\nLogo Design\r\nOthers - Graphics &amp; Design\r\nPhotoshop Editing\r\nPresentation Design\r\nSocial Media Design\r\nT-Shirts\r\nVector Tracing\r\nWeb &amp; Mobile Design\r\nLifestyle\r\nCooking Recipes\r\nDiet &amp; Weight Loss\r\nHealth &amp; Fitness\r\nRelationship Advice\r\nMusic &amp; Audio\r\nJingles &amp; Drops\r\nMixing &amp; Mastering\r\nMusic Direction\r\nOthers - Music &amp; Audio\r\nProducers &amp; Composers\r\nSession Musicians &amp; Singers\r\nSinger - Songwriters\r\nSound Effects\r\nSound Recordist / Sound Assist\r\nVoice Over\r\nOthers\r\nPromotion\r\nBanner Advertising\r\nContent Marketing\r\nDomain Research\r\nEmail Marketing\r\nFlyers &amp; Handouts\r\nHold Your Sign\r\nHuman Billboards\r\nInFilm Branding\r\nInfluencer Marketing\r\nLocal Listings\r\nMarketing Strategy\r\nMobile Advertising\r\nMusic Promotion\r\nOthers - Promotion\r\nOutdoor Advertising\r\nPet Models\r\nRadio Advertising\r\nSEM\r\nSEO\r\nSocial Media Marketing\r\nVideo Advertising\r\nWeb Analytics\r\nWeb Traffic\r\nSoftware\r\nConvert Files\r\nData Analysis &amp; Reports\r\nDatabases\r\nDesktop Applications\r\nEcommerce\r\nGaming\r\nMobile Apps &amp; Web\r\nOthers - Programming &amp; Tech\r\nQA\r\nSupport &amp; IT\r\nUser Testing\r\nWeb Programming\r\nWebsite Builders &amp; CMS\r\nWordPress\r\nWriting &amp; Translation\r\nArticles &amp; Blog Posts\r\nBusiness Copywriting\r\nCreative Writing\r\nLegal writing\r\nOthers - Writing &amp; Translation\r\nPress Releases\r\nProofreading &amp; Editing\r\nResearch &amp; Summaries\r\nResumes &amp; Cover Letters\r\nScript Writing\r\nSong Writing / Lyricist\r\nTranscription\r\nTranslation'),
('price', '5'),
('ver', '8.3.4'),
('price_mode', '1'),
('approve_suggests', '1'),
('view_rel_max', '7'),
('view_more_max', '7'),
('paypal_email', 'pay@greatfilmjobs.com'),
('notify_email', 'design@madhurebba.com'),
('currency', 'USD'),
('days_before_withdraw', '14'),
('commission', '1'),
('FACEBOOK_APP_ID', '1750802685183844'),
('FACEBOOK_SECRET', '6cd284acfa345e9f4ee91d56a3a1b73d'),
('enable_fc', '1'),
('commission_percent', '20'),
('short_urls', '1'),
('twitter', 'GreatFilmJobs'),
('vonly', '1'),
('enable_alertpay', '0'),
('enable_paypal', '1'),
('alertpay_email', 'design@madhurebba.com'),
('alertpay_currency', 'USD'),
('ap_code', 'E8mvjWycoCBCeP1P'),
('fprice', '10'),
('fdays', '30'),
('scriptolution_toprated_rating', '60'),
('scriptolution_toprated_count', '10'),
('verify_pm', '1'),
('def_country', 'US'),
('enable_levels', '0'),
('level1job', '1'),
('level2job', '3'),
('level3job', ''),
('level2num', '10'),
('level2rate', '90'),
('level3num', '20'),
('level3rate', '90'),
('scriptolution_proxy_block', '0'),
('enable_ref', '0'),
('ref_price', '1'),
('scriptolution_paypal_confirm', '0'),
('items_per_page_new', '28'),
('hide_catnav', '0'),
('enable_captcha', '4'),
('fiverrscript_dotcom_home_featcats', '1'),
('scriptolution_notify_gigval', '1'),
('scriptolution_notify_gigval_email', 'design@madhurebba.com'),
('scriptolution_solve_c', 'rxM0Add9QYj6fbcgs58nL7-ivKWj8HqF'),
('scriptolution_solve_v', 'jzRpiw11DA6MsTHWEMwfAZUdKRa61Pa9'),
('scriptolution_solve_h', 'McHmHSLWzKDzGtbC-y8fcUHwHzWNDeYh'),
('recaptcha_pubkey', ''),
('recaptcha_privkey', ''),
('scriptolution_cur_pos', '0'),
('scriptolution_launch_mode', '0'),
('scriptolution_mail_from_name', 'Great Film Jobs'),
('scriptolutionstripeenable', '0'),
('scriptolutionstripesecret', ''),
('scriptolutionstripepublishable', ''),
('scriptolutionstripecurrency', 'USD'),
('enablescriptolutionlocations', '1'),
('scriptolution_map_key', 'AIzaSyDFCanjNysDz9MiZTLxm4rguA-KiOV3TBY'),
('scriptolution_enable_processing_fee', '1'),
('scriptolution_processing_fee', '1.00'),
('enable_scriptolutionminwd', '1'),
('scriptolutionminwd', '10'),
('site_email', 'design@madhurebba.com'),
('site_name', 'GreatFilmJobs.com'),
('max_syndicate_results', '25'),
('maximum_results', '1000000'),
('emailsender', 'Admin'),
('max_suggest', '14'),
('items_per_page', '16'),
('site_slogan', 'GreatFilmJobs.com: Buy. Sell. Have fun!'),
('approve_stories', '1'),
('metadescription', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun!'),
('metakeywords', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun! Film Jobs Great Micro Jobs\r\nGig Extra Gig Video Greeting Props Director Movie audio music\r\nAnimation &amp; Video\r\nAfter Effects\r\nAnimated Characters &amp; Modeling\r\nAudio Stocks\r\nEditing &amp; Post Production\r\nGames Developers\r\nIntro &amp; Animated Logos\r\nLyrics &amp; Music Videos\r\nOthers - Video &amp; Animation\r\nPromotional &amp; Branded Videos\r\nSpokespersons &amp; Testimonials\r\nVideo Greetings\r\nVideo Stocks\r\nWhiteboard &amp; Explainer Videos\r\nArt Direction\r\nAnimals\r\nAnimatronics Puppets\r\nArts &amp; Crafts\r\nCostumes\r\nCostumes Rental / Sale\r\nDummy Props\r\nFashion Designers\r\nHandmade Jewellery\r\nLocations\r\nMakeup\r\nOthers - Art Direction\r\nProps\r\nSets\r\nSpecial Effects\r\nStoryboarding\r\nStyling &amp; Beauty\r\nVehicles\r\nArtistes / Models\r\nAnchors\r\nChoreographers\r\nComedians\r\nCrowd\r\nDancers\r\nFemale\r\nFemale Child\r\nJunior Artistes\r\nMale\r\nMale Child\r\nOthers - Artistes / Models\r\nStunt People\r\nBusiness\r\nBox Office Reports / Reviews\r\nBranding Services\r\nBusiness - Others\r\nBusiness Plans\r\nBusiness Tips\r\nCareer Advice\r\nFinancial Consulting\r\nLegal Consulting\r\nMarket Research\r\nPresentations\r\nVirtual Assistants\r\nCrew\r\nArt Director\r\nArtist\r\nAsst Director\r\nAudio Engineer\r\nBest Boy\r\nBoom Operator\r\nCamera Operator\r\nChoreopgrapher\r\nCinematographer\r\nComposer\r\nCostume Designer\r\nCountinuity\r\nDesigner\r\nDirector\r\nDolly Grip\r\nDrivers\r\nElectrician\r\nExecutive Producer\r\nFocus Puller\r\nGaffer\r\nGenerator Operator\r\nGrip\r\nHair Dresser\r\nHelpers\r\nKey Grip\r\nLighting Designer\r\nLighting Technician\r\nLine Producer\r\nLocation Manager\r\nLocation Scouter\r\nMake-up Artist\r\nOutdoor Unit Technicians\r\nPost-Production\r\nProducer\r\nProduction Assistant\r\nProduction Coordinator\r\nScript Supervisor\r\nSet Decorator\r\nSound\r\nSound Editor\r\nSound Mixer\r\nSpecial Effects Supervisor\r\nStunt Coordinator\r\nStunt Performer\r\nTechnician\r\nTV Writer\r\nUnit Production Manager\r\nUtility Sound Technician\r\nVideographer\r\nVisual Effects\r\nVisual Effects Supervisor\r\nEquipment\r\nAudio\r\nCameras\r\nCranes\r\nLights\r\nOther Equipments\r\nGraphics &amp; Design\r\n3D &amp; 2D Models\r\nBanner Ads\r\nBook Covers &amp; Packaging\r\nBusiness Cards &amp; Stationery\r\nCartoons &amp; Caricatures\r\nFlyers &amp; Posters\r\nIllustrations\r\nInfographics\r\nInvitations\r\nLogo Design\r\nOthers - Graphics &amp; Design\r\nPhotoshop Editing\r\nPresentation Design\r\nSocial Media Design\r\nT-Shirts\r\nVector Tracing\r\nWeb &amp; Mobile Design\r\nLifestyle\r\nCooking Recipes\r\nDiet &amp; Weight Loss\r\nHealth &amp; Fitness\r\nRelationship Advice\r\nMusic &amp; Audio\r\nJingles &amp; Drops\r\nMixing &amp; Mastering\r\nMusic Direction\r\nOthers - Music &amp; Audio\r\nProducers &amp; Composers\r\nSession Musicians &amp; Singers\r\nSinger - Songwriters\r\nSound Effects\r\nSound Recordist / Sound Assist\r\nVoice Over\r\nOthers\r\nPromotion\r\nBanner Advertising\r\nContent Marketing\r\nDomain Research\r\nEmail Marketing\r\nFlyers &amp; Handouts\r\nHold Your Sign\r\nHuman Billboards\r\nInFilm Branding\r\nInfluencer Marketing\r\nLocal Listings\r\nMarketing Strategy\r\nMobile Advertising\r\nMusic Promotion\r\nOthers - Promotion\r\nOutdoor Advertising\r\nPet Models\r\nRadio Advertising\r\nSEM\r\nSEO\r\nSocial Media Marketing\r\nVideo Advertising\r\nWeb Analytics\r\nWeb Traffic\r\nSoftware\r\nConvert Files\r\nData Analysis &amp; Reports\r\nDatabases\r\nDesktop Applications\r\nEcommerce\r\nGaming\r\nMobile Apps &amp; Web\r\nOthers - Programming &amp; Tech\r\nQA\r\nSupport &amp; IT\r\nUser Testing\r\nWeb Programming\r\nWebsite Builders &amp; CMS\r\nWordPress\r\nWriting &amp; Translation\r\nArticles &amp; Blog Posts\r\nBusiness Copywriting\r\nCreative Writing\r\nLegal writing\r\nOthers - Writing &amp; Translation\r\nPress Releases\r\nProofreading &amp; Editing\r\nResearch &amp; Summaries\r\nResumes &amp; Cover Letters\r\nScript Writing\r\nSong Writing / Lyricist\r\nTranscription\r\nTranslation'),
('price', '5'),
('ver', '8.3.4'),
('price_mode', '1'),
('approve_suggests', '1'),
('view_rel_max', '7'),
('view_more_max', '7'),
('paypal_email', 'pay@greatfilmjobs.com'),
('notify_email', 'design@madhurebba.com'),
('currency', 'USD'),
('days_before_withdraw', '14'),
('commission', '1'),
('FACEBOOK_APP_ID', '1750802685183844'),
('FACEBOOK_SECRET', '6cd284acfa345e9f4ee91d56a3a1b73d'),
('enable_fc', '1'),
('commission_percent', '20'),
('short_urls', '1'),
('twitter', 'GreatFilmJobs'),
('vonly', '1'),
('enable_alertpay', '0'),
('enable_paypal', '1'),
('alertpay_email', 'design@madhurebba.com'),
('alertpay_currency', 'USD'),
('ap_code', 'E8mvjWycoCBCeP1P'),
('fprice', '10'),
('fdays', '30'),
('scriptolution_toprated_rating', '60'),
('scriptolution_toprated_count', '10'),
('verify_pm', '1'),
('def_country', 'US'),
('enable_levels', '0'),
('level1job', '1'),
('level2job', '3'),
('level3job', ''),
('level2num', '10'),
('level2rate', '90'),
('level3num', '20'),
('level3rate', '90'),
('scriptolution_proxy_block', '0'),
('enable_ref', '0'),
('ref_price', '1'),
('scriptolution_paypal_confirm', '0'),
('items_per_page_new', '28'),
('hide_catnav', '0'),
('enable_captcha', '4'),
('fiverrscript_dotcom_home_featcats', '1'),
('scriptolution_notify_gigval', '1'),
('scriptolution_notify_gigval_email', 'design@madhurebba.com'),
('scriptolution_solve_c', 'rxM0Add9QYj6fbcgs58nL7-ivKWj8HqF'),
('scriptolution_solve_v', 'jzRpiw11DA6MsTHWEMwfAZUdKRa61Pa9'),
('scriptolution_solve_h', 'McHmHSLWzKDzGtbC-y8fcUHwHzWNDeYh'),
('recaptcha_pubkey', ''),
('recaptcha_privkey', ''),
('scriptolution_cur_pos', '0'),
('scriptolution_launch_mode', '0'),
('scriptolution_mail_from_name', 'Great Film Jobs'),
('scriptolutionstripeenable', '0'),
('scriptolutionstripesecret', ''),
('scriptolutionstripepublishable', ''),
('scriptolutionstripecurrency', 'USD'),
('enablescriptolutionlocations', '1'),
('scriptolution_map_key', 'AIzaSyDFCanjNysDz9MiZTLxm4rguA-KiOV3TBY'),
('scriptolution_enable_processing_fee', '1'),
('scriptolution_processing_fee', '1.00'),
('enable_scriptolutionminwd', '1'),
('scriptolutionminwd', '10'),
('site_email', 'design@madhurebba.com'),
('site_name', 'GreatFilmJobs.com'),
('max_syndicate_results', '25'),
('maximum_results', '1000000'),
('emailsender', 'Admin'),
('max_suggest', '14'),
('items_per_page', '16'),
('site_slogan', 'GreatFilmJobs.com: Buy. Sell. Have fun!'),
('approve_stories', '1'),
('metadescription', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun!'),
('metakeywords', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun! Film Jobs Great Micro Jobs\r\nGig Extra Gig Video Greeting Props Director Movie audio music\r\nAnimation &amp; Video\r\nAfter Effects\r\nAnimated Characters &amp; Modeling\r\nAudio Stocks\r\nEditing &amp; Post Production\r\nGames Developers\r\nIntro &amp; Animated Logos\r\nLyrics &amp; Music Videos\r\nOthers - Video &amp; Animation\r\nPromotional &amp; Branded Videos\r\nSpokespersons &amp; Testimonials\r\nVideo Greetings\r\nVideo Stocks\r\nWhiteboard &amp; Explainer Videos\r\nArt Direction\r\nAnimals\r\nAnimatronics Puppets\r\nArts &amp; Crafts\r\nCostumes\r\nCostumes Rental / Sale\r\nDummy Props\r\nFashion Designers\r\nHandmade Jewellery\r\nLocations\r\nMakeup\r\nOthers - Art Direction\r\nProps\r\nSets\r\nSpecial Effects\r\nStoryboarding\r\nStyling &amp; Beauty\r\nVehicles\r\nArtistes / Models\r\nAnchors\r\nChoreographers\r\nComedians\r\nCrowd\r\nDancers\r\nFemale\r\nFemale Child\r\nJunior Artistes\r\nMale\r\nMale Child\r\nOthers - Artistes / Models\r\nStunt People\r\nBusiness\r\nBox Office Reports / Reviews\r\nBranding Services\r\nBusiness - Others\r\nBusiness Plans\r\nBusiness Tips\r\nCareer Advice\r\nFinancial Consulting\r\nLegal Consulting\r\nMarket Research\r\nPresentations\r\nVirtual Assistants\r\nCrew\r\nArt Director\r\nArtist\r\nAsst Director\r\nAudio Engineer\r\nBest Boy\r\nBoom Operator\r\nCamera Operator\r\nChoreopgrapher\r\nCinematographer\r\nComposer\r\nCostume Designer\r\nCountinuity\r\nDesigner\r\nDirector\r\nDolly Grip\r\nDrivers\r\nElectrician\r\nExecutive Producer\r\nFocus Puller\r\nGaffer\r\nGenerator Operator\r\nGrip\r\nHair Dresser\r\nHelpers\r\nKey Grip\r\nLighting Designer\r\nLighting Technician\r\nLine Producer\r\nLocation Manager\r\nLocation Scouter\r\nMake-up Artist\r\nOutdoor Unit Technicians\r\nPost-Production\r\nProducer\r\nProduction Assistant\r\nProduction Coordinator\r\nScript Supervisor\r\nSet Decorator\r\nSound\r\nSound Editor\r\nSound Mixer\r\nSpecial Effects Supervisor\r\nStunt Coordinator\r\nStunt Performer\r\nTechnician\r\nTV Writer\r\nUnit Production Manager\r\nUtility Sound Technician\r\nVideographer\r\nVisual Effects\r\nVisual Effects Supervisor\r\nEquipment\r\nAudio\r\nCameras\r\nCranes\r\nLights\r\nOther Equipments\r\nGraphics &amp; Design\r\n3D &amp; 2D Models\r\nBanner Ads\r\nBook Covers &amp; Packaging\r\nBusiness Cards &amp; Stationery\r\nCartoons &amp; Caricatures\r\nFlyers &amp; Posters\r\nIllustrations\r\nInfographics\r\nInvitations\r\nLogo Design\r\nOthers - Graphics &amp; Design\r\nPhotoshop Editing\r\nPresentation Design\r\nSocial Media Design\r\nT-Shirts\r\nVector Tracing\r\nWeb &amp; Mobile Design\r\nLifestyle\r\nCooking Recipes\r\nDiet &amp; Weight Loss\r\nHealth &amp; Fitness\r\nRelationship Advice\r\nMusic &amp; Audio\r\nJingles &amp; Drops\r\nMixing &amp; Mastering\r\nMusic Direction\r\nOthers - Music &amp; Audio\r\nProducers &amp; Composers\r\nSession Musicians &amp; Singers\r\nSinger - Songwriters\r\nSound Effects\r\nSound Recordist / Sound Assist\r\nVoice Over\r\nOthers\r\nPromotion\r\nBanner Advertising\r\nContent Marketing\r\nDomain Research\r\nEmail Marketing\r\nFlyers &amp; Handouts\r\nHold Your Sign\r\nHuman Billboards\r\nInFilm Branding\r\nInfluencer Marketing\r\nLocal Listings\r\nMarketing Strategy\r\nMobile Advertising\r\nMusic Promotion\r\nOthers - Promotion\r\nOutdoor Advertising\r\nPet Models\r\nRadio Advertising\r\nSEM\r\nSEO\r\nSocial Media Marketing\r\nVideo Advertising\r\nWeb Analytics\r\nWeb Traffic\r\nSoftware\r\nConvert Files\r\nData Analysis &amp; Reports\r\nDatabases\r\nDesktop Applications\r\nEcommerce\r\nGaming\r\nMobile Apps &amp; Web\r\nOthers - Programming &amp; Tech\r\nQA\r\nSupport &amp; IT\r\nUser Testing\r\nWeb Programming\r\nWebsite Builders &amp; CMS\r\nWordPress\r\nWriting &amp; Translation\r\nArticles &amp; Blog Posts\r\nBusiness Copywriting\r\nCreative Writing\r\nLegal writing\r\nOthers - Writing &amp; Translation\r\nPress Releases\r\nProofreading &amp; Editing\r\nResearch &amp; Summaries\r\nResumes &amp; Cover Letters\r\nScript Writing\r\nSong Writing / Lyricist\r\nTranscription\r\nTranslation'),
('price', '5'),
('ver', '8.3.4'),
('price_mode', '1'),
('approve_suggests', '1'),
('view_rel_max', '7'),
('view_more_max', '7'),
('paypal_email', 'pay@greatfilmjobs.com'),
('notify_email', 'design@madhurebba.com'),
('currency', 'USD'),
('days_before_withdraw', '14'),
('commission', '1'),
('FACEBOOK_APP_ID', '1750802685183844'),
('FACEBOOK_SECRET', '6cd284acfa345e9f4ee91d56a3a1b73d'),
('enable_fc', '1'),
('commission_percent', '20'),
('short_urls', '1'),
('twitter', 'GreatFilmJobs'),
('vonly', '1'),
('enable_alertpay', '0'),
('enable_paypal', '1'),
('alertpay_email', 'design@madhurebba.com'),
('alertpay_currency', 'USD'),
('ap_code', 'E8mvjWycoCBCeP1P'),
('fprice', '10'),
('fdays', '30'),
('scriptolution_toprated_rating', '60'),
('scriptolution_toprated_count', '10'),
('verify_pm', '1'),
('def_country', 'US'),
('enable_levels', '0'),
('level1job', '1'),
('level2job', '3'),
('level3job', ''),
('level2num', '10'),
('level2rate', '90'),
('level3num', '20'),
('level3rate', '90'),
('scriptolution_proxy_block', '0'),
('enable_ref', '0'),
('ref_price', '1'),
('scriptolution_paypal_confirm', '0'),
('items_per_page_new', '28'),
('hide_catnav', '0'),
('enable_captcha', '4'),
('fiverrscript_dotcom_home_featcats', '1'),
('scriptolution_notify_gigval', '1'),
('scriptolution_notify_gigval_email', 'design@madhurebba.com'),
('scriptolution_solve_c', 'rxM0Add9QYj6fbcgs58nL7-ivKWj8HqF'),
('scriptolution_solve_v', 'jzRpiw11DA6MsTHWEMwfAZUdKRa61Pa9'),
('scriptolution_solve_h', 'McHmHSLWzKDzGtbC-y8fcUHwHzWNDeYh'),
('recaptcha_pubkey', ''),
('recaptcha_privkey', ''),
('scriptolution_cur_pos', '0'),
('scriptolution_launch_mode', '0'),
('scriptolution_mail_from_name', 'Great Film Jobs'),
('scriptolutionstripeenable', '0'),
('scriptolutionstripesecret', ''),
('scriptolutionstripepublishable', ''),
('scriptolutionstripecurrency', 'USD'),
('enablescriptolutionlocations', '1'),
('scriptolution_map_key', 'AIzaSyDFCanjNysDz9MiZTLxm4rguA-KiOV3TBY'),
('scriptolution_enable_processing_fee', '1'),
('scriptolution_processing_fee', '1.00'),
('enable_scriptolutionminwd', '1'),
('scriptolutionminwd', '10'),
('site_email', 'design@madhurebba.com'),
('site_name', 'GreatFilmJobs.com'),
('max_syndicate_results', '25'),
('maximum_results', '1000000'),
('emailsender', 'Admin'),
('max_suggest', '14'),
('items_per_page', '16'),
('site_slogan', 'GreatFilmJobs.com: Buy. Sell. Have fun!'),
('approve_stories', '1'),
('metadescription', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun!'),
('metakeywords', 'GreatFilmJobs.com for all kinds of MicroJobs! Buy. Sell. Have fun! Film Jobs Great Micro Jobs\r\nGig Extra Gig Video Greeting Props Director Movie audio music\r\nAnimation &amp; Video\r\nAfter Effects\r\nAnimated Characters &amp; Modeling\r\nAudio Stocks\r\nEditing &amp; Post Production\r\nGames Developers\r\nIntro &amp; Animated Logos\r\nLyrics &amp; Music Videos\r\nOthers - Video &amp; Animation\r\nPromotional &amp; Branded Videos\r\nSpokespersons &amp; Testimonials\r\nVideo Greetings\r\nVideo Stocks\r\nWhiteboard &amp; Explainer Videos\r\nArt Direction\r\nAnimals\r\nAnimatronics Puppets\r\nArts &amp; Crafts\r\nCostumes\r\nCostumes Rental / Sale\r\nDummy Props\r\nFashion Designers\r\nHandmade Jewellery\r\nLocations\r\nMakeup\r\nOthers - Art Direction\r\nProps\r\nSets\r\nSpecial Effects\r\nStoryboarding\r\nStyling &amp; Beauty\r\nVehicles\r\nArtistes / Models\r\nAnchors\r\nChoreographers\r\nComedians\r\nCrowd\r\nDancers\r\nFemale\r\nFemale Child\r\nJunior Artistes\r\nMale\r\nMale Child\r\nOthers - Artistes / Models\r\nStunt People\r\nBusiness\r\nBox Office Reports / Reviews\r\nBranding Services\r\nBusiness - Others\r\nBusiness Plans\r\nBusiness Tips\r\nCareer Advice\r\nFinancial Consulting\r\nLegal Consulting\r\nMarket Research\r\nPresentations\r\nVirtual Assistants\r\nCrew\r\nArt Director\r\nArtist\r\nAsst Director\r\nAudio Engineer\r\nBest Boy\r\nBoom Operator\r\nCamera Operator\r\nChoreopgrapher\r\nCinematographer\r\nComposer\r\nCostume Designer\r\nCountinuity\r\nDesigner\r\nDirector\r\nDolly Grip\r\nDrivers\r\nElectrician\r\nExecutive Producer\r\nFocus Puller\r\nGaffer\r\nGenerator Operator\r\nGrip\r\nHair Dresser\r\nHelpers\r\nKey Grip\r\nLighting Designer\r\nLighting Technician\r\nLine Producer\r\nLocation Manager\r\nLocation Scouter\r\nMake-up Artist\r\nOutdoor Unit Technicians\r\nPost-Production\r\nProducer\r\nProduction Assistant\r\nProduction Coordinator\r\nScript Supervisor\r\nSet Decorator\r\nSound\r\nSound Editor\r\nSound Mixer\r\nSpecial Effects Supervisor\r\nStunt Coordinator\r\nStunt Performer\r\nTechnician\r\nTV Writer\r\nUnit Production Manager\r\nUtility Sound Technician\r\nVideographer\r\nVisual Effects\r\nVisual Effects Supervisor\r\nEquipment\r\nAudio\r\nCameras\r\nCranes\r\nLights\r\nOther Equipments\r\nGraphics &amp; Design\r\n3D &amp; 2D Models\r\nBanner Ads\r\nBook Covers &amp; Packaging\r\nBusiness Cards &amp; Stationery\r\nCartoons &amp; Caricatures\r\nFlyers &amp; Posters\r\nIllustrations\r\nInfographics\r\nInvitations\r\nLogo Design\r\nOthers - Graphics &amp; Design\r\nPhotoshop Editing\r\nPresentation Design\r\nSocial Media Design\r\nT-Shirts\r\nVector Tracing\r\nWeb &amp; Mobile Design\r\nLifestyle\r\nCooking Recipes\r\nDiet &amp; Weight Loss\r\nHealth &amp; Fitness\r\nRelationship Advice\r\nMusic &amp; Audio\r\nJingles &amp; Drops\r\nMixing &amp; Mastering\r\nMusic Direction\r\nOthers - Music &amp; Audio\r\nProducers &amp; Composers\r\nSession Musicians &amp; Singers\r\nSinger - Songwriters\r\nSound Effects\r\nSound Recordist / Sound Assist\r\nVoice Over\r\nOthers\r\nPromotion\r\nBanner Advertising\r\nContent Marketing\r\nDomain Research\r\nEmail Marketing\r\nFlyers &amp; Handouts\r\nHold Your Sign\r\nHuman Billboards\r\nInFilm Branding\r\nInfluencer Marketing\r\nLocal Listings\r\nMarketing Strategy\r\nMobile Advertising\r\nMusic Promotion\r\nOthers - Promotion\r\nOutdoor Advertising\r\nPet Models\r\nRadio Advertising\r\nSEM\r\nSEO\r\nSocial Media Marketing\r\nVideo Advertising\r\nWeb Analytics\r\nWeb Traffic\r\nSoftware\r\nConvert Files\r\nData Analysis &amp; Reports\r\nDatabases\r\nDesktop Applications\r\nEcommerce\r\nGaming\r\nMobile Apps &amp; Web\r\nOthers - Programming &amp; Tech\r\nQA\r\nSupport &amp; IT\r\nUser Testing\r\nWeb Programming\r\nWebsite Builders &amp; CMS\r\nWordPress\r\nWriting &amp; Translation\r\nArticles &amp; Blog Posts\r\nBusiness Copywriting\r\nCreative Writing\r\nLegal writing\r\nOthers - Writing &amp; Translation\r\nPress Releases\r\nProofreading &amp; Editing\r\nResearch &amp; Summaries\r\nResumes &amp; Cover Letters\r\nScript Writing\r\nSong Writing / Lyricist\r\nTranscription\r\nTranslation'),
('price', '5'),
('ver', '8.3.4'),
('price_mode', '1'),
('approve_suggests', '1'),
('view_rel_max', '7'),
('view_more_max', '7'),
('paypal_email', 'pay@greatfilmjobs.com'),
('notify_email', 'design@madhurebba.com'),
('currency', 'USD'),
('days_before_withdraw', '14'),
('commission', '1'),
('FACEBOOK_APP_ID', '1750802685183844'),
('FACEBOOK_SECRET', '6cd284acfa345e9f4ee91d56a3a1b73d'),
('enable_fc', '1'),
('commission_percent', '20'),
('short_urls', '1'),
('twitter', 'GreatFilmJobs'),
('vonly', '1'),
('enable_alertpay', '0'),
('enable_paypal', '1'),
('alertpay_email', 'design@madhurebba.com'),
('alertpay_currency', 'USD'),
('ap_code', 'E8mvjWycoCBCeP1P'),
('fprice', '10'),
('fdays', '30'),
('scriptolution_toprated_rating', '60'),
('scriptolution_toprated_count', '10'),
('verify_pm', '1'),
('def_country', 'US'),
('enable_levels', '0'),
('level1job', '1'),
('level2job', '3'),
('level3job', ''),
('level2num', '10'),
('level2rate', '90'),
('level3num', '20'),
('level3rate', '90'),
('scriptolution_proxy_block', '0'),
('enable_ref', '0'),
('ref_price', '1'),
('scriptolution_paypal_confirm', '0'),
('items_per_page_new', '28'),
('hide_catnav', '0'),
('enable_captcha', '4'),
('fiverrscript_dotcom_home_featcats', '1'),
('scriptolution_notify_gigval', '1'),
('scriptolution_notify_gigval_email', 'design@madhurebba.com'),
('scriptolution_solve_c', 'rxM0Add9QYj6fbcgs58nL7-ivKWj8HqF'),
('scriptolution_solve_v', 'jzRpiw11DA6MsTHWEMwfAZUdKRa61Pa9'),
('scriptolution_solve_h', 'McHmHSLWzKDzGtbC-y8fcUHwHzWNDeYh'),
('recaptcha_pubkey', ''),
('recaptcha_privkey', ''),
('scriptolution_cur_pos', '0'),
('scriptolution_launch_mode', '0'),
('scriptolution_mail_from_name', 'Great Film Jobs'),
('scriptolutionstripeenable', '0'),
('scriptolutionstripesecret', ''),
('scriptolutionstripepublishable', ''),
('scriptolutionstripecurrency', 'USD'),
('enablescriptolutionlocations', '1'),
('scriptolution_map_key', 'AIzaSyDFCanjNysDz9MiZTLxm4rguA-KiOV3TBY'),
('scriptolution_enable_processing_fee', '1'),
('scriptolution_processing_fee', '1.00'),
('enable_scriptolutionminwd', '1'),
('scriptolutionminwd', '10'),
('short_urls', '1'),
('twitter', 'Scriptolution'),
('enable_razorpay', ''),
('razorpay_public', ''),
('razorpay_private', ''),
('enable_cashfree', '0'),
('cashfree_mode', '1'),
('cashfree_secret_key', 'e505bb82c462fed7c2fb29b54d5359267e8e8382'),
('cashfree_app_id', '87790c2c273bb37d2a42bf2f9778'),
('enable_cashfree', '0'),
('cashfree_mode', '1'),
('cashfree_secret_key', 'e505bb82c462fed7c2fb29b54d5359267e8e8382'),
('cashfree_app_id', '87790c2c273bb37d2a42bf2f9778'),
('enable_cashfree', '0'),
('cashfree_mode', '1'),
('cashfree_secret_key', 'e505bb82c462fed7c2fb29b54d5359267e8e8382'),
('cashfree_app_id', '87790c2c273bb37d2a42bf2f9778'),
('enable_cashfree', '0'),
('cashfree_mode', '1'),
('cashfree_secret_key', 'e505bb82c462fed7c2fb29b54d5359267e8e8382'),
('cashfree_app_id', '87790c2c273bb37d2a42bf2f9778'),
('enable_cashfree', '0'),
('cashfree_mode', '1'),
('cashfree_secret_key', 'e505bb82c462fed7c2fb29b54d5359267e8e8382'),
('cashfree_app_id', '87790c2c273bb37d2a42bf2f9778'),
('enable_cashfree', '0'),
('cashfree_mode', '1'),
('cashfree_secret_key', 'e505bb82c462fed7c2fb29b54d5359267e8e8382'),
('cashfree_app_id', '87790c2c273bb37d2a42bf2f9778'),
('enable_cashfree', '0'),
('cashfree_mode', '1'),
('cashfree_secret_key', 'e505bb82c462fed7c2fb29b54d5359267e8e8382'),
('cashfree_app_id', '87790c2c273bb37d2a42bf2f9778'),
('enable_cashfree', '0'),
('cashfree_mode', '1'),
('cashfree_secret_key', 'e505bb82c462fed7c2fb29b54d5359267e8e8382'),
('cashfree_app_id', '87790c2c273bb37d2a42bf2f9778');

-- --------------------------------------------------------

--
-- Table structure for table `extras`
--

CREATE TABLE `extras` (
  `EID` bigint(20) NOT NULL,
  `PID` bigint(20) NOT NULL DEFAULT '0',
  `etitle` varchar(200) NOT NULL DEFAULT '',
  `eprice` bigint(10) NOT NULL DEFAULT '0',
  `ctp` decimal(9,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `extras`
--

INSERT INTO `extras` (`EID`, `PID`, `etitle`, `eprice`, `ctp`) VALUES
(1, 40, 'get legal advice from a lawyer of your property document ', 18, 4.00),
(2, 40, 'check your property in and out and can send latest photographs along with boundaries ', 7, 1.60),
(3, 40, 'get the latest E.C. copy of your property document', 5, 1.00),
(4, 41, 'train your kid how to learn and write', 5, 1.00),
(5, 41, 'make your child to create own short stories', 9, 2.00),
(6, 45, 'teach algebra on an hourly basis', 5, 1.00),
(7, 46, 'take your elders for outing and make them feel happy ', 25, 5.00),
(8, 46, 'provide nurse assistance if needed ', 10, 2.00),
(9, 46, 'rejoice them with some entertainment', 15, 3.00),
(10, 48, 'get video coverage of &quot;ARCHANA&quot; ', 5, 1.00),
(11, 50, 'get video coverage of &quot;ARCHANA&quot; for you', 2, 0.20),
(12, 51, 'get video coverage of &quot;ARCHANA&quot; for you', 5, 1.00),
(13, 56, 'teach you pencil art skills', 9, 2.00),
(14, 56, 'train you free hand sketch skills', 9, 2.00),
(15, 56, 'teach you color combinations', 9, 2.00),
(16, 58, 'provide you video coverage ', 9, 2.00),
(17, 74, 'send vedio of your abhisekham', 9, 2.00),
(18, 75, 'send the vedio for the kunkumarchana', 15, 3.00),
(19, 76, 'teach you how to handle crayons', 12, 2.40),
(20, 77, 'teach you how to handle crayons ', 5, 1.00),
(21, 77, 'teach you how to handle water colors ', 5, 1.00),
(22, 77, 'teach you how to handle charcoal', 5, 1.00),
(23, 78, 'test your sketching skills', 5, 1.00),
(24, 78, 'test your Water Color skills ', 5, 1.00),
(25, 79, 'teach you extra exercises on Lines', 5, 1.00),
(26, 80, 'how to make a interesting composition using 2D shapes', 5, 1.00),
(27, 81, 'teach you how to design your own visiting card ', 9, 2.00),
(28, 81, 'teach you how to design a pamphlet for your company ', 15, 3.00),
(29, 82, 'teach you pencil shading of 3D shapes', 9, 2.00),
(30, 82, 'teach you how to color 3D shapes', 15, 3.00),
(31, 83, 'fill this form', 5, 1.00),
(32, 83, 'customise this agreement with your spects', 15, 3.00),
(33, 83, 'add more legal terms', 25, 5.00),
(34, 84, 'advice on Incorporating OPC in three simple steps', 10, 2.00),
(35, 84, 'customize documents required for opc', 25, 5.00),
(36, 84, 'Provide DIN number for director', 25, 5.00),
(37, 85, 'test1', 13, 2.60),
(38, 85, 'test2', 14, 2.80),
(39, 85, 'test3', 25, 5.00),
(40, 99, 'come with you ', 4, 40.00),
(41, 101, 'come with you ', 5, 60.00),
(42, 294, 'fill the employment agreement', 5, 1.00),
(43, 294, 'customize the employment agreement according to your requirement', 10, 2.00),
(44, 325, 'show how To Create Easy, Profitable KINDLE Cookbooks', 15, 3.00),
(45, 440, ' post a recommendation on your profile given by you limited to 120 words', 7, 1.40),
(46, 440, 'post a recommendation on your profile written by me limited to 250 words', 12, 2.40),
(47, 584, 'give you source file', 10, 2.00),
(48, 584, 'add details like shadows, gradients etc to really make the panels standout', 15, 3.00),
(49, 584, 'create animatic/animation of the storyboard and deliver as a video file', 20, 4.00),
(50, 586, 'include source file', 15, 3.00),
(51, 586, 'add full color ', 25, 5.00),
(52, 586, 'extra fast delivery:4 days', 25, 5.00),
(53, 588, 'give you color STORYBOARDS ', 15, 3.00),
(54, 591, 'do extra fast delivery', 10, 2.00),
(55, 591, 'write storyboard in words in format for any business presentation', 25, 5.00),
(56, 591, 'add taking points in each storyboard to avoid those lengthy power point presentation', 15, 3.00),
(57, 592, 'do extra fast delivery: 4 days', 25, 5.00),
(58, 592, 'clean up the drawing with full shading and backgroung', 15, 3.00),
(59, 592, 'clean up the drawing with full shading, background and color', 25, 5.00),
(60, 593, 'give you source file', 10, 2.00),
(61, 594, 'give you source file', 10, 2.00),
(62, 594, 'give you high quality hand drawn digital illustration of full color.', 15, 3.00),
(63, 597, 'add background/Scene', 8, 1.60),
(64, 597, 'include colors in illustration', 10, 2.00),
(65, 597, 'give for commercial use', 15, 3.00),
(66, 599, 'give you source file', 8, 1.60),
(67, 600, 'add talking points with each storyboard ', 15, 3.00),
(68, 601, 'give you source file', 8, 1.60),
(69, 602, 'give storyboards with full body', 8, 1.60),
(70, 603, 'give you source file', 5, 1.00),
(71, 604, 'draw background/scene for storyboards', 10, 2.00),
(72, 605, 'offer you an extra 20/15 pages until end of the script', 10, 2.00),
(73, 606, 'provide any information about  storyboard', 5, 1.00),
(74, 606, 'draw 1 B&amp;W storyboard panel', 25, 5.00),
(75, 606, 'draw illustration with line art partially', 25, 5.00),
(76, 622, 'draw detailed storyboard(only black and white) of one page', 15, 3.00),
(77, 622, 'draw detailed storyboard(full color) of one page', 25, 5.00),
(78, 885, 'deliver in 2 days', 5, 1.00),
(79, 885, 'add 5 more images of your choice', 5, 1.00),
(80, 885, 'add 7 more images of your choice', 7, 1.40),
(81, 888, 'add an additional 125 words', 7, 1.40),
(82, 891, 'include unlimited background sfx', 15, 3.00),
(83, 891, 'create a drop up to 15-30 sec in length', 15, 3.00),
(84, 891, 'send all files both in mp3 and WAV formats', 10, 2.00),
(85, 892, 'deliver in 4 days', 15, 3.00),
(86, 894, 'extra fast deliver: 2 days', 15, 3.00),
(87, 896, 'give fast delivery in 2 days', 2, 0.40),
(88, 896, 'give super fast delivery in 1 day', 4, 0.80),
(89, 901, 'edit 30 min of audio', 10, 2.00),
(90, 901, 'edit 45 min of audio', 15, 3.00),
(91, 901, 'edit 60 min of audio', 20, 4.00),
(92, 907, 'extra fast deliver: 2 days', 10, 2.00),
(93, 907, 'deliver a one hour mix with the tracks you choose(2 day)', 10, 2.00),
(94, 907, 'deliver a one hour mix with tracks and the order you choose', 15, 3.00),
(95, 909, 'extra fast deliver: 4 days', 25, 5.00),
(96, 909, 'provide individual stems in high quality WAV files', 15, 3.00),
(97, 909, 'provide you vocal editing', 15, 3.00),
(98, 911, 'do extra audio to edit', 10, 2.00),
(99, 911, 'do mastering optional', 25, 5.00),
(100, 911, 'add music ', 25, 5.00),
(101, 912, 'do extra fast delivery: 2 days', 15, 3.00),
(102, 913, 'tweet the link on my 5000 plus follower twitter account', 10, 2.00),
(103, 915, 'add extra words', 7, 1.40),
(104, 916, 'extra fast deliver: 1 day', 10, 2.00),
(105, 917, 'deliver in 2 days', 3, 0.60),
(106, 917, 'deliver in 1 day', 5, 1.00),
(107, 920, 'extra fast deliver: 2 days', 25, 5.00),
(108, 920, 'produce a show up to 60 min in length', 15, 3.00),
(109, 920, 'make up to 5 edits in your show audio, with you providing the extra time of edits', 15, 3.00),
(110, 921, 'deliver in 2 days', 3, 0.60),
(111, 921, 'deliver in 1 day', 4, 0.80),
(112, 922, 'give you the separate tracks and midi files', 15, 3.00),
(113, 922, 'master your track', 15, 3.00),
(114, 922, 'add a string orchestra to your entire song maximum 4 min', 20, 4.00),
(115, 923, 'master your track', 25, 5.00),
(116, 923, 'extra fast deliver( 2 days)', 20, 4.00),
(117, 923, 'provide 1 extra min', 10, 2.00),
(118, 924, 'deliver in 2 days', 3, 0.60),
(119, 924, 'deliver in 1 day', 5, 1.00),
(120, 925, 'play up to 2 min', 10, 2.00),
(121, 925, 'play up to 3 min', 15, 3.00),
(122, 925, 'record acoustic guitar in stereo for your song', 10, 2.00),
(123, 927, 'extra fast deliver: 2 days', 15, 3.00),
(124, 927, 'send you the midi file to edit as you please', 15, 3.00),
(125, 927, 'record using my PDP all maple shell acoustic kit', 15, 3.00),
(126, 928, 'extra fast deliver: 4 days', 20, 4.00),
(127, 929, 'extra fast deliver: 2 days', 15, 3.00),
(128, 929, 'professional package', 15, 3.00),
(129, 929, 'premium package', 20, 4.00),
(130, 937, 'write top line', 20, 4.00),
(131, 937, 'provide over +4 min', 10, 2.00),
(132, 937, 'provide top line melody', 20, 4.00),
(133, 942, 'extra fast deliver: 2 days', 25, 5.00),
(134, 942, 'add builds and drops saperate hook from verse with sounds and add sound touches', 25, 5.00),
(135, 943, 'extra fast deliver: 2 days', 15, 3.00),
(136, 943, 'make a sound fix according to your need', 25, 5.00),
(137, 945, 'extra fast deliver: 2 days', 1, 0.20),
(138, 947, 'extra fast deliver: 2 days', 20, 4.00),
(139, 947, 'convert to any audio format', 10, 2.00),
(140, 947, 'provide the music sheet', 10, 2.00),
(141, 948, 'Delivery of multiple files - up to 10 ', 10, 2.00),
(142, 948, 'Record to exact audio length (:30 seconds, etc.) ', 15, 3.00),
(143, 948, 'Add royalty free music from my library', 25, 5.00),
(144, 949, 'add background music', 15, 3.00),
(145, 949, 'separate files-splits', 10, 2.00),
(146, 949, 'provide express pass ', 10, 2.00),
(147, 950, 'split the recordings into separate files', 10, 2.00),
(148, 950, 'provide HQ audio', 10, 2.00),
(149, 950, 'proofread your copy', 10, 2.00),
(150, 952, 'extra fast deliver: 2 days', 10, 2.00),
(151, 952, 'include project file', 25, 5.00),
(152, 952, 'make professional 16 tracks mix saturation, eq, compression, summing, effects', 15, 3.00),
(153, 956, 'extra fast deliver: 2 days', 10, 2.00),
(154, 956, 'remove noise and enhance your audio up to 20 min long', 15, 3.00),
(155, 971, 'deliver in 2 days', 5, 1.00),
(156, 971, 'add 5 more images of your choice', 5, 1.00),
(157, 971, 'deliver in 1 day', 5, 1.00),
(158, 972, 'deliver in 2 days', 5, 1.00),
(159, 972, 'add 5 more images of your choice', 3, 0.60),
(160, 972, 'deliver in 1 day', 5, 1.00),
(161, 973, 'HD version', 4, 0.80),
(162, 973, 'deliver in 2 days', 2, 0.40),
(163, 974, 'deliver in 2 days', 5, 1.00),
(164, 974, 'HD version of the video', 2, 0.40),
(165, 975, 'deliver in 2 days', 5, 1.00),
(166, 975, 'deliver HD version of the video', 3, 0.60),
(167, 975, 'add another slide at last (blank black background) with from message', 3, 0.60),
(168, 976, 'add 5 more pictures to the video', 3, 0.60),
(169, 976, 'deliver HD version of the video', 1, 0.20),
(170, 976, 'deliver in 2 days', 1, 0.20),
(171, 977, 'add 4 more pictures to the video', 1, 0.20),
(172, 977, 'provide HD version of the video', 2, 0.40),
(173, 977, 'deliver in 2 days', 1, 0.20),
(174, 1033, 'add 4 more pictures to the video', 2, 0.40),
(175, 1033, 'provide HD version of the video', 1, 0.20),
(176, 1033, 'deliver in 2 days', 2, 0.40),
(177, 1056, 'add 5 more pictures to the video', 1, 0.20),
(178, 1056, 'give HD version of the presentation', 2, 0.40),
(179, 1056, 'do this in 2 days', 2, 0.40),
(180, 1057, 'give HD version of the presentation', 3, 0.60),
(181, 1057, 'deliver in 2 days', 3, 0.60),
(182, 1061, 'give HD version of this video for', 3, 0.60),
(183, 1061, 'deliver in 2 days', 2, 0.40),
(184, 1062, 'give HD version of this video for', 2, 0.40),
(185, 1062, 'deliver in 2 days', 2, 0.40),
(186, 1066, 'FULL HD resolution (1080p) file', 2, 0.40),
(187, 1066, 'deliver in 2 days', 1, 0.20),
(188, 1069, 'FULL HD resolution (1080p) file', 2, 0.40),
(189, 1069, 'deliver in 2 days', 1, 0.20),
(190, 1071, 'provide FULL HD resolution (1080p) file', 2, 0.40),
(191, 1071, 'deliver in 2 days', 2, 0.40),
(192, 1077, 'give HD version of this video for', 3, 0.60),
(193, 1077, 'deliver in 2 days', 2, 0.40),
(194, 1085, 'provide HD version of this video', 3, 0.60),
(195, 1085, 'deliver in 2 days', 2, 0.40),
(196, 1086, 'give HD version of this video for', 2, 0.40),
(197, 1086, 'deliver in 2 days', 2, 0.40),
(198, 1092, 'provide HD version of this video', 2, 0.40),
(199, 1092, 'deliver in 2 days', 2, 0.40),
(200, 1093, 'FULL HD resolution (1080p) file', 3, 0.60),
(201, 1093, 'Revisions', 5, 1.00),
(202, 1094, 'provide HD version of this video', 2, 0.40),
(203, 1094, 'deliver in 2 days', 3, 0.60),
(204, 1233, 'give HD version of this video for', 2, 0.40),
(205, 1233, 'do this in 2 days', 2, 0.40),
(206, 1238, 'I shall add 4 more pictures, 4 texts and another title', 3, 0.60),
(207, 1238, 'I shall add 4 more pictures, 4 texts and another title', 3, 0.60),
(208, 1238, 'I shall provide HD version of this video', 2, 0.40),
(209, 1239, 'I shall provide HD version of this video', 3, 0.60),
(210, 1239, 'I shall deliver in 2days', 2, 0.40),
(211, 1824, 'make something awesome for you adding other photos and data ', 25, 5.00),
(212, 2841, 'design professional logo', 15, 3.00);

-- --------------------------------------------------------

--
-- Table structure for table `featured`
--

CREATE TABLE `featured` (
  `ID` bigint(20) NOT NULL,
  `PID` bigint(20) NOT NULL DEFAULT '0',
  `time` varchar(20) DEFAULT NULL,
  `price` varchar(20) NOT NULL DEFAULT '0',
  `PAYPAL` bigint(20) NOT NULL,
  `exp` int(1) NOT NULL DEFAULT '0',
  `fiverrscriptdotcom_fstripe` bigint(20) NOT NULL DEFAULT '0',
  `fiverrscriptdotcom_fstripe_user` varchar(200) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `featured`
--

INSERT INTO `featured` (`ID`, `PID`, `time`, `price`, `PAYPAL`, `exp`, `fiverrscriptdotcom_fstripe`, `fiverrscriptdotcom_fstripe_user`) VALUES
(1, 114, '1426139858', '100.0', 7, 1, 0, ''),
(2, 116, '1426141387', '10.0', 69, 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `FID` bigint(20) NOT NULL,
  `fname` varchar(400) NOT NULL DEFAULT '',
  `time` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL,
  `s` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`FID`, `fname`, `time`, `ip`, `s`) VALUES
(1, 'employment-agreement.zip', '1413958471', '122.175.18.73', 'pItQM1413958471'),
(2, 'employment-agreement.zip', '1413958531', '122.175.18.73', 'eDb101413958531'),
(3, 'filmcity.zip', '1426066318', '202.153.41.162', 'hMXXO1426066318'),
(4, 'filmcity.zip', '1426067729', '202.153.41.162', 'TzdD91426067729'),
(5, 'filmcity.zip', '1426141465', '202.153.41.162', '8z8ng1426141465'),
(6, 'CocoonAndStars.zip', '1440570743', '49.204.35.243', 'apC8i1440570743'),
(7, 'employment-agreement.zip', '1475296232', '43.249.226.82', '1hoo61475296232'),
(8, '4.zip', '1475487001', '49.204.7.252', '5s1SQ1475487001'),
(9, '8.zip', '1475495897', '49.204.7.252', 'OkI1E1475495897'),
(10, '9.zip', '1475496169', '49.204.7.252', 'BBD111475496169'),
(11, '10.zip', '1475496613', '49.204.7.252', '8bL1Q1475496613'),
(12, '11.zip', '1475496793', '49.204.7.252', 'Htm8E1475496793'),
(13, '11.zip', '1475498467', '49.204.7.252', 'bJz961475498467'),
(14, '11.zip', '1475559655', '49.204.7.252', 'KBim61475559655'),
(15, '17.zip', '1475562617', '49.204.7.252', 'Ie7WL1475562617'),
(16, '18.zip', '1475562866', '49.204.7.252', 'pMjg01475562866'),
(17, '9.zip', '1475565692', '49.204.7.252', 'kB3aa1475565692'),
(18, 'DorchesterDrive_UK-00206.zip', '1475576860', '49.204.7.252', 'oK3w31475576860'),
(19, '1.zip', '1475576939', '49.204.7.252', 'wmfus1475576939'),
(20, '2.zip', '1475578392', '49.204.7.252', 'rcvpA1475578392'),
(21, '3.zip', '1475578686', '49.204.7.252', '5UBZ91475578686'),
(22, '3.zip', '1475578729', '49.204.7.252', 'Qzekm1475578729'),
(23, '4.zip', '1475579029', '49.204.7.252', 'kI0br1475579029'),
(24, '4.zip', '1475579067', '49.204.7.252', 'XljQv1475579067'),
(25, '5.zip', '1475579258', '49.204.7.252', 'FpRRz1475579258'),
(26, '6.zip', '1475579495', '49.204.7.252', 'PToKc1475579495'),
(27, '7.zip', '1475579656', '49.204.7.252', 'CsarW1475579656'),
(28, '8.zip', '1475579861', '49.204.7.252', 'wRkS01475579861'),
(29, '9.zip', '1475579996', '49.204.7.252', 'OmD8s1475579996'),
(30, '10.zip', '1475580143', '49.204.7.252', 'Gl1k41475580143'),
(31, '11.zip', '1475580496', '49.204.7.252', '5gwXz1475580496'),
(32, '12.zip', '1475580596', '49.204.7.252', 'JoDhc1475580596'),
(33, '12.zip', '1475580723', '49.204.7.252', 'pwPHe1475580723'),
(34, '13.zip', '1475580872', '49.204.7.252', 'UgBep1475580872'),
(35, '14.zip', '1475581051', '49.204.7.252', 'JNYpv1475581051'),
(36, '15.zip', '1475581193', '49.204.7.252', 'dKonH1475581193'),
(37, '16.zip', '1475581346', '49.204.7.252', 'bIEAB1475581346'),
(38, '1.zip', '1475581855', '49.204.7.252', '1Kj2C1475581855'),
(39, '1.zip', '1475581972', '49.204.7.252', 'VwtJt1475581972'),
(40, '2.zip', '1475582276', '49.204.7.252', 'PHsTj1475582276'),
(41, '2.zip', '1475582434', '49.204.7.252', '8ZLVq1475582434'),
(42, '4.zip', '1475582568', '49.204.7.252', 'VNUYi1475582568'),
(43, '5.zip', '1475582969', '49.204.7.252', 'MzxwK1475582969'),
(44, '6.zip', '1475583127', '49.204.7.252', 'sVcPX1475583127'),
(45, '6.zip', '1475583189', '49.204.7.252', 'ooJTk1475583189'),
(46, '7.zip', '1475583426', '49.204.7.252', 'r2drg1475583426'),
(47, 'Anushka.zip', '1476705873', '49.204.7.252', 'xbUfr1476705873'),
(48, 'allu.zip', '1476707148', '49.204.7.252', 'V6IME1476707148'),
(49, 'Bhumika.zip', '1476707356', '49.204.7.252', 'gYSYx1476707356'),
(50, 'allu.zip', '1476708011', '49.204.7.252', 'c4wZb1476708011'),
(51, 'Tamannaah.zip', '1476708294', '49.204.7.252', 'fQF9d1476708294'),
(52, 'allari.zip', '1476709156', '49.204.7.252', 'gJTis1476709156'),
(53, 'KamnaJethmalani.zip', '1476766768', '49.204.7.252', 'mErYr1476766768'),
(54, 'Poonam.zip', '1476768155', '49.204.7.252', 'SkiXS1476768155'),
(55, 'ali.zip', '1476779027', '49.204.7.252', 'Hyujd1476779027'),
(56, 'adhi.zip', '1476784595', '49.204.7.252', '3Be2w1476784595'),
(57, 'veda.zip', '1476785000', '49.204.7.252', 'aQQPC1476785000'),
(58, 'Tapsee.zip', '1476785955', '49.204.7.252', 'uVIIB1476785955'),
(59, 'adavi sheshu.zip', '1476786244', '49.204.7.252', '3TXX01476786244'),
(60, 'Suma.zip', '1476786724', '49.204.7.252', 'FwdwZ1476786724'),
(61, 'Samantha.zip', '1476787294', '49.204.7.252', '9H5lQ1476787294'),
(62, 'Saloni.zip', '1476787821', '49.204.7.252', 'j5pAt1476787821'),
(63, 'brahmi.zip', '1476788043', '49.204.7.252', 'jOVVh1476788043'),
(64, 'Sada.zip', '1476788341', '49.204.7.252', 'Ho0ar1476788341'),
(65, 'aryan.zip', '1476789648', '49.204.7.252', 'fnOif1476789648'),
(66, 'Samantha.zip', '1476789960', '49.204.7.252', 'uP75Y1476789960'),
(67, 'Bhumika.zip', '1476790659', '49.204.7.252', 'd78NN1476790659'),
(68, 'nithin.zip', '1476790810', '49.204.7.252', '8sW6q1476790810'),
(69, 'Tamannaah.zip', '1476790897', '49.204.7.252', 'bYg0g1476790897'),
(70, 'Anushka.zip', '1476791069', '49.204.7.252', '37Bfm1476791069'),
(71, 'Ramya krishnan.zip', '1476791704', '49.204.7.252', 'Y2FXI1476791704'),
(72, 'rajiv.zip', '1476792323', '49.204.7.252', '7QrJK1476792323'),
(73, 'venki.zip', '1476793397', '49.204.7.252', 'yvE301476793397'),
(74, 'suman.zip', '1476794636', '49.204.7.252', 'lH5Ge1476794636'),
(75, 'suman.zip', '1476852260', '49.204.7.252', 'cnMgd1476852260'),
(76, 'varun.zip', '1476855604', '49.204.7.252', '7paxk1476855604'),
(77, 'thanish.zip', '1476856629', '49.204.7.252', 'SPCX41476856629'),
(78, 'Vinayak.zip', '1476857458', '49.204.7.252', 'XLAcl1476857458'),
(79, 'sukumar.zip', '1476857937', '49.204.7.252', 'vikWH1476857937'),
(80, 'srinu vaitla.zip', '1476858255', '49.204.7.252', 'vvKco1476858255'),
(81, 'Ramgopal varma.zip', '1476858647', '49.204.7.252', 'RWSyv1476858647'),
(82, 'Raghavendra rao.zip', '1476859081', '49.204.7.252', 'fe3fB1476859081'),
(83, 'shivareddy.zip', '1476859609', '49.204.7.252', 'SJIye1476859609'),
(84, 'Puri jagannath.zip', '1476859857', '49.204.7.252', '7kA1n1476859857'),
(85, 'krishnabagavan.zip', '1476860547', '49.204.7.252', 'XQiyS1476860547'),
(86, 'group-1.zip', '1476863108', '49.204.7.252', 'wSclm1476863108'),
(87, 'group-2.zip', '1476864744', '49.204.7.252', 'feuwL1476864744'),
(88, 'puri.zip', '1476866541', '49.204.7.252', 'SCnIA1476866541'),
(89, 'lawrence.zip', '1476867514', '49.204.7.252', 'jGbuY1476867514'),
(90, 'shekar.zip', '1476868381', '49.204.7.252', 'O8r8n1476868381'),
(91, 'ravi babu.zip', '1476868855', '49.204.7.252', 'hazGL1476868855'),
(92, 'sukumar.zip', '1476869551', '49.204.7.252', '3hRAX1476869551'),
(93, 'Rajamouli.zip', '1476870624', '49.204.7.252', 'rwSgB1476870624'),
(94, 'group 3.zip', '1476871918', '49.204.7.252', 'JDN7n1476871918'),
(95, 'Krishna vasmi.zip', '1476943912', '49.204.7.252', 'RwuXg1476943912'),
(96, 'YVS Chowdary.zip', '1476944262', '49.204.7.252', 's9zXH1476944262'),
(97, 'Kodi Ramakrishna.zip', '1476944565', '49.204.7.252', '5N3Ga1476944565'),
(98, 'Karunakaran.zip', '1476944931', '49.204.7.252', 'QbV0P1476944931'),
(99, 'group 4.zip', '1476944933', '49.204.7.252', 'f9qxO1476944933'),
(100, 'Gunashekar.zip', '1476945192', '49.204.7.252', 'YRdZt1476945192'),
(101, 'Dasari NarayanaRao.zip', '1476945492', '49.204.7.252', 'IxCRy1476945492'),
(102, 'group-5.zip', '1476946488', '49.204.7.252', 'eUxOR1476946488'),
(103, 'r.p.patnaik.zip', '1476948039', '49.204.7.252', '3dl5G1476948039'),
(104, 'group-6.zip', '1476950078', '49.204.7.252', '3dAu81476950078'),
(105, 'Directors.zip', '1476950981', '49.204.7.252', 'dRJTG1476950981'),
(106, 'group-7.zip', '1476952845', '49.204.7.252', 'XoLur1476952845'),
(107, 'group-7.zip', '1476953034', '49.204.7.252', 'YQXpQ1476953034'),
(108, 'r.p.patnaik.zip', '1476956030', '49.204.7.252', 'Vcxy01476956030'),
(109, 'directors1.zip', '1476957000', '49.204.7.252', 'cmlpV1476957000'),
(110, 'group-8.zip', '1476957909', '49.204.7.252', 'h76yA1476957909'),
(111, 'directorss.zip', '1476958669', '49.204.7.252', '9NbB41476958669'),
(112, 'Devisri.zip', '1476960131', '49.204.7.252', 'mTEB41476960131'),
(113, 'Harris Jayaraj.zip', '1476960643', '49.204.7.252', 'Mb03w1476960643'),
(114, 'group-9.zip', '1476960713', '49.204.7.252', '9qWUG1476960713'),
(115, 'Ilaiyaraaja.zip', '1476961090', '49.204.7.252', 'tfTZT1476961090'),
(116, 'keeravani.zip', '1476961645', '49.204.7.252', 'Yj5ht1476961645'),
(117, 'koti.zip', '1476962118', '49.204.7.252', '9kvx01476962118'),
(118, 'Mani Sharma.zip', '1476962549', '49.204.7.252', 'SA8zo1476962549'),
(119, 'Rahman.zip', '1476962993', '49.204.7.252', 'xXTXn1476962993'),
(120, 'Balasubrahmanyam.zip', '1476963666', '49.204.7.252', '1PA6b1476963666'),
(121, 'ny.zip', '1476968949', '43.249.226.82', 'kBBZi1476968949'),
(122, 'ny.zip', '1476969123', '43.249.226.82', 'oNz2x1476969123'),
(123, 'Music.zip', '1477027224', '49.204.7.252', '8uo1h1477027224'),
(124, 'M.M. SRILEKHA.zip', '1477027469', '49.204.7.252', 'meMeF1477027469'),
(125, 'musicc.zip', '1477027942', '49.204.7.252', '27fYF1477027942'),
(126, 'sharathchandra.zip', '1477028786', '49.204.7.252', 'Abdu31477028786'),
(127, 'Musica.zip', '1477029089', '49.204.7.252', 'aOLY31477029089'),
(128, 'S.A. Rajkumar.zip', '1477029860', '49.204.7.252', 'r7MHJ1477029860'),
(129, 'musiccomposers.zip', '1477029873', '49.204.7.252', 'wzDSp1477029873'),
(130, 'Ramana Kumar Gogula.zip', '1477030625', '49.204.7.252', '9GeHK1477030625'),
(131, 'composers.zip', '1477031194', '49.204.7.252', '0DPm61477031194'),
(132, 'Dance.zip', '1477032357', '49.204.7.252', 'viq601477032357'),
(133, 'Shankar Mahadevan.zip', '1477032771', '49.204.7.252', 'NGVkl1477032771'),
(134, 'dancee.zip', '1477032820', '49.204.7.252', 'KIt1A1477032820'),
(135, 'raju.zip', '1477033427', '49.204.7.252', 'OWMH51477033427'),
(136, 'Shashi Preetam.zip', '1477033439', '49.204.7.252', 'YRTUb1477033439'),
(137, 'Chota . K . Naidu.zip', '1477034051', '49.204.7.252', '3Uw781477034051'),
(138, 'suchitra.zip', '1477034283', '49.204.7.252', 'wy3IH1477034283'),
(139, 'shivashankar.zip', '1477034636', '49.204.7.252', '6hz5a1477034636'),
(140, 'smitha.zip', '1477034986', '49.204.7.252', 'XQbAS1477034986'),
(141, 'swarna.zip', '1477035002', '49.204.7.252', 'sbbdB1477035002'),
(142, 'Tanikella Bharani.zip', '1477035656', '49.204.7.252', 'z7Wx71477035656'),
(143, '15.zip', '1477036592', '49.204.7.252', 'A5RqH1477036592'),
(144, 'Satyam Rajesh.zip', '1477036642', '49.204.7.252', 'BpCz61477036642'),
(145, 'dream.zip', '1477037555', '49.204.7.252', 'Rixrs1477037555'),
(146, 'Vadde Naveen.zip', '1477037733', '49.204.7.252', 'Eoscj1477037733'),
(147, 'Gadde Rajendra Prasad.zip', '1477038776', '49.204.7.252', 'covjJ1477038776'),
(148, 'brahmaji.zip', '1477039569', '49.204.7.252', 'GwexY1477039569'),
(149, '16.zip', '1477042525', '49.204.7.252', 'G3zCn1477042525'),
(150, '17.zip', '1477042820', '49.204.7.252', 'bWw331477042820'),
(151, '7.zip', '1477042872', '49.204.7.252', 'mxCaB1477042872'),
(152, '18.zip', '1477043246', '49.204.7.252', 'Ma5Hf1477043246'),
(153, '19.zip', '1477043611', '49.204.7.252', 'HjJP11477043611'),
(154, '20.zip', '1477044193', '49.204.7.252', '6DNtf1477044193'),
(155, '21.zip', '1477044445', '49.204.7.252', 'kK8R11477044445'),
(156, '22.zip', '1477044650', '49.204.7.252', 'ViMpk1477044650'),
(157, '23.zip', '1477045025', '49.204.7.252', '9elxV1477045025'),
(158, '24.zip', '1477045320', '49.204.7.252', 'uunoC1477045320'),
(159, '1.zip', '1477045515', '49.204.7.252', 'YhAF51477045515'),
(160, '1.zip', '1477045692', '49.204.7.252', 'mE5M31477045692'),
(161, '25.zip', '1477045846', '49.204.7.252', 'wjjHN1477045846'),
(162, '2.zip', '1477046092', '49.204.7.252', 'AAGrT1477046092'),
(163, '26.zip', '1477046107', '49.204.7.252', 'r5oYZ1477046107'),
(164, '2.zip', '1477047349', '49.204.7.252', 'F9oGK1477047349'),
(165, '1.zip', '1477049642', '49.204.7.252', 'DyFkH1477049642'),
(166, '1.zip', '1477049932', '49.204.7.252', '5GLC21477049932'),
(167, '6.zip', '1477050137', '49.204.7.252', 'vluIf1477050137'),
(168, '5.zip', '1477050406', '49.204.7.252', 'QPyO31477050406'),
(169, '1.zip', '1477050858', '49.204.7.252', 'lNiGf1477050858'),
(170, '1.zip', '1477051354', '49.204.7.252', 'OHd8z1477051354'),
(171, '1.zip', '1477051789', '49.204.7.252', '8ZXTu1477051789'),
(172, '1.zip', '1477052149', '49.204.7.252', 'VwaJ61477052149'),
(173, '1.zip', '1477052685', '49.204.7.252', '2vwbo1477052685'),
(174, '1.zip', '1477053089', '49.204.7.252', 'rhDwr1477053089'),
(175, '1.zip', '1477053459', '49.204.7.252', 'lNDSc1477053459'),
(176, '1.zip', '1477053717', '49.204.7.252', 'dNArc1477053717'),
(177, '1.zip', '1477062588', '122.169.161.15', 'ccDkY1477062588'),
(178, '1.zip', '1477115847', '49.204.7.252', 'ITTSm1477115847'),
(179, '1.zip', '1477117363', '49.204.7.252', 'JcaMC1477117363'),
(180, '1.zip', '1477117752', '49.204.7.252', 'kRxq41477117752'),
(181, '1.zip', '1477118163', '49.204.7.252', 'a9wZp1477118163'),
(182, '1.zip', '1477119151', '49.204.7.252', 'AANLU1477119151'),
(183, '1.zip', '1477121347', '49.204.7.252', '6vpAB1477121347'),
(184, '1.zip', '1477121599', '49.204.7.252', 'icSHx1477121599'),
(185, '1.zip', '1477121871', '49.204.7.252', 'pNdR11477121871'),
(186, '1.zip', '1477122852', '49.204.7.252', '1zBFN1477122852'),
(187, '1.zip', '1477123100', '49.204.7.252', 'nMZWj1477123100'),
(188, '1.zip', '1477123868', '49.204.7.252', 'WquyI1477123868'),
(189, '1.zip', '1477124153', '49.204.7.252', 'ahqMh1477124153'),
(190, '1.zip', '1477124423', '49.204.7.252', '9dZL71477124423'),
(191, '1.zip', '1477124736', '49.204.7.252', 'zqtr51477124736'),
(192, '1.zip', '1477125611', '49.204.7.252', '2ZnIH1477125611'),
(193, '1.zip', '1477126101', '49.204.7.252', 'Ci44G1477126101'),
(194, '1.zip', '1477130603', '49.204.7.252', 'b6o5c1477130603'),
(195, '1.zip', '1477131502', '49.204.7.252', 'dm9jw1477131502'),
(196, '1.zip', '1477133263', '49.204.7.252', 'kN2XB1477133263'),
(197, '1.zip', '1477133973', '49.204.7.252', 'jmbty1477133973'),
(198, '1.zip', '1477134341', '49.204.7.252', 'NPghR1477134341'),
(199, '1.zip', '1477134586', '49.204.7.252', 'DyOfJ1477134586'),
(200, '1.zip', '1477134909', '49.204.7.252', 'eIoSb1477134909'),
(201, '1.zip', '1477135208', '49.204.7.252', '16vcN1477135208'),
(202, '1.zip', '1477135570', '49.204.7.252', 'VoNII1477135570'),
(203, '1.zip', '1477135881', '49.204.7.252', '0eKNO1477135881'),
(204, '1.zip', '1477136291', '49.204.7.252', 'fX4281477136291'),
(205, '1.zip', '1477136862', '49.204.7.252', 'Gk8EP1477136862'),
(206, '1.zip', '1477137318', '49.204.7.252', 'wybTa1477137318'),
(207, '1.zip', '1477139196', '49.204.7.252', 'MelD31477139196'),
(208, 'ny.zip', '1477277820', '43.249.226.82', 'L3Z0V1477277820'),
(209, '0.zip', '1477284449', '49.204.7.252', 'EbHwJ1477284449'),
(210, '1.zip', '1477284772', '49.204.7.252', '21n0i1477284772'),
(211, '1.zip', '1477285407', '49.204.7.252', 'n5zRi1477285407'),
(212, '1.zip', '1477285898', '49.204.7.252', 'ETGWa1477285898'),
(213, '1.zip', '1477287113', '49.204.7.252', 'QBMxR1477287113'),
(214, '27.zip', '1477287505', '49.204.7.252', 'Xjhl11477287505'),
(215, '1.zip', '1477287505', '49.204.7.252', 'oJzOQ1477287505'),
(216, '28.zip', '1477287929', '49.204.7.252', 'mO19f1477287929'),
(217, '1.zip', '1477288225', '49.204.7.252', 'gIiEc1477288225'),
(218, '29.zip', '1477288238', '49.204.7.252', 'IrjMi1477288238'),
(219, '30.zip', '1477288499', '49.204.7.252', 'vCjbO1477288499'),
(220, '1.zip', '1477288602', '49.204.7.252', 'Bn8Rf1477288602'),
(221, '30.zip', '1477288823', '49.204.7.252', 'mj2Oe1477288823'),
(222, '1.zip', '1477289191', '49.204.7.252', 'r6kqi1477289191'),
(223, '31.zip', '1477289331', '49.204.7.252', '2XUoU1477289331'),
(224, '1.zip', '1477289495', '49.204.7.252', 'ooYBL1477289495'),
(225, '32.zip', '1477289794', '49.204.7.252', 'PsLhu1477289794'),
(226, '33.zip', '1477290152', '49.204.7.252', 'lPdWO1477290152'),
(227, '34.zip', '1477290829', '49.204.7.252', 'cIDnu1477290829'),
(228, '35.zip', '1477291114', '49.204.7.252', 'Nur0S1477291114'),
(229, '1.zip', '1477291207', '49.204.7.252', 'UdaM31477291207'),
(230, '36.zip', '1477291255', '49.204.7.252', 'YHfqp1477291255'),
(231, '37.zip', '1477291639', '49.204.7.252', 'uh97C1477291639'),
(232, '1.zip', '1477291675', '49.204.7.252', 'jnJzt1477291675'),
(233, '1.zip', '1477292075', '49.204.7.252', 'QeGNn1477292075'),
(234, '38.zip', '1477292267', '49.204.7.252', 'muk2d1477292267'),
(235, '1.zip', '1477292613', '49.204.7.252', 'ldAFP1477292613'),
(236, '40.zip', '1477292882', '49.204.7.252', 'Dvovc1477292882'),
(237, '1.zip', '1477292918', '49.204.7.252', 'eTYri1477292918'),
(238, '41.zip', '1477293123', '49.204.7.252', 'FP18b1477293123'),
(239, '1.zip', '1477293134', '49.204.7.252', 'bAoSy1477293134'),
(240, '1.zip', '1477293767', '49.204.7.252', 'QJpDc1477293767'),
(241, '42.zip', '1477296079', '49.204.7.252', 'mot6X1477296079'),
(242, '44.zip', '1477299140', '49.204.7.252', '4qA1B1477299140'),
(243, '1.zip', '1477299689', '49.204.7.252', 'OvlY31477299689'),
(244, '45.zip', '1477299714', '49.204.7.252', 'mBLXo1477299714'),
(245, '1.zip', '1477299933', '49.204.7.252', 'NiT5f1477299933'),
(246, '46.zip', '1477300132', '49.204.7.252', 'Ysoly1477300132'),
(247, '1.zip', '1477300173', '49.204.7.252', 'q0SQf1477300173'),
(248, '47.zip', '1477300286', '49.204.7.252', 'dXmhc1477300286'),
(249, '48.zip', '1477300628', '49.204.7.252', 'NrR2f1477300628'),
(250, '49.zip', '1477300764', '49.204.7.252', 'H4Ehu1477300764'),
(251, '50.zip', '1477301224', '49.204.7.252', 'EGlAS1477301224'),
(252, '51.zip', '1477303140', '49.204.7.252', 'alhSH1477303140'),
(253, '51.zip', '1477303481', '49.204.7.252', '81Ds51477303481'),
(254, '52.zip', '1477303677', '49.204.7.252', '2SIAb1477303677'),
(255, '53.zip', '1477304240', '49.204.7.252', 'Ml3ci1477304240'),
(256, '54.zip', '1477304434', '49.204.7.252', 'iEL231477304434'),
(257, '55.zip', '1477304608', '49.204.7.252', '4Inag1477304608'),
(258, '56.zip', '1477304806', '49.204.7.252', 'vSoC61477304806'),
(259, '57.zip', '1477304974', '49.204.7.252', 'twmZQ1477304974'),
(260, '58.zip', '1477305127', '49.204.7.252', '7awQV1477305127'),
(261, '60.zip', '1477305357', '49.204.7.252', 'w9gHw1477305357'),
(262, '1.zip', '1477305396', '49.204.7.252', 'HSoTG1477305396'),
(263, '61.zip', '1477305674', '49.204.7.252', '87e9k1477305674'),
(264, '1.zip', '1477305720', '49.204.7.252', 'VAZLA1477305720'),
(265, '62.zip', '1477305948', '49.204.7.252', 't276C1477305948'),
(266, '1.zip', '1477306028', '49.204.7.252', 'ZtSti1477306028'),
(267, '63.zip', '1477306179', '49.204.7.252', 'UVDNX1477306179'),
(268, '1.zip', '1477306445', '49.204.7.252', 'HR6Is1477306445'),
(269, '64.zip', '1477306527', '49.204.7.252', 'LwlnT1477306527'),
(270, '65.zip', '1477306825', '49.204.7.252', 'p0JlA1477306825'),
(271, '1.zip', '1477306837', '49.204.7.252', 'SZtDb1477306837'),
(272, '1.zip', '1477307117', '49.204.7.252', 'wqUh91477307117'),
(273, '66.zip', '1477307145', '49.204.7.252', 'Bajc21477307145'),
(274, '1.zip', '1477307325', '49.204.7.252', 'LD1QH1477307325'),
(275, '67.zip', '1477307525', '49.204.7.252', 'oo9Hu1477307525'),
(276, '1.zip', '1477307615', '49.204.7.252', '2hzPJ1477307615'),
(277, '68.zip', '1477307777', '49.204.7.252', '9MIbu1477307777'),
(278, '1.zip', '1477307918', '49.204.7.252', 'px6Ga1477307918'),
(279, '1.zip', '1477308114', '49.204.7.252', 'vnx281477308114'),
(280, '70.zip', '1477374036', '49.204.7.252', 'fLn2I1477374036'),
(281, '71.zip', '1477374184', '49.204.7.252', 'ssv0k1477374184'),
(282, '1.zip', '1477374309', '49.204.7.252', 'G07Ro1477374309'),
(283, '72.zip', '1477374496', '49.204.7.252', 'wqHMG1477374496'),
(284, '1.zip', '1477374719', '49.204.7.252', 'Ipg4Z1477374719'),
(285, '73.zip', '1477374821', '49.204.7.252', 'PYSYt1477374821'),
(286, '1.zip', '1477375073', '49.204.7.252', 'MwNHY1477375073'),
(287, '74.zip', '1477375228', '49.204.7.252', 'MeBhC1477375228'),
(288, '75.zip', '1477375491', '49.204.7.252', 'FzadF1477375491'),
(289, '1.zip', '1477375667', '49.204.7.252', 'vZGst1477375667'),
(290, '1.zip', '1477376216', '49.204.7.252', '2eO391477376216'),
(291, '1.zip', '1477376716', '49.204.7.252', 'zLn0E1477376716'),
(292, '1.zip', '1477377129', '49.204.7.252', 'IscSv1477377129'),
(293, '1.zip', '1477377432', '49.204.7.252', 'BWwUh1477377432'),
(294, '1.zip', '1477377793', '49.204.7.252', 'mDgIW1477377793'),
(295, '76.zip', '1477378011', '49.204.7.252', 'XFRlS1477378011'),
(296, '1.zip', '1477378111', '49.204.7.252', 'Vpbik1477378111'),
(297, '1.zip', '1477378560', '49.204.7.252', 'FeEmv1477378560'),
(298, '77.zip', '1477378611', '49.204.7.252', '0hfl61477378611'),
(299, '1.zip', '1477378783', '49.204.7.252', 'dlMNH1477378783'),
(300, '78.zip', '1477378793', '49.204.7.252', 'DqY6I1477378793'),
(301, '79.zip', '1477378953', '49.204.7.252', 'MaVId1477378953'),
(302, '1.zip', '1477379081', '49.204.7.252', 'FHjan1477379081'),
(303, '80.zip', '1477379328', '49.204.7.252', 'LvAcg1477379328'),
(304, '1.zip', '1477379520', '49.204.7.252', 'mHYVE1477379520'),
(305, '81.zip', '1477379582', '49.204.7.252', 'q66351477379582'),
(306, '82.zip', '1477379793', '49.204.7.252', '8xx8F1477379793'),
(307, '1.zip', '1477380722', '49.204.7.252', 'LKUMc1477380722'),
(308, '1.zip', '1477381111', '49.204.7.252', 'by7O81477381111'),
(309, '1.zip', '1477381548', '49.204.7.252', 'ddQge1477381548'),
(310, '1.zip', '1477381885', '49.204.7.252', 'UEyJZ1477381885'),
(311, '83.zip', '1477390421', '49.204.7.252', 'RwlWA1477390421'),
(312, '84.zip', '1477390818', '49.204.7.252', 'tMOhd1477390818'),
(313, '85.zip', '1477390946', '49.204.7.252', '8Bx8C1477390946'),
(314, '86.zip', '1477391072', '49.204.7.252', 'rKju91477391072'),
(315, '87.zip', '1477391215', '49.204.7.252', 'mIBbt1477391215'),
(316, '88.zip', '1477391361', '49.204.7.252', 'HybUs1477391361'),
(317, '89.zip', '1477391467', '49.204.7.252', 'o0Ku21477391467'),
(318, '90.zip', '1477391607', '49.204.7.252', 'XBnFy1477391607'),
(319, '91.zip', '1477391727', '49.204.7.252', 'aHBTo1477391727'),
(320, '92.zip', '1477391858', '49.204.7.252', '0z3rh1477391858'),
(321, '93.zip', '1477392047', '49.204.7.252', 'wp6XF1477392047'),
(322, '94.zip', '1477392165', '49.204.7.252', 'xwSa61477392165'),
(323, '95.zip', '1477392498', '49.204.7.252', 'C9q0Y1477392498'),
(324, '96.zip', '1477460919', '49.204.7.252', 'bQNA01477460919'),
(325, '97.zip', '1477461055', '49.204.7.252', 'yMoov1477461055'),
(326, '98.zip', '1477461249', '49.204.7.252', 'nWKFj1477461249'),
(327, '99.zip', '1477461413', '49.204.7.252', '7Cirg1477461413'),
(328, '100.zip', '1477461551', '49.204.7.252', '53N251477461551'),
(329, '101.zip', '1477461729', '49.204.7.252', 'mhWJ21477461729'),
(330, '102.zip', '1477461872', '49.204.7.252', 'ah2BR1477461872'),
(331, '103.zip', '1477462087', '49.204.7.252', 'BfHR31477462087'),
(332, '104.zip', '1477462204', '49.204.7.252', 'aNeCh1477462204'),
(333, '105.zip', '1477462334', '49.204.7.252', '2WSFq1477462334'),
(334, '106.zip', '1477475134', '49.204.7.252', 'f6Op91477475134'),
(335, '107.zip', '1477475279', '49.204.7.252', 'pQvFn1477475279'),
(336, '108.zip', '1477475455', '49.204.7.252', 'cNHpG1477475455'),
(337, '109.zip', '1477475648', '49.204.7.252', 'FFjhm1477475648'),
(338, '110.zip', '1477475837', '49.204.7.252', 'yQ4ng1477475837'),
(339, '111.zip', '1477475930', '49.204.7.252', 'n9sxa1477475930'),
(340, '112.zip', '1477476057', '49.204.7.252', '5zjOY1477476057'),
(341, '113.zip', '1477476339', '49.204.7.252', 'nuTh31477476339'),
(342, '114.zip', '1477476574', '49.204.7.252', 'UdSaw1477476574'),
(343, '115.zip', '1477476712', '49.204.7.252', 'FLE3V1477476712'),
(344, '116.zip', '1477477921', '49.204.7.252', 'yRGVG1477477921'),
(345, '117.zip', '1477478057', '49.204.7.252', 'nUbrP1477478057'),
(346, '1.zip', '1477487433', '49.204.7.252', 'YgbTn1477487433'),
(347, '1.zip', '1477487668', '49.204.7.252', '8PiOE1477487668'),
(348, '1.zip', '1477487849', '49.204.7.252', 'Qn6tf1477487849'),
(349, '1.zip', '1477488080', '49.204.7.252', 'KpPoZ1477488080'),
(350, '6.zip', '1477539252', '49.204.7.252', 'n6EDE1477539252'),
(351, '877.zip', '1477539735', '49.204.7.252', 'iCsnK1477539735'),
(352, '7yy.zip', '1477539978', '49.204.7.252', 'heH3i1477539978'),
(353, 'bf.zip', '1477540531', '49.204.7.252', 'WSLoG1477540531'),
(354, 'jj.zip', '1477541028', '49.204.7.252', '8RGSQ1477541028'),
(355, 't.zip', '1477541326', '49.204.7.252', 'tFqBe1477541326'),
(356, 'k.zip', '1477541685', '49.204.7.252', 'uQ0gs1477541685'),
(357, 'j.zip', '1477542003', '49.204.7.252', 'CnfGG1477542003'),
(358, 'k.zip', '1477542312', '49.204.7.252', '6Z5iq1477542312'),
(359, 'te.zip', '1477542655', '49.204.7.252', 'XtSOB1477542655'),
(360, '118.zip', '1477543641', '49.204.7.252', 'SlYWe1477543641'),
(361, '119.zip', '1477543814', '49.204.7.252', 'qlusE1477543814'),
(362, 'l.zip', '1477543910', '49.204.7.252', 'FL81w1477543910'),
(363, '120.zip', '1477543992', '49.204.7.252', '8CT911477543992'),
(364, '121.zip', '1477544177', '49.204.7.252', 'GyCte1477544177'),
(365, '122.zip', '1477544303', '49.204.7.252', '9wC4v1477544303'),
(366, '123.zip', '1477544447', '49.204.7.252', 'UaZE91477544447'),
(367, 'k.zip', '1477544480', '49.204.7.252', 'eH3hq1477544480'),
(368, '124.zip', '1477544563', '49.204.7.252', 'ni67c1477544563'),
(369, '125.zip', '1477544736', '49.204.7.252', 'L4SzK1477544736'),
(370, 'i.zip', '1477544819', '49.204.7.252', 'LV70v1477544819'),
(371, '126.zip', '1477544901', '49.204.7.252', '9laeS1477544901'),
(372, '127.zip', '1477545017', '49.204.7.252', 'jJKJS1477545017'),
(373, '128.zip', '1477545266', '49.204.7.252', 'EVtRV1477545266'),
(374, 'k.zip', '1477545354', '49.204.7.252', 'Uu7XD1477545354'),
(375, '129.zip', '1477545410', '49.204.7.252', 'u5S311477545410'),
(376, 'i.zip', '1477545729', '49.204.7.252', 'oa7fa1477545729'),
(377, 'u.zip', '1477546748', '49.204.7.252', 'uHrii1477546748'),
(378, 'l.zip', '1477547071', '49.204.7.252', 'rRoRn1477547071'),
(379, 'r.zip', '1477547460', '49.204.7.252', 'UwI9t1477547460'),
(380, 'r.zip', '1477547717', '49.204.7.252', 'eATRU1477547717'),
(381, '130.zip', '1477548103', '49.204.7.252', '90moe1477548103'),
(382, '131.zip', '1477548221', '49.204.7.252', 'XswKc1477548221'),
(383, 'f.zip', '1477548294', '49.204.7.252', 'fLhKy1477548294'),
(384, '132.zip', '1477548357', '49.204.7.252', 'gIjFZ1477548357'),
(385, '133.zip', '1477548442', '49.204.7.252', 'irepR1477548442'),
(386, '134.zip', '1477548568', '49.204.7.252', 'S556I1477548568'),
(387, '135.zip', '1477548708', '49.204.7.252', 'C2d0t1477548708'),
(388, '135.zip', '1477548775', '49.204.7.252', 'a640h1477548775'),
(389, '136.zip', '1477548883', '49.204.7.252', 'rnkak1477548883'),
(390, '137.zip', '1477549093', '49.204.7.252', 'K6TFK1477549093'),
(391, '138.zip', '1477549267', '49.204.7.252', 'pdIlA1477549267'),
(392, '139.zip', '1477549414', '49.204.7.252', '9EEDu1477549414'),
(393, 't.zip', '1477549503', '49.204.7.252', 'leh4X1477549503'),
(394, '140.zip', '1477549674', '49.204.7.252', 'e9GgW1477549674'),
(395, '141.zip', '1477549782', '49.204.7.252', 'aIuL91477549782'),
(396, '142.zip', '1477549907', '49.204.7.252', 'XNfdY1477549907'),
(397, '143.zip', '1477550029', '49.204.7.252', '5RCwO1477550029'),
(398, 'o.zip', '1477550169', '49.204.7.252', 'VeZSE1477550169'),
(399, 'i.zip', '1477550458', '49.204.7.252', 'dX0A81477550458'),
(400, 'u.zip', '1477550935', '49.204.7.252', '7x4bp1477550935'),
(401, 'e.zip', '1477551248', '49.204.7.252', '9UiVC1477551248'),
(402, 's.zip', '1477551635', '49.204.7.252', 'QVPeZ1477551635'),
(403, 'j.zip', '1477551887', '49.204.7.252', 'x76VT1477551887'),
(404, '144.zip', '1477552038', '49.204.7.252', 'NDQz71477552038'),
(405, '145.zip', '1477552130', '49.204.7.252', 'QA5vk1477552130'),
(406, '146.zip', '1477552261', '49.204.7.252', 'bqFRv1477552261'),
(407, 'f.zip', '1477552337', '49.204.7.252', 'zZVPZ1477552337'),
(408, '147.zip', '1477552374', '49.204.7.252', '5VNSZ1477552374'),
(409, '148.zip', '1477552479', '49.204.7.252', 'EjGNl1477552479'),
(410, '149.zip', '1477552593', '49.204.7.252', 'TYzPO1477552593'),
(411, 'y.zip', '1477552623', '49.204.7.252', 'G5Qxk1477552623'),
(412, '150.zip', '1477552703', '49.204.7.252', '9SDAa1477552703'),
(413, '151.zip', '1477552865', '49.204.7.252', 'Fzy9x1477552865'),
(414, 'l.zip', '1477552868', '49.204.7.252', 'LeaiD1477552868'),
(415, '152.zip', '1477553044', '49.204.7.252', 'myq9s1477553044'),
(416, 'k.zip', '1477553159', '49.204.7.252', 'wV0xp1477553159'),
(417, '153.zip', '1477553204', '49.204.7.252', 'HPrBb1477553204'),
(418, '154.zip', '1477553364', '49.204.7.252', '2lBs41477553364'),
(419, 'k.zip', '1477553538', '49.204.7.252', 'ALP8F1477553538'),
(420, 'l.zip', '1477554846', '49.204.7.252', 'G87HF1477554846'),
(421, 'u.zip', '1477555317', '49.204.7.252', 'eiir41477555317'),
(422, '155.zip', '1477555712', '49.204.7.252', 'NQhEi1477555712'),
(423, '156.zip', '1477555831', '49.204.7.252', 'UaL2Q1477555831'),
(424, 'l.zip', '1477555880', '49.204.7.252', 'EtMKa1477555880'),
(425, '157.zip', '1477555926', '49.204.7.252', '5bIXP1477555926'),
(426, '158.zip', '1477556028', '49.204.7.252', 'oOTrn1477556028'),
(427, 'i.zip', '1477556271', '49.204.7.252', 'xnE8f1477556271'),
(428, '159.zip', '1477559435', '49.204.7.252', '8pL621477559435'),
(429, '160.zip', '1477559523', '49.204.7.252', 'S21F11477559523'),
(430, '161.zip', '1477559626', '49.204.7.252', 'UiUmc1477559626'),
(431, '162.zip', '1477561804', '49.204.7.252', 'aVzxK1477561804'),
(432, '163.zip', '1477561980', '49.204.7.252', 'ZBbFs1477561980'),
(433, '164.zip', '1477562186', '49.204.7.252', 'p80jR1477562186'),
(434, '165.zip', '1477562362', '49.204.7.252', 'u9UCy1477562362'),
(435, '166.zip', '1477562629', '49.204.7.252', 'Q7omQ1477562629'),
(436, '167.zip', '1477562834', '49.204.7.252', 'nb1hZ1477562834'),
(437, '2.zip', '1477564174', '49.204.7.252', 'DW4Vg1477564174'),
(438, '1.zip', '1477564446', '49.204.7.252', 'CcNjp1477564446'),
(439, '4.zip', '1477564724', '49.204.7.252', 'omc1q1477564724'),
(440, '5.zip', '1477565021', '49.204.7.252', 'Ocl2z1477565021'),
(441, '5.zip', '1477565339', '49.204.7.252', 'zgrQc1477565339'),
(442, '0.zip', '1477565618', '49.204.7.252', '0TTDA1477565618'),
(443, '168.zip', '1477565647', '49.204.7.252', 'qc8721477565647'),
(444, '169.zip', '1477565734', '49.204.7.252', 'DQwMS1477565734'),
(445, '170.zip', '1477565815', '49.204.7.252', 'l0gpv1477565815'),
(446, '171.zip', '1477565906', '49.204.7.252', 'AMwmy1477565906'),
(447, '172.zip', '1477566054', '49.204.7.252', 'oLkVd1477566054'),
(448, '173.zip', '1477566213', '49.204.7.252', '57WFz1477566213'),
(449, '8.zip', '1477567276', '49.204.7.252', 'vlVWe1477567276'),
(450, '174.zip', '1477567500', '49.204.7.252', 'yuQuF1477567500'),
(451, '175.zip', '1477567631', '49.204.7.252', 'L12P51477567631'),
(452, '176.zip', '1477567738', '49.204.7.252', 'syKNH1477567738'),
(453, '177.zip', '1477567908', '49.204.7.252', 'g4IB61477567908'),
(454, '178.zip', '1477570092', '49.204.7.252', 'uJ9511477570092'),
(455, '179.zip', '1477570237', '49.204.7.252', 'Bbbk81477570237'),
(456, '180.zip', '1477570428', '49.204.7.252', 'Im0FF1477570428'),
(457, '181.zip', '1477570683', '49.204.7.252', 'MA98P1477570683'),
(458, '182.zip', '1477570889', '49.204.7.252', '6LwJh1477570889'),
(459, '183.zip', '1477570991', '49.204.7.252', 'PhyKe1477570991'),
(460, '184.zip', '1477571170', '49.204.7.252', 'dSYgi1477571170'),
(461, '185.zip', '1477571303', '49.204.7.252', 'jQXXA1477571303'),
(462, '186.zip', '1477571569', '49.204.7.252', 'oSLPk1477571569'),
(463, '187.zip', '1477634988', '49.204.7.252', 'rm8fd1477634988'),
(464, '188.zip', '1477635147', '49.204.7.252', 'BTfqj1477635147'),
(465, '189.zip', '1477635321', '49.204.7.252', 'nkeQD1477635321'),
(466, '190.zip', '1477635509', '49.204.7.252', 'tSKEB1477635509'),
(467, '191.zip', '1477635632', '49.204.7.252', 'SrOvt1477635632'),
(468, '192.zip', '1477635895', '49.204.7.252', 'QExEu1477635895'),
(469, '193.zip', '1477636091', '49.204.7.252', 'rhvxU1477636091'),
(470, '194.zip', '1477636237', '49.204.7.252', 'xPuIZ1477636237'),
(471, '195.zip', '1477636435', '49.204.7.252', 'h8bqE1477636435'),
(472, '196.zip', '1477645117', '49.204.7.252', 'TZv9I1477645117'),
(473, '197.zip', '1477645277', '49.204.7.252', '1dex61477645277'),
(474, '198.zip', '1477645589', '49.204.7.252', 'mWgqy1477645589'),
(475, '199.zip', '1477645698', '49.204.7.252', '2onKI1477645698'),
(476, '200.zip', '1477645826', '49.204.7.252', 'fLoaF1477645826'),
(477, '201.zip', '1477646038', '49.204.7.252', 'iOpln1477646038'),
(478, '202.zip', '1477646278', '49.204.7.252', 'khI7U1477646278'),
(479, '203.zip', '1477646446', '49.204.7.252', 'VR8N51477646446'),
(480, '204.zip', '1477648334', '49.204.7.252', 'uZ0mv1477648334'),
(481, '205.zip', '1477648554', '49.204.7.252', 'T05Ep1477648554'),
(482, '206.zip', '1477648666', '49.204.7.252', 'LG8HM1477648666'),
(483, '207.zip', '1477648899', '49.204.7.252', 'gCgqN1477648899'),
(484, '208.zip', '1477649004', '49.204.7.252', 'eDi3N1477649004'),
(485, '209.zip', '1477649083', '49.204.7.252', 'PKoEi1477649083'),
(486, '210.zip', '1477649341', '49.204.7.252', 'Zs3vH1477649341'),
(487, '211.zip', '1477649496', '49.204.7.252', 'QabcB1477649496'),
(488, '212.zip', '1477649653', '49.204.7.252', 'niNlw1477649653'),
(489, '213.zip', '1477655444', '49.204.7.252', 'McBuY1477655444'),
(490, '214.zip', '1477655552', '49.204.7.252', '8kUXK1477655552'),
(491, '215.zip', '1477655816', '49.204.7.252', 'zZ2Yh1477655816'),
(492, '216.zip', '1477656027', '49.204.7.252', 'UteIP1477656027'),
(493, '217.zip', '1477656190', '49.204.7.252', 'fohRf1477656190'),
(494, '218.zip', '1477656399', '49.204.7.252', 'JkWIP1477656399'),
(495, '7.zip', '1477718332', '49.204.7.252', 'ybo6c1477718332'),
(496, '4.zip', '1477718724', '49.204.7.252', 'Yys3S1477718724'),
(497, '4.zip', '1477719050', '49.204.7.252', 'rOjTt1477719050'),
(498, '219.zip', '1477719240', '49.204.7.252', 'bTG4s1477719240'),
(499, '4.zip', '1477719369', '49.204.7.252', '2DstG1477719369'),
(500, '220.zip', '1477719430', '49.204.7.252', 'DSVNv1477719430'),
(501, '221.zip', '1477719626', '49.204.7.252', 'Cn2ss1477719626'),
(502, '5.zip', '1477719698', '49.204.7.252', '7LfhT1477719698'),
(503, '222.zip', '1477719776', '49.204.7.252', 'K5bmG1477719776'),
(504, '4.zip', '1477720047', '49.204.7.252', 'ZxRAS1477720047'),
(505, '223.zip', '1477720085', '49.204.7.252', 'Jw1ER1477720085'),
(506, '224.zip', '1477720282', '49.204.7.252', 'd1nPn1477720282'),
(507, '6.zip', '1477720445', '49.204.7.252', 'syWfK1477720445'),
(508, '225.zip', '1477720506', '49.204.7.252', 'JtbtW1477720506'),
(509, '6.zip', '1477720896', '49.204.7.252', 'eGhzs1477720896'),
(510, '6.zip', '1477721133', '49.204.7.252', '6irJ11477721133'),
(511, '6.zip', '1477721451', '49.204.7.252', 'SFVYs1477721451'),
(512, '226.zip', '1477721871', '49.204.7.252', 'VQlTs1477721871'),
(513, '6.zip', '1477721913', '49.204.7.252', 'Sd7yr1477721913'),
(514, '227.zip', '1477722009', '49.204.7.252', 't5h911477722009'),
(515, '228.zip', '1477722176', '49.204.7.252', 'yjx7Y1477722176'),
(516, '6.zip', '1477722185', '49.204.7.252', 'Sb2MJ1477722185'),
(517, '229.zip', '1477722303', '49.204.7.252', 'MF6iV1477722303'),
(518, '4.zip', '1477723100', '49.204.7.252', 'vYuKZ1477723100'),
(519, '0.zip', '1477723380', '49.204.7.252', 'vuIDc1477723380'),
(520, '230.zip', '1477723392', '49.204.7.252', 'eiVUY1477723392'),
(521, '2.zip', '1477723619', '49.204.7.252', 'h9z6e1477723619'),
(522, '231.zip', '1477723683', '49.204.7.252', 'haZV61477723683'),
(523, '2.zip', '1477724101', '49.204.7.252', 'QrppJ1477724101'),
(524, '232.zip', '1477724786', '49.204.7.252', 'Gd71i1477724786'),
(525, '233.zip', '1477724910', '49.204.7.252', 'zGLCW1477724910'),
(526, '234.zip', '1477725031', '49.204.7.252', '7hpZo1477725031'),
(527, '2.zip', '1477725307', '49.204.7.252', 'dkRiC1477725307'),
(528, '5.zip', '1477725669', '49.204.7.252', 'FrH0h1477725669'),
(529, '1.zip', '1477725881', '49.204.7.252', '6mJkm1477725881'),
(530, '235.zip', '1477725941', '49.204.7.252', 'JqKi51477725941'),
(531, '236.zip', '1477726024', '49.204.7.252', 'Jq85J1477726024'),
(532, '5.zip', '1477726116', '49.204.7.252', 'nfJGc1477726116'),
(533, '237.zip', '1477726211', '49.204.7.252', 'rU5qd1477726211'),
(534, '238.zip', '1477726400', '49.204.7.252', 'Ogq3f1477726400'),
(535, '239.zip', '1477728684', '49.204.7.252', 'ey3EP1477728684'),
(536, '240.zip', '1477728924', '49.204.7.252', 'D5Qmy1477728924'),
(537, '5.zip', '1477729975', '49.204.7.252', 'qhHAh1477729975'),
(538, '5.zip', '1477730682', '49.204.7.252', 'Ea0Dq1477730682'),
(539, '8.zip', '1477731002', '49.204.7.252', 'k4F8l1477731002'),
(540, '5.zip', '1477731339', '49.204.7.252', 'O9PhP1477731339'),
(541, '8.zip', '1477731753', '49.204.7.252', 'oC3eM1477731753'),
(542, '5.zip', '1477732360', '49.204.7.252', '465Ue1477732360'),
(543, '8.zip', '1477732717', '49.204.7.252', 'T6E081477732717'),
(544, '1.zip', '1477733685', '49.204.7.252', 'QQoCt1477733685'),
(545, '5.zip', '1477734117', '49.204.7.252', 'SrRJv1477734117'),
(546, '5.zip', '1477734390', '49.204.7.252', 'imKQ01477734390'),
(547, '8.zip', '1477734973', '49.204.7.252', 'vqJjG1477734973'),
(548, '8.zip', '1477735414', '49.204.7.252', 'W8YJM1477735414'),
(549, '7.zip', '1477735631', '49.204.7.252', 'COWps1477735631'),
(550, '9.zip', '1477735965', '49.204.7.252', 'vQVrJ1477735965'),
(551, 'y.zip', '1477736482', '49.204.7.252', 'y0piX1477736482'),
(552, 'v.zip', '1477737122', '49.204.7.252', 'GLIHm1477737122'),
(553, '1.zip', '1477740886', '49.204.7.252', 'Jgjub1477740886'),
(554, '2.zip', '1477887998', '49.204.7.252', 'T8oyZ1477887998'),
(555, 'c.zip', '1477888255', '49.204.7.252', 'pPWOg1477888255'),
(556, 'b.zip', '1477888551', '49.204.7.252', 'sici71477888551'),
(557, 'v.zip', '1477889223', '49.204.7.252', '8tnCp1477889223'),
(558, '9.zip', '1477890527', '49.204.7.252', 'lcIUq1477890527'),
(559, '4.zip', '1477890804', '49.204.7.252', '8VcmZ1477890804'),
(560, '4.zip', '1477891791', '49.204.7.252', 'NenyB1477891791'),
(561, 'b.zip', '1477892233', '49.204.7.252', 'bX9tR1477892233'),
(562, 'm.zip', '1477892477', '49.204.7.252', '6cXv91477892477'),
(563, '8.zip', '1477892853', '49.204.7.252', 'tLO981477892853'),
(564, 'j.zip', '1477893213', '49.204.7.252', 'eL5pY1477893213'),
(565, '232.zip', '1477893947', '49.204.7.252', '2cOSF1477893947'),
(566, '9.zip', '1477894011', '49.204.7.252', 'XT08G1477894011'),
(567, '233.zip', '1477894136', '49.204.7.252', 'ITeZb1477894136'),
(568, '7.zip', '1477894288', '49.204.7.252', 'saXAf1477894288'),
(569, '234.zip', '1477894290', '49.204.7.252', 'Vfqkx1477894290'),
(570, '8.zip', '1477894701', '49.204.7.252', '7tXR11477894701'),
(571, '235.zip', '1477894736', '49.204.7.252', '4whRq1477894736'),
(572, '236.zip', '1477894859', '49.204.7.252', 'k4EDu1477894859'),
(573, '237.zip', '1477894970', '49.204.7.252', 'BGrgI1477894970'),
(574, '8.zip', '1477895101', '49.204.7.252', 'agC4s1477895101'),
(575, '238.zip', '1477895243', '49.204.7.252', 'O9Jjy1477895243'),
(576, '239.zip', '1477895349', '49.204.7.252', 'oNDvI1477895349'),
(577, '240.zip', '1477895528', '49.204.7.252', 'Ur3y11477895528'),
(578, '8.zip', '1477895579', '49.204.7.252', 'KV3Y01477895579'),
(579, '241.zip', '1477895648', '49.204.7.252', 'yYSPz1477895648'),
(580, '242.zip', '1477895793', '49.204.7.252', 'jOpPq1477895793'),
(581, '5.zip', '1477896249', '49.204.7.252', 'tSCca1477896249'),
(582, '5.zip', '1477896606', '49.204.7.252', '1UJ221477896606'),
(583, '1.zip', '1477896924', '49.204.7.252', 'rAUFm1477896924'),
(584, '0.zip', '1477897566', '49.204.7.252', 'Tozm71477897566'),
(585, '11.zip', '1477897996', '49.204.7.252', 'T3Rgw1477897996'),
(586, 'z.zip', '1477899628', '49.204.7.252', 'slxu21477899628'),
(587, '243.zip', '1477900737', '49.204.7.252', '0sjMr1477900737'),
(588, '244.zip', '1477900910', '49.204.7.252', 'RuHZF1477900910'),
(589, '245.zip', '1477901095', '49.204.7.252', 'qgssY1477901095'),
(590, '246.zip', '1477901289', '49.204.7.252', 'oIDOt1477901289'),
(591, '247.zip', '1477901642', '49.204.7.252', 'ufYLQ1477901642'),
(592, '248.zip', '1477901897', '49.204.7.252', 'PPLx31477901897'),
(593, '249.zip', '1477902031', '49.204.7.252', 'VdipL1477902031'),
(594, '250.zip', '1477902107', '49.204.7.252', 'vC4H81477902107'),
(595, '251.zip', '1477902244', '49.204.7.252', 'XJgTw1477902244'),
(596, '252.zip', '1477902484', '49.204.7.252', 'boatj1477902484'),
(597, '5.zip', '1477903031', '49.204.7.252', 'OsHoC1477903031'),
(598, '5.zip', '1477903590', '49.204.7.252', 'ik0FD1477903590'),
(599, '0.zip', '1477903936', '49.204.7.252', 'gH4qg1477903936'),
(600, '2.zip', '1477904412', '49.204.7.252', 'dfpKX1477904412'),
(601, '0.zip', '1477905139', '49.204.7.252', 'nPGa11477905139'),
(602, '6.zip', '1477978806', '49.204.7.252', 'JLhSz1477978806'),
(603, 'k.zip', '1477979628', '49.204.7.252', 'cGdWn1477979628'),
(604, '253.zip', '1477979665', '49.204.7.252', 'GE2co1477979665'),
(605, '254.zip', '1477979779', '49.204.7.252', 'e3OTd1477979779'),
(606, '255.zip', '1477979907', '49.204.7.252', 'l09xT1477979907'),
(607, 'p.zip', '1477980600', '49.204.7.252', 'DGrz61477980600'),
(608, '5.zip', '1477981813', '49.204.7.252', 'jjNE31477981813'),
(609, '4.zip', '1477982259', '49.204.7.252', 'YriB31477982259'),
(610, 'h.zip', '1477982596', '49.204.7.252', '5gXoe1477982596'),
(611, '256.zip', '1477983556', '49.204.7.252', 'pVHMu1477983556'),
(612, '257.zip', '1477983756', '49.204.7.252', '59xBq1477983756'),
(613, '258.zip', '1477983865', '49.204.7.252', '6JmDu1477983865'),
(614, '258.zip', '1477983937', '49.204.7.252', 'jETT41477983937'),
(615, '259.zip', '1477984046', '49.204.7.252', 'nh0y71477984046'),
(616, '260.zip', '1477984209', '49.204.7.252', '7FHAW1477984209'),
(617, 'kl.zip', '1477984341', '49.204.7.252', 'trqV31477984341'),
(618, '261.zip', '1477984402', '49.204.7.252', 'lOjX81477984402'),
(619, '262.zip', '1477984527', '49.204.7.252', 'tSafa1477984527'),
(620, '263.zip', '1477984738', '49.204.7.252', 'hicPt1477984738'),
(621, '264.zip', '1477984863', '49.204.7.252', 'WTQM31477984863'),
(622, '265.zip', '1477984983', '49.204.7.252', 'UHiFb1477984983'),
(623, '266.zip', '1477985150', '49.204.7.252', '0TmyP1477985150'),
(624, '267.zip', '1477985287', '49.204.7.252', 'j164x1477985287'),
(625, '268.zip', '1477985441', '49.204.7.252', 'XBHD21477985441'),
(626, '3.zip', '1477985628', '49.204.7.252', 'OVbfA1477985628'),
(627, '6.zip', '1477986672', '49.204.7.252', 'hWqmU1477986672'),
(628, '2.zip', '1477987164', '49.204.7.252', 'TZ9UM1477987164'),
(629, 'h.zip', '1477987393', '49.204.7.252', 'QA2PS1477987393'),
(630, '2.zip', '1477987920', '49.204.7.252', 'pUW0m1477987920'),
(631, '0.zip', '1477992112', '49.204.7.252', 'ujysn1477992112'),
(632, 't.zip', '1477992448', '49.204.7.252', 'S6itf1477992448'),
(633, '1.zip', '1477992671', '49.204.7.252', 'NNGWO1477992671'),
(634, '4.zip', '1477992899', '49.204.7.252', 'xmOg51477992899'),
(635, '269.zip', '1477992927', '49.204.7.252', 'cofo31477992927'),
(636, '270.zip', '1477993060', '49.204.7.252', 'A0IRm1477993060'),
(637, 'g.zip', '1477993260', '49.204.7.252', 'hh0rG1477993260'),
(638, '4.zip', '1477993515', '49.204.7.252', 'pEbGH1477993515'),
(639, '44.zip', '1477993827', '49.204.7.252', 'bcj3y1477993827'),
(640, '4.zip', '1477995627', '49.204.7.252', 'ddgaC1477995627'),
(641, 'j.zip', '1477996036', '49.204.7.252', 'ujj3M1477996036'),
(642, '4.zip', '1477996247', '49.204.7.252', 'vGE7Y1477996247'),
(643, 'j.zip', '1477996544', '49.204.7.252', 'taMqm1477996544'),
(644, 'k.zip', '1477997058', '49.204.7.252', '6EsS11477997058'),
(645, 'l.zip', '1477997408', '49.204.7.252', 'wshJi1477997408'),
(646, '271.zip', '1477997657', '49.204.7.252', 'MSLgQ1477997657'),
(647, 'l.zip', '1477997662', '49.204.7.252', 'vVkFO1477997662'),
(648, '272.zip', '1477997799', '49.204.7.252', 'Goxcd1477997799'),
(649, '273.zip', '1477998020', '49.204.7.252', 'oLh5M1477998020'),
(650, '274.zip', '1477998148', '49.204.7.252', '6bqN61477998148'),
(651, '275.zip', '1477999919', '49.204.7.252', 'phdrg1477999919'),
(652, '276.zip', '1477999998', '49.204.7.252', '8DLWd1477999998'),
(653, '277.zip', '1478001091', '49.204.7.252', 'XbRA71478001091'),
(654, '278.zip', '1478001177', '49.204.7.252', '9ERq01478001177'),
(655, '279.zip', '1478001293', '49.204.7.252', '0lgbh1478001293'),
(656, '280.zip', '1478001490', '49.204.7.252', 'G4yS91478001490'),
(657, '5.zip', '1478001614', '49.204.7.252', 'iWAYM1478001614'),
(658, 'b.zip', '1478001838', '49.204.7.252', 'DQYff1478001838'),
(659, '281.zip', '1478002024', '49.204.7.252', 'jIMEs1478002024'),
(660, 'n.zip', '1478002115', '49.204.7.252', 'cOKkf1478002115'),
(661, '282.zip', '1478002353', '49.204.7.252', 'DX5xs1478002353'),
(662, '5.zip', '1478002399', '49.204.7.252', '5BbtN1478002399'),
(663, '1.zip', '1478002672', '49.204.7.252', 'xC5iy1478002672'),
(664, '283.zip', '1478066707', '49.204.7.252', 'TpVbX1478066707'),
(665, '1.zip', '1478066946', '49.204.7.252', '7UWVO1478066946'),
(666, '284.zip', '1478066971', '49.204.7.252', 'LHeVh1478066971'),
(667, '285.zip', '1478067077', '49.204.7.252', 'DVOTj1478067077'),
(668, '286.zip', '1478067342', '49.204.7.252', '1KRCh1478067342'),
(669, '287.zip', '1478067461', '49.204.7.252', '0dEFa1478067461'),
(670, '288.zip', '1478067596', '49.204.7.252', 'TJXWp1478067596'),
(671, '289.zip', '1478067712', '49.204.7.252', '0K12v1478067712'),
(672, '290.zip', '1478067827', '49.204.7.252', 'vZIIu1478067827'),
(673, ',.rar', '1478068176', '49.204.7.252', 'wi2Ai1478068176'),
(674, 'k.zip', '1478068758', '49.204.7.252', '7UFSJ1478068758'),
(675, '2.zip', '1478069117', '49.204.7.252', 'BWvnc1478069117'),
(676, '291.zip', '1478069913', '49.204.7.252', 'KB5ld1478069913'),
(677, '292.zip', '1478070023', '49.204.7.252', 'IhhHK1478070023'),
(678, '293.zip', '1478070116', '49.204.7.252', '2cFlV1478070116'),
(679, '294.zip', '1478070426', '49.204.7.252', 'qRCgH1478070426'),
(680, '295.zip', '1478070707', '49.204.7.252', 'pGLgc1478070707'),
(681, '5.zip', '1478071072', '49.204.7.252', '2ioxM1478071072'),
(682, 'l.zip', '1478071437', '49.204.7.252', 'C3Mcw1478071437'),
(683, 'k.zip', '1478071676', '49.204.7.252', 'lCvyA1478071676'),
(684, 'm.zip', '1478071899', '49.204.7.252', 'Xqhzp1478071899'),
(685, '4.zip', '1478072479', '49.204.7.252', 'g0N6n1478072479'),
(686, '296.zip', '1478072646', '49.204.7.252', '4hTb31478072646'),
(687, '297.zip', '1478072747', '49.204.7.252', 'ViJj61478072747'),
(688, '4.zip', '1478072930', '49.204.7.252', 'V3xIw1478072930'),
(689, '298.zip', '1478072962', '49.204.7.252', 'hkwgI1478072962'),
(690, '299.zip', '1478074044', '49.204.7.252', 'ux9Lu1478074044'),
(691, '300.zip', '1478074236', '49.204.7.252', 'TAJUs1478074236'),
(692, '5.zip', '1478074282', '49.204.7.252', 'eyZRe1478074282'),
(693, 'k.zip', '1478080682', '49.204.7.252', 'AOqWh1478080682'),
(694, '301.zip', '1478081189', '49.204.7.252', 'UE4hr1478081189'),
(695, '302.zip', '1478081347', '49.204.7.252', '8dhkB1478081347'),
(696, '303.zip', '1478081434', '49.204.7.252', 'yiKvi1478081434'),
(697, '2.zip', '1478081459', '49.204.7.252', 'FFXbq1478081459'),
(698, '304.zip', '1478081523', '49.204.7.252', 'ZM9bx1478081523'),
(699, '2.zip', '1478081737', '49.204.7.252', 'Ne8fF1478081737'),
(700, '305.zip', '1478081894', '49.204.7.252', 'oFwo91478081894'),
(701, '306.zip', '1478082005', '49.204.7.252', 'a4rm51478082005'),
(702, 'l.zip', '1478082059', '49.204.7.252', 'yMJrH1478082059'),
(703, '307.zip', '1478082071', '49.204.7.252', 'EBYkG1478082071'),
(704, '308.zip', '1478082214', '49.204.7.252', 'ZLEPd1478082214'),
(705, '309.zip', '1478082381', '49.204.7.252', 'ub1LX1478082381'),
(706, 'h.zip', '1478082468', '49.204.7.252', '8rRqO1478082468'),
(707, '310.zip', '1478082493', '49.204.7.252', '2xgNP1478082493'),
(708, '311.zip', '1478082592', '49.204.7.252', 'GOuSW1478082592'),
(709, 'j.zip', '1478083147', '49.204.7.252', 'vctDi1478083147'),
(710, '312.zip', '1478084005', '49.204.7.252', '2Xibc1478084005'),
(711, '313.zip', '1478084129', '49.204.7.252', 'dXCRg1478084129'),
(712, '314.zip', '1478084233', '49.204.7.252', 'fqvel1478084233'),
(713, '315.zip', '1478084337', '49.204.7.252', 'DtGQb1478084337'),
(714, '316.zip', '1478084472', '49.204.7.252', 'FNpLT1478084472'),
(715, '317.zip', '1478084600', '49.204.7.252', 'Cghx21478084600'),
(716, '318.zip', '1478084705', '49.204.7.252', 'yNLUz1478084705'),
(717, '319.zip', '1478084810', '49.204.7.252', 'rByij1478084810'),
(718, '320.zip', '1478084938', '49.204.7.252', 'l15lM1478084938'),
(719, '321.zip', '1478149338', '49.204.7.252', 'M1TeG1478149338'),
(720, '322.zip', '1478149566', '49.204.7.252', 'RcjvZ1478149566'),
(721, '323.zip', '1478149694', '49.204.7.252', 'CQEsv1478149694'),
(722, '324.zip', '1478149820', '49.204.7.252', 'O0c4l1478149820'),
(723, '325.zip', '1478149939', '49.204.7.252', 'NdNAk1478149939'),
(724, '326.zip', '1478150048', '49.204.7.252', 'AeU3f1478150048'),
(725, '327.zip', '1478150168', '49.204.7.252', 'rXSpX1478150168'),
(726, '328.zip', '1478150473', '49.204.7.252', 'mipS61478150473'),
(727, '329.zip', '1478150595', '49.204.7.252', 'YoE721478150595'),
(728, '330.zip', '1478150722', '49.204.7.252', 'UNqVw1478150722'),
(729, '331.zip', '1478150846', '49.204.7.252', '2RJ1f1478150846'),
(730, '332.zip', '1478150973', '49.204.7.252', 'lqhqN1478150973'),
(731, '333.zip', '1478151055', '49.204.7.252', 'MqXNt1478151055'),
(732, '334.zip', '1478151188', '49.204.7.252', 'OD3741478151188'),
(733, '335.zip', '1478151332', '49.204.7.252', 'pNox41478151332'),
(734, '335.zip', '1478151374', '49.204.7.252', 'A120i1478151374'),
(735, '336.zip', '1478155556', '49.204.7.252', 'tSi7A1478155556'),
(736, '337.zip', '1478155700', '49.204.7.252', '5XM1h1478155700'),
(737, '338.zip', '1478155950', '49.204.7.252', 'gEZLj1478155950'),
(738, '339.zip', '1478156056', '49.204.7.252', 'OKJ0Q1478156056'),
(739, '340.zip', '1478157218', '49.204.7.252', 'rgbE61478157218'),
(740, '341.zip', '1478157323', '49.204.7.252', 'ACLuJ1478157323'),
(741, '342.zip', '1478157415', '49.204.7.252', 'PLVCY1478157415'),
(742, '343.zip', '1478157526', '49.204.7.252', 'biz9Z1478157526'),
(743, '344.zip', '1478157627', '49.204.7.252', 'S0NEa1478157627'),
(744, '345.zip', '1478157710', '49.204.7.252', 'Gl99x1478157710'),
(745, '346.zip', '1478157823', '49.204.7.252', 'lCj6I1478157823'),
(746, '347.zip', '1478157918', '49.204.7.252', 'DoJEG1478157918'),
(747, '348.zip', '1478158011', '49.204.7.252', '4MwWq1478158011'),
(748, '349.zip', '1478158128', '49.204.7.252', 'VSPmB1478158128'),
(749, '350.zip', '1478158268', '49.204.7.252', 'swo9Z1478158268'),
(750, '351.zip', '1478158367', '49.204.7.252', 'lUsS11478158367'),
(751, '352.zip', '1478158487', '49.204.7.252', 'qQr0A1478158487'),
(752, '353.zip', '1478158662', '49.204.7.252', 'bqgoN1478158662'),
(753, '354.zip', '1478158774', '49.204.7.252', 'NOxh41478158774'),
(754, '4.zip', '1478158844', '49.204.7.252', 'qz23o1478158844'),
(755, '1.zip', '1478159445', '49.204.7.252', 'zNYQM1478159445'),
(756, '5.zip', '1478160370', '49.204.7.252', 'qpu1U1478160370'),
(757, '355.zip', '1478162134', '49.204.7.252', '3xIpC1478162134'),
(758, '356.zip', '1478162224', '49.204.7.252', 'cAEnH1478162224'),
(759, '357.zip', '1478162333', '49.204.7.252', 'Snad21478162333'),
(760, '358.zip', '1478162414', '49.204.7.252', '3UraC1478162414'),
(761, '359.zip', '1478162692', '49.204.7.252', 'a1v2r1478162692'),
(762, '360.zip', '1478166048', '49.204.7.252', 'eeMJE1478166048'),
(763, '361.zip', '1478166153', '49.204.7.252', 'Ux99R1478166153'),
(764, '362.zip', '1478166244', '49.204.7.252', 'xAyyb1478166244'),
(765, '363.zip', '1478166367', '49.204.7.252', 'REf7t1478166367'),
(766, 'l.zip', '1478166402', '49.204.7.252', 'hJI0O1478166402'),
(767, '364.zip', '1478166502', '49.204.7.252', 'wPy6o1478166502'),
(768, '365.zip', '1478166826', '49.204.7.252', '00nM11478166826'),
(769, '366.zip', '1478167040', '49.204.7.252', '3kPLf1478167040');
INSERT INTO `files` (`FID`, `fname`, `time`, `ip`, `s`) VALUES
(770, '367.zip', '1478167149', '49.204.7.252', 'GyX6j1478167149'),
(771, '368.zip', '1478169026', '49.204.7.252', 'L000Q1478169026'),
(772, '369.zip', '1478169726', '49.204.7.252', '8zpkx1478169726'),
(773, '370.zip', '1478170316', '49.204.7.252', 'yPjpK1478170316'),
(774, '371.zip', '1478170424', '49.204.7.252', 'DflZm1478170424'),
(775, 'v.zip', '1478170504', '49.204.7.252', 'nubGM1478170504'),
(776, '372.zip', '1478170544', '49.204.7.252', 'Xvqk91478170544'),
(777, '1.zip', '1478171573', '49.204.7.252', '7wZxu1478171573'),
(778, '5.zip', '1478172076', '49.204.7.252', 'ZIt531478172076'),
(779, '373.zip', '1478239381', '49.204.7.252', 'BeLLS1478239381'),
(780, '374.zip', '1478239515', '49.204.7.252', 'uIH3j1478239515'),
(781, '375.zip', '1478239621', '49.204.7.252', 'mTJCJ1478239621'),
(782, '376.zip', '1478242315', '49.204.7.252', 'Nn6jB1478242315'),
(783, '377.zip', '1478243321', '49.204.7.252', 'oCx3Z1478243321'),
(784, '378.zip', '1478244850', '49.204.7.252', '9FCrT1478244850'),
(785, '379.zip', '1478244963', '49.204.7.252', 'L3Dtt1478244963'),
(786, '380.zip', '1478245081', '49.204.7.252', 'WIANW1478245081'),
(787, '381.zip', '1478245270', '49.204.7.252', 'JwCH91478245270'),
(788, '382.zip', '1478245362', '49.204.7.252', 'thJLo1478245362'),
(789, '383.zip', '1478245497', '49.204.7.252', 'qyK0q1478245497'),
(790, '384.zip', '1478256273', '49.204.7.252', 'MAr551478256273'),
(791, '385.zip', '1478256488', '49.204.7.252', 'MQrCJ1478256488'),
(792, '386.zip', '1478256562', '49.204.7.252', 'n9ZZ11478256562'),
(793, '387.zip', '1478256649', '49.204.7.252', 'oSL451478256649'),
(794, '388.zip', '1478256840', '49.204.7.252', 'vHVYp1478256840'),
(795, '389.zip', '1478256935', '49.204.7.252', 'crI3J1478256935'),
(796, '390.zip', '1478257008', '49.204.7.252', 'RTEoG1478257008'),
(797, '391.zip', '1478257096', '49.204.7.252', 'QqTIj1478257096'),
(798, '392.zip', '1478257220', '49.204.7.252', 'TEV1y1478257220'),
(799, '393.zip', '1478257312', '49.204.7.252', 'uiBRZ1478257312'),
(800, '394.zip', '1478257451', '49.204.7.252', 'y0caH1478257451'),
(801, '395.zip', '1478257543', '49.204.7.252', 'dBvkR1478257543'),
(802, '396.zip', '1478257671', '49.204.7.252', 'KoH5S1478257671'),
(803, '397.zip', '1478257771', '49.204.7.252', 'G6Hki1478257771'),
(804, '398.zip', '1478257871', '49.204.7.252', '5NDia1478257871'),
(805, '399.zip', '1478258007', '49.204.7.252', '2B4101478258007'),
(806, '400.zip', '1478260844', '49.204.7.252', 'zQK591478260844'),
(807, '401.zip', '1478260959', '49.204.7.252', 'e3n7a1478260959'),
(808, '402.zip', '1478261035', '49.204.7.252', 'ZjutA1478261035'),
(809, '403.zip', '1478261135', '49.204.7.252', 'k1b6i1478261135'),
(810, '404.zip', '1478261232', '49.204.7.252', 'MpN891478261232'),
(811, '405.zip', '1478261316', '49.204.7.252', '3Hyrs1478261316'),
(812, '406.zip', '1478261445', '49.204.7.252', 'k9ChR1478261445'),
(813, '406.zip', '1478261517', '49.204.7.252', 'y7LI41478261517'),
(814, '406.zip', '1478261553', '49.204.7.252', 'FZw6Z1478261553'),
(815, '407.zip', '1478261652', '49.204.7.252', 'HaL4E1478261652'),
(816, '408.zip', '1478261748', '49.204.7.252', 'a6hk11478261748'),
(817, '409.zip', '1478261864', '49.204.7.252', 'g2YmS1478261864'),
(818, '410.zip', '1478261996', '49.204.7.252', 'tk7gY1478261996'),
(819, '411.zip', '1478262224', '49.204.7.252', 'pxtXq1478262224'),
(820, '412.zip', '1478262305', '49.204.7.252', 'PY8am1478262305'),
(821, '413.zip', '1478262425', '49.204.7.252', '1wcQ21478262425'),
(822, '414.zip', '1478324691', '49.204.7.252', 'jLiCj1478324691'),
(823, '415.zip', '1478324943', '49.204.7.252', 'PyR2n1478324943'),
(824, '416.zip', '1478325053', '49.204.7.252', 'd1lEo1478325053'),
(825, '417.zip', '1478325185', '49.204.7.252', 'w8nQN1478325185'),
(826, '418.zip', '1478325271', '49.204.7.252', 'jWYKB1478325271'),
(827, '419.zip', '1478325396', '49.204.7.252', '5Eg5U1478325396'),
(828, '420.zip', '1478325487', '49.204.7.252', 'oZqWa1478325487'),
(829, '421.zip', '1478325618', '49.204.7.252', 'GcN5M1478325618'),
(830, '422.zip', '1478327671', '49.204.7.252', 'C2hG41478327671'),
(831, '423.zip', '1478327792', '49.204.7.252', 'kbm6n1478327792'),
(832, '424.zip', '1478327888', '49.204.7.252', 'EsWin1478327888'),
(833, '425.zip', '1478328004', '49.204.7.252', 'sPmHC1478328004'),
(834, '425.zip', '1478329169', '49.204.7.252', '4va7u1478329169'),
(835, '426.zip', '1478329295', '49.204.7.252', 'nYlTq1478329295'),
(836, '427.zip', '1478329391', '49.204.7.252', 'wiyCo1478329391'),
(837, '428.zip', '1478329478', '49.204.7.252', 'vjnjT1478329478'),
(838, '429.zip', '1478329595', '49.204.7.252', '0Mkbp1478329595'),
(839, '430.zip', '1478329673', '49.204.7.252', 'k13Br1478329673'),
(840, '431.zip', '1478339713', '49.204.7.252', 'oO7iW1478339713'),
(841, '432.zip', '1478340160', '49.204.7.252', 'GWJvN1478340160'),
(842, '433.zip', '1478340244', '49.204.7.252', 'G0s8u1478340244'),
(843, '434.zip', '1478340325', '49.204.7.252', 'ulSkl1478340325'),
(844, '435.zip', '1478340406', '49.204.7.252', 'Vh64G1478340406'),
(845, '436.zip', '1478340490', '49.204.7.252', 'I0Oxp1478340490'),
(846, '437.zip', '1478340575', '49.204.7.252', 'dlfqT1478340575'),
(847, '438.zip', '1478340741', '49.204.7.252', 'o7Hgx1478340741'),
(848, '439.zip', '1478340915', '49.204.7.252', 'PVg3l1478340915'),
(849, '440.zip', '1478341022', '49.204.7.252', 'oK4Fk1478341022'),
(850, '441.zip', '1478344365', '49.204.7.252', '9DvyQ1478344365'),
(851, '442.zip', '1478344425', '49.204.7.252', 'zzllp1478344425'),
(852, '443.zip', '1478344543', '49.204.7.252', 'pu3mu1478344543'),
(853, '444.zip', '1478344724', '49.204.7.252', 'Ovb5V1478344724'),
(854, '445.zip', '1478344959', '49.204.7.252', 'rQrh01478344959'),
(855, '446.zip', '1478345050', '49.204.7.252', '1AbSp1478345050'),
(856, '447.zip', '1478346964', '49.204.7.252', 'GzWdR1478346964'),
(857, '448.zip', '1478347055', '49.204.7.252', 'BOWIn1478347055'),
(858, '449.zip', '1478347117', '49.204.7.252', 'FxRT41478347117'),
(859, '450.zip', '1478347188', '49.204.7.252', 'JyrpP1478347188'),
(860, '451.zip', '1478347283', '49.204.7.252', '8bGVG1478347283'),
(861, '452.zip', '1478347364', '49.204.7.252', 'pMuCx1478347364'),
(862, '2.zip', '1478499995', '49.204.7.252', 'RmKjW1478499995'),
(863, '5.zip', '1478500351', '49.204.7.252', 'Jor0U1478500351'),
(864, '453.zip', '1478500583', '49.204.7.252', 'ur0RM1478500583'),
(865, 'k.zip', '1478500664', '49.204.7.252', 'JMqvM1478500664'),
(866, '454.zip', '1478500677', '49.204.7.252', 'KKpUV1478500677'),
(867, '455.zip', '1478500822', '49.204.7.252', '1ZWs51478500822'),
(868, '456.zip', '1478500884', '49.204.7.252', '48N6a1478500884'),
(869, '457.zip', '1478500968', '49.204.7.252', '2mVfD1478500968'),
(870, '458.zip', '1478501116', '49.204.7.252', 'VnAkI1478501116'),
(871, '459.zip', '1478501234', '49.204.7.252', 'wbXLL1478501234'),
(872, '460.zip', '1478501328', '49.204.7.252', 'Qzt4Y1478501328'),
(873, '461.zip', '1478501433', '49.204.7.252', 'xpEZr1478501433'),
(874, '462.zip', '1478501526', '49.204.7.252', 'a82vf1478501526'),
(875, 'l.zip', '1478503293', '49.204.7.252', 'FZLdn1478503293'),
(876, '4.zip', '1478504174', '49.204.7.252', 'jr8u81478504174'),
(877, '463.zip', '1478504237', '49.204.7.252', 'MeeVl1478504237'),
(878, '464.zip', '1478504353', '49.204.7.252', 'ZOfbu1478504353'),
(879, '465.zip', '1478504445', '49.204.7.252', 'XcKnn1478504445'),
(880, '466.zip', '1478504563', '49.204.7.252', 'jpQ5Z1478504563'),
(881, '467.zip', '1478504666', '49.204.7.252', 'Y8plR1478504666'),
(882, '468.zip', '1478504766', '49.204.7.252', 'zeRFa1478504766'),
(883, '469.zip', '1478504865', '49.204.7.252', 'KYpIt1478504865'),
(884, '1.zip', '1478504930', '49.204.7.252', 'KyjCR1478504930'),
(885, '470.zip', '1478504950', '49.204.7.252', 'haDSD1478504950'),
(886, '471.zip', '1478505051', '49.204.7.252', 'AzZZV1478505051'),
(887, '472.zip', '1478505200', '49.204.7.252', 'gt54f1478505200'),
(888, 'j.zip', '1478507082', '49.204.7.252', 'vMuBz1478507082'),
(889, '5.zip', '1478507788', '49.204.7.252', 'Z30uU1478507788'),
(890, 'k.zip', '1478509340', '49.204.7.252', 'IbphF1478509340'),
(891, 'l.zip', '1478509954', '49.204.7.252', 'w3ojU1478509954'),
(892, '5.zip', '1478510310', '49.204.7.252', 'mFF641478510311'),
(893, '473.zip', '1478516115', '49.204.7.252', 'f9z2u1478516115'),
(894, '474.zip', '1478516222', '49.204.7.252', 'ByyJp1478516222'),
(895, '475.zip', '1478516342', '49.204.7.252', 'qJHHt1478516342'),
(896, '476.zip', '1478516492', '49.204.7.252', 'jwgBC1478516492'),
(897, '477.zip', '1478516593', '49.204.7.252', 'kfpzo1478516593'),
(898, '478.zip', '1478516707', '49.204.7.252', 'IIAF01478516707'),
(899, '479.zip', '1478516787', '49.204.7.252', 'FuZAy1478516787'),
(900, '480.zip', '1478516986', '49.204.7.252', 'CKYQB1478516986'),
(901, '481.zip', '1478517116', '49.204.7.252', 'ZwvPn1478517116'),
(902, '482.zip', '1478517252', '49.204.7.252', 'NrHAs1478517252'),
(903, 'o.zip', '1478519094', '49.204.7.252', 'aIJ921478519094'),
(904, 'l.zip', '1478519797', '49.204.7.252', 'FgXmE1478519797'),
(905, 'l.zip', '1478520194', '49.204.7.252', 'mIx9j1478520194'),
(906, 'k.zip', '1478520964', '49.204.7.252', 'LjBZ31478520964'),
(907, '4.zip', '1478521212', '49.204.7.252', 'tL35s1478521212'),
(908, '483.zip', '1478521832', '49.204.7.252', 'GcGBH1478521832'),
(909, '484.zip', '1478521909', '49.204.7.252', 'C0WNM1478521909'),
(910, '485.zip', '1478522013', '49.204.7.252', 'OLhuD1478522013'),
(911, '486.zip', '1478522100', '49.204.7.252', 't5xZa1478522100'),
(912, '487.zip', '1478522182', '49.204.7.252', 'Wiv7U1478522182'),
(913, '488.zip', '1478522257', '49.204.7.252', '7u0pq1478522257'),
(914, '489.zip', '1478522327', '49.204.7.252', 'RHrBn1478522327'),
(915, '490.zip', '1478522450', '49.204.7.252', 'cXpwg1478522450'),
(916, '490.zip', '1478522511', '49.204.7.252', 'melIU1478522511'),
(917, '491.zip', '1478522593', '49.204.7.252', 'DGGD91478522593'),
(918, '492.zip', '1478522707', '49.204.7.252', 'kOACH1478522707'),
(919, '493.zip', '1478589433', '49.204.7.252', 'L5ofC1478589433'),
(920, '494.zip', '1478589556', '49.204.7.252', 'vzh171478589556'),
(921, '495.zip', '1478589713', '49.204.7.252', '5wBiB1478589713'),
(922, '496.zip', '1478589883', '49.204.7.252', 'YlFVf1478589883'),
(923, '497.zip', '1478593442', '49.204.7.252', 'Ee0041478593442'),
(924, '498.zip', '1478593644', '49.204.7.252', 'iLkDj1478593644'),
(925, '499.zip', '1478593735', '49.204.7.252', 'aqbaE1478593735'),
(926, '500.zip', '1478594394', '49.204.7.252', 'XRzUE1478594394'),
(927, '501.zip', '1478595236', '49.204.7.252', '7eAoA1478595236'),
(928, '502.zip', '1478595480', '49.204.7.252', 'WepEx1478595480'),
(929, '503.zip', '1478601727', '49.204.7.252', 'g094B1478601727'),
(930, '504.zip', '1478601920', '49.204.7.252', 'YHc7N1478601920'),
(931, '505.zip', '1478602192', '49.204.7.252', 'JRoL71478602192'),
(932, '506.zip', '1478602356', '49.204.7.252', 'JSm8C1478602356'),
(933, '507.zip', '1478602447', '49.204.7.252', '6QYH91478602447'),
(934, '508.zip', '1478602529', '49.204.7.252', 'Dx1dn1478602529'),
(935, '509.zip', '1478602618', '49.204.7.252', 'ppZlY1478602618'),
(936, '510.zip', '1478602924', '49.204.7.252', 'jvQns1478602924'),
(937, '511.zip', '1478603144', '49.204.7.252', 'Tlxc71478603144'),
(938, '512.zip', '1478603220', '49.204.7.252', 'b0UYc1478603220'),
(939, '513.zip', '1478603352', '49.204.7.252', 'rnBd91478603352'),
(940, '514.zip', '1478672221', '49.204.7.252', 'tmyI61478672221'),
(941, '515.zip', '1478672310', '49.204.7.252', '39Ciw1478672310'),
(942, '516.zip', '1478672399', '49.204.7.252', 'NrqO51478672399'),
(943, '517.zip', '1478672596', '49.204.7.252', 'Awqqe1478672596'),
(944, '518.zip', '1478672778', '49.204.7.252', '7p9dU1478672778'),
(945, '519.zip', '1478672887', '49.204.7.252', 'cDb2d1478672887'),
(946, '520.zip', '1478672957', '49.204.7.252', 'UtZqF1478672957'),
(947, '521.zip', '1478673108', '49.204.7.252', 'SJzY91478673108'),
(948, '522.zip', '1478673261', '49.204.7.252', 'dALzG1478673261'),
(949, '523.zip', '1478673383', '49.204.7.252', 'ghddb1478673383'),
(950, '524.zip', '1478675531', '49.204.7.252', 'cvM4l1478675531'),
(951, '525.zip', '1478676619', '49.204.7.252', 'BmYXN1478676619'),
(952, '526.zip', '1478676684', '49.204.7.252', 'lLKT51478676684'),
(953, '527.zip', '1478677186', '49.204.7.252', 'gGV1l1478677186'),
(954, '528.zip', '1478677278', '49.204.7.252', 'w4LvI1478677278'),
(955, '529.zip', '1478677371', '49.204.7.252', '2D38H1478677371'),
(956, '530.zip', '1478677620', '49.204.7.252', 'WPZo31478677620'),
(957, '531.zip', '1478677685', '49.204.7.252', 'Ej07L1478677685'),
(958, '532.zip', '1478677771', '49.204.7.252', '0ozEo1478677771'),
(959, '533.zip', '1478677880', '49.204.7.252', 'CCBkP1478677880'),
(960, '534.zip', '1478677969', '49.204.7.252', 'jukJp1478677969'),
(961, '535.zip', '1478691016', '49.204.7.252', 'HkAR21478691016'),
(962, '536.zip', '1478691157', '49.204.7.252', 'U2jWf1478691157'),
(963, '537.zip', '1478691261', '49.204.7.252', 'VdieZ1478691261'),
(964, '538.zip', '1478691319', '49.204.7.252', 'JDlih1478691319'),
(965, '539.zip', '1478691379', '49.204.7.252', '6apEB1478691379'),
(966, '540.zip', '1478691440', '49.204.7.252', 'k1kCr1478691440'),
(967, '541.zip', '1478691502', '49.204.7.252', 'kGQr61478691502'),
(968, '542.zip', '1478691560', '49.204.7.252', 'eTuTq1478691560'),
(969, '543.zip', '1478691646', '49.204.7.252', 'IWQbX1478691646'),
(970, '544.zip', '1478691855', '49.204.7.252', 'pWMYy1478691855'),
(971, '545.zip', '1478691944', '49.204.7.252', 'JSGAc1478691944'),
(972, '546.zip', '1478761812', '49.204.7.252', 'VSN7N1478761812'),
(973, '547.zip', '1478761891', '49.204.7.252', 'Igb4b1478761891'),
(974, '548.zip', '1478761956', '49.204.7.252', '9niuA1478761956'),
(975, '549.zip', '1478762036', '49.204.7.252', 'StQ5K1478762036'),
(976, '550.zip', '1478762110', '49.204.7.252', 'h2lUD1478762110'),
(977, '551.zip', '1478762175', '49.204.7.252', 'L9uqv1478762175'),
(978, '552.zip', '1478762245', '49.204.7.252', '5KiIW1478762245'),
(979, '553.zip', '1478762303', '49.204.7.252', 'XoiLt1478762303'),
(980, '554.zip', '1478762351', '49.204.7.252', 'rR8hJ1478762351'),
(981, '555.zip', '1478762419', '49.204.7.252', 'VGZy01478762419'),
(982, '556.zip', '1478771161', '49.204.7.252', 'DRtj91478771161'),
(983, '557.zip', '1478771223', '49.204.7.252', 't8uqb1478771223'),
(984, '558.zip', '1478771281', '49.204.7.252', 'v9MWv1478771281'),
(985, '559.zip', '1478771331', '49.204.7.252', '4BkyS1478771331'),
(986, '560.zip', '1478771386', '49.204.7.252', 'a1QZM1478771386'),
(987, '561.zip', '1478771451', '49.204.7.252', '12aOk1478771451'),
(988, '562.zip', '1478771621', '49.204.7.252', '59Rim1478771621'),
(989, '563.zip', '1479359810', '49.204.7.252', 'H4QkK1479359810'),
(990, '564.zip', '1479359870', '49.204.7.252', 'N8agR1479359870'),
(991, '565.zip', '1479359923', '49.204.7.252', 'TzDQC1479359923'),
(992, '566.zip', '1479360003', '49.204.7.252', 'bSrVw1479360003'),
(993, '567.zip', '1479360074', '49.204.7.252', '9ZdDj1479360074'),
(994, '568.zip', '1479360179', '49.204.7.252', '5scUr1479360179'),
(995, '569.zip', '1479360231', '49.204.7.252', 'oaVJP1479360231'),
(996, '570.zip', '1479360283', '49.204.7.252', 'O5XF41479360283'),
(997, '571.zip', '1479360338', '49.204.7.252', 'gxmUx1479360338'),
(998, '572.zip', '1479360391', '49.204.7.252', '2MVfZ1479360391'),
(999, '573.zip', '1479360455', '49.204.7.252', 'xQHf61479360455'),
(1000, '574.zip', '1479361799', '49.204.7.252', 'zIVtQ1479361799'),
(1001, '575.zip', '1479361860', '49.204.7.252', '8Fzfg1479361860'),
(1002, '576.zip', '1479365995', '49.204.7.252', '5mHAB1479365995'),
(1003, '577.zip', '1479366052', '49.204.7.252', 'vfwNy1479366052'),
(1004, '578.zip', '1479366097', '49.204.7.252', '3jfoi1479366097'),
(1005, '579.zip', '1479366147', '49.204.7.252', 'dI6kZ1479366147'),
(1006, '580.zip', '1479366193', '49.204.7.252', 'dA4YU1479366193'),
(1007, '581.zip', '1479366253', '49.204.7.252', '8RPr41479366253'),
(1008, '582.zip', '1479366309', '49.204.7.252', 'iI1wG1479366309'),
(1009, '583.zip', '1479366379', '49.204.7.252', 'zWD9c1479366379'),
(1010, '584.zip', '1479366437', '49.204.7.252', 'R9CHa1479366437'),
(1011, '585.zip', '1479368308', '49.204.7.252', 'WtDmq1479368308'),
(1012, '586.zip', '1479368357', '49.204.7.252', 'x5kgw1479368357'),
(1013, '587.zip', '1479368405', '49.204.7.252', 'A3GKR1479368405'),
(1014, '588.zip', '1479368472', '49.204.7.252', 'yYZ9c1479368472'),
(1015, '589.zip', '1479368558', '49.204.7.252', '0BJv11479368558'),
(1016, '590.zip', '1479368604', '49.204.7.252', 'NXBr21479368604'),
(1017, '591.zip', '1479376690', '49.204.7.252', 'PMnWY1479376690'),
(1018, '592.zip', '1479377136', '49.204.7.252', 'DeLJ81479377136'),
(1019, '593.zip', '1479377202', '49.204.7.252', 'WOvaF1479377202'),
(1020, '594.zip', '1479377278', '49.204.7.252', 'cblCx1479377278'),
(1021, '595.zip', '1479377338', '49.204.7.252', '9H1GG1479377338'),
(1022, '596.zip', '1479377401', '49.204.7.252', 'Jtoe21479377401'),
(1023, '597.zip', '1479377551', '49.204.7.252', 'J6iYE1479377551'),
(1024, '598.zip', '1479377629', '49.204.7.252', 'kIWX81479377629'),
(1025, '599.zip', '1479377703', '49.204.7.252', 'OJo5o1479377703'),
(1026, '600.zip', '1479378823', '49.204.7.252', 'EMIWp1479378823'),
(1027, '601.zip', '1479378880', '49.204.7.252', 'l4whC1479378880'),
(1028, 'Yahoo-Email-List.zip', '1479737800', '43.249.226.82', 'rVgfI1479737800'),
(1029, 'Ashok.zip', '1482136023', '49.204.41.96', '4JR6X1482136023'),
(1030, 'thoattharani.zip', '1482136441', '49.204.41.96', 'ebsmI1482136441'),
(1031, 'makeup1.zip', '1482146206', '49.204.41.96', 'Q9NaD1482146206'),
(1032, 'makeup.zip', '1482146661', '49.204.41.96', 'Xhi8h1482146661'),
(1033, 'snap1.JPG', '1482255495', '43.230.198.46', 'a7WKn1482255495'),
(1034, 'costumes.zip', '1482297310', '49.204.41.96', '22hof1482297310'),
(1035, 'costume1.zip', '1482297703', '49.204.41.96', 'XBqOR1482297703'),
(1036, 'publicity.zip', '1482298380', '49.204.41.96', 'Jm43J1482298380'),
(1037, 'Publicity1.zip', '1482298812', '49.204.41.96', 'NsTwt1482298812'),
(1038, 'IMG_3526.JPG', '1482384843', '139.167.148.116', 'av6qo1482384843'),
(1039, 'IMG_3527.JPG', '1482384904', '139.167.148.116', 'eMcjy1482384904'),
(1040, 'IMG_3570.JPG', '1482400427', '139.167.145.139', 'jS1Rd1482400427'),
(1041, 'IMG_3570.JPG', '1482400472', '139.167.145.139', 'j1eKe1482400472'),
(1042, 'IMG_3571.JPG', '1482400527', '139.167.145.139', 'rutb61482400527'),
(1043, 'Marketing Guides.zip', '1485150660', '49.204.41.96', 'a4RTu1485150660'),
(1044, 'Marketing Guides.zip', '1485150834', '49.204.41.96', 'krlu81485150834'),
(1045, 'Marketing Guides.zip', '1485153484', '49.204.41.96', 'hBN3T1485153484'),
(1046, 'image.jpeg', '1485785121', '43.230.198.140', 'a8Tqm1485785121'),
(1047, 'WhatsApp Video 2017-03-28 at 18.27.01 (1).mp4', '1490851844', '49.206.201.241', 'vSWbB1490851844'),
(1048, 'WhatsApp Video 2017-03-28 at 18.27.01.mp4', '1490851873', '49.206.201.241', 'rZsnk1490851873'),
(1049, 'Aqua Secure_2018-01-16-21-54-37.png', '1516496755', '2405:204:6004:bfb2::', 'mflUn1516496755'),
(1050, 'SC Gamers final script for spokesperson .doc', '1518902072', '86.98.6.150', '8uAfJ1518902072'),
(1051, 'Powerkarte4 Logo.png', '1523465462', '92.230.135.117', 'IVFyh1523465462'),
(1052, '0_b1b66_e98a449f_XL.jpg', '1523465520', '92.230.135.117', 'xhXIa1523465520'),
(1053, 'add-products.jpg', '1547727404', '183.83.1.209', 'Y3kqO1547727404'),
(1054, 'add-products-lead.jpg', '1547727523', '183.83.1.209', '7nNxU1547727523'),
(1055, 'add-products.jpg', '1547728036', '183.83.1.209', 'EBfHY1547728036'),
(1056, 'add-products.jpg', '1547728055', '183.83.1.209', 'z2PDK1547728055'),
(1057, 'add-products.jpg', '1547729236', '183.83.1.209', 'YE2IW1547729236'),
(1058, 'add-products-lead-edit.jpg', '1547729261', '183.83.1.209', 'pgnQO1547729261'),
(1059, 'add-products.jpg', '1547729291', '183.83.1.209', 'fqg6m1547729291'),
(1060, 'add-products.jpg', '1547729354', '183.83.1.209', '9wbhX1547729354'),
(1061, 'assignedto.jpg', '1547729489', '183.83.1.209', '9b5gv1547729489'),
(1062, 'add-products.jpg', '1547729648', '183.83.1.209', 'FTurt1547729648'),
(1063, 'add-products-lead.jpg', '1547729672', '183.83.1.209', '9Qi7d1547729672'),
(1064, 'add-products.jpg', '1547729829', '183.83.1.209', 'bzR0A1547729829'),
(1065, 'add-products.jpg', '1547730198', '183.83.1.209', 't8QBr1547730198'),
(1066, 'add-products.jpg', '1547731169', '183.83.1.209', 'CbCiV1547731169'),
(1067, 'comments-popup.jpg', '1547731264', '183.83.1.209', 'NVcBC1547731264'),
(1068, 'add-products.jpg', '1547748349', '183.83.1.209', '20L6q1547748349'),
(1069, 'add-products.jpg', '1547748420', '183.83.1.209', 'rT6GJ1547748420'),
(1070, 'add-products.jpg', '1547748445', '183.83.1.209', 'rTeRL1547748445'),
(1071, 'add-products.jpg', '1547748542', '183.83.1.209', '7aW5W1547748542'),
(1072, 'accuracy-check-Right-side.jpg', '1554383745', '103.214.61.117', 'G00261554383745'),
(1073, 'accuracy-check-Back.jpg', '1554383766', '103.214.61.117', 'KOPOx1554383766'),
(1074, 'accuracy-check-Front.jpg', '1554383782', '103.214.61.117', '5ijhH1554383782'),
(1075, 'accuracy-check.jpg', '1554741643', '103.214.61.115', 'pDrK81554741643'),
(1076, 'accuracy-check.jpg', '1554742444', '103.214.61.115', 'DShP21554742444'),
(1077, 'accuracy-check.jpg', '1554742877', '103.214.61.115', 'mInhW1554742877'),
(1078, 'accuracy-check.jpg', '1554744653', '103.214.61.115', 'VI5XE1554744653'),
(1079, 'accuracy-check.jpg', '1554745307', '103.214.61.115', 'AMvDs1554745307'),
(1080, 'front.jpg', '1555053537', '106.200.153.204', 'to22q1555053537'),
(1081, 'act-direct.zip', '1555074140', '106.200.153.204', 'KNEYg1555074140'),
(1082, 'act-direct.zip', '1555075020', '183.83.239.105', '8Qokh1555075020'),
(1083, 'child-act-direct.zip', '1555076090', '183.83.239.105', 'MIq3Q1555076090'),
(1084, 'direct-pack.zip', '1555077369', '183.83.239.105', 'gLbAc1555077369'),
(1085, 'cards.png', '1584625950', '27.57.167.107', 'X3p3N1584625950'),
(1086, 'cards.png', '1584626051', '27.57.167.107', 'qXUeq1584626051'),
(1087, 'TEMPlogo.png', '1584626337', '27.57.167.107', 'IkI2Y1584626337'),
(1088, 'UltraMan Manmadh Rebba(WorldChampion).pdf', '1584709920', '124.123.78.7', '7yCbi1584709920'),
(1089, 'thakshil.png', '1589259974', '49.204.180.139', 'a6QnX1589259974'),
(1090, 'thakshil.png', '1589260099', '49.204.180.139', 'zq12O1589260099'),
(1091, 'overlapping text 2.jpeg', '1589382092', '103.132.25.198', 'VxD6s1589382092'),
(1092, 'DSC_1360-1.jpg', '1589382180', '103.132.25.198', 'Vkxh01589382180'),
(1093, 'DSC_1360-1.jpg', '1589385059', '103.132.25.198', 'b0hPB1589385059');

-- --------------------------------------------------------

--
-- Table structure for table `fiverrscript_dotcom_notity`
--

CREATE TABLE `fiverrscript_dotcom_notity` (
  `NID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `scriptolution_type` varchar(100) NOT NULL DEFAULT '',
  `scriptolution_OID` bigint(20) NOT NULL DEFAULT '0',
  `time_added` varchar(20) DEFAULT NULL,
  `scriptolution_unread` bigint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fiverrscript_dotcom_notity`
--

INSERT INTO `fiverrscript_dotcom_notity` (`NID`, `USERID`, `scriptolution_type`, `scriptolution_OID`, `time_added`, `scriptolution_unread`) VALUES
(1, 41, 'scriptolution_buyer_requirements', 1, '1425974569', 1),
(2, 41, 'scriptolution_buyer_requirements', 2, '1425983943', 0),
(3, 43, 'scriptolution_buyer_requirements', 3, '1426140794', 0),
(4, 43, 'scriptolution_buyer_requirements', 4, '1426141747', 0),
(5, 53, 'fiverrscript_dotcom_neworder', 11, '1437124712', 0),
(6, 55, 'fiverrscript_dotcom_orderdelivered', 11, '1437124844', 0),
(7, 53, 'fiverrscript_dotcom_neworder', 13, '1437125735', 0),
(8, 48, 'fiverrscript_dotcom_neworder', 14, '1437125753', 0),
(9, 55, 'fiverrscript_dotcom_orderdelivered', 13, '1437125884', 0),
(10, 48, 'fiverrscript_dotcom_neworder', 15, '1437126035', 0),
(11, 55, 'fiverrscript_dotcom_orderdelivered', 14, '1437126353', 0),
(12, 55, 'fiverrscript_dotcom_orderdelivered', 15, '1437126559', 0),
(13, 53, 'fiverrscript_dotcom_neworder', 21, '1437126698', 0),
(14, 53, 'fiverrscript_dotcom_neworder', 22, '1437126715', 0),
(15, 48, 'fiverrscript_dotcom_neworder', 16, '1437126960', 0),
(16, 51, 'fiverrscript_dotcom_neworder', 17, '1437126978', 0),
(17, 53, 'fiverrscript_dotcom_neworder', 20, '1437126988', 0),
(18, 48, 'fiverrscript_dotcom_neworder', 5, '1437127169', 0),
(19, 53, 'fiverrscript_dotcom_neworder', 6, '1437127182', 0),
(20, 48, 'fiverrscript_dotcom_neworder', 18, '1437127187', 0),
(21, 53, 'fiverrscript_dotcom_neworder', 19, '1437127193', 0),
(22, 48, 'fiverrscript_dotcom_neworder', 7, '1437127308', 0),
(23, 50, 'fiverrscript_dotcom_neworder', 9, '1437127313', 0),
(24, 50, 'fiverrscript_dotcom_neworder', 10, '1437127319', 0),
(25, 53, 'fiverrscript_dotcom_neworder', 8, '1437127327', 0),
(26, 54, 'fiverrscript_dotcom_orderdelivered', 8, '1437127530', 0),
(27, 45, 'fiverrscript_dotcom_orderdelivered', 19, '1437127570', 0),
(28, 45, 'fiverrscript_dotcom_orderdelivered', 6, '1437127613', 0),
(29, 47, 'fiverrscript_dotcom_orderupdate', 20, '1437127637', 0),
(30, 47, 'fiverrscript_dotcom_orderdelivered', 20, '1437127646', 0),
(31, 47, 'fiverrscript_dotcom_orderdelivered', 22, '1437127673', 0),
(32, 47, 'fiverrscript_dotcom_orderdelivered', 21, '1437127687', 0),
(33, 54, 'fiverrscript_dotcom_orderdelivered', 7, '1437127824', 0),
(34, 47, 'fiverrscript_dotcom_orderdelivered', 16, '1437127934', 0),
(35, 45, 'fiverrscript_dotcom_orderdelivered', 5, '1437127946', 0),
(36, 45, 'fiverrscript_dotcom_orderdelivered', 18, '1437127962', 0),
(37, 47, 'fiverrscript_dotcom_orderdelivered', 17, '1437128044', 0),
(38, 54, 'fiverrscript_dotcom_orderdelivered', 9, '1437128199', 0),
(39, 54, 'fiverrscript_dotcom_orderdelivered', 10, '1437128216', 0),
(40, 51, 'fiverrscript_dotcom_orderfeedback', 17, '1437201498', 0),
(41, 53, 'fiverrscript_dotcom_neworder', 12, '1437202074', 0),
(42, 55, 'fiverrscript_dotcom_orderdelivered', 12, '1437202170', 0),
(43, 53, 'fiverrscript_dotcom_orderfeedback', 6, '1437203545', 0),
(44, 50, 'fiverrscript_dotcom_orderfeedback', 9, '1437206262', 1),
(45, 53, 'fiverrscript_dotcom_orderfeedback', 8, '1437206562', 0),
(46, 48, 'fiverrscript_dotcom_orderfeedback', 7, '1437297036', 0),
(47, 48, 'fiverrscript_dotcom_orderfeedback', 18, '1437297442', 0),
(48, 48, 'fiverrscript_dotcom_orderfeedback', 16, '1437297877', 0),
(49, 53, 'fiverrscript_dotcom_orderfeedback', 21, '1437298008', 0),
(50, 48, 'fiverrscript_dotcom_orderfeedback', 15, '1437298574', 0),
(51, 48, 'fiverrscript_dotcom_orderfeedback', 14, '1437298612', 0),
(52, 53, 'fiverrscript_dotcom_orderfeedback', 13, '1437298742', 0),
(53, 53, 'fiverrscript_dotcom_orderfeedback', 11, '1437298891', 0),
(54, 52, 'fiverrscript_dotcom_neworder', 24, '1437462215', 0),
(55, 51, 'fiverrscript_dotcom_neworder', 23, '1437462227', 0),
(56, 51, 'fiverrscript_dotcom_neworder', 25, '1437462414', 0),
(57, 53, 'fiverrscript_dotcom_neworder', 27, '1437462432', 0),
(58, 48, 'fiverrscript_dotcom_neworder', 26, '1437462441', 0),
(59, 57, 'fiverrscript_dotcom_orderdelivered', 24, '1437462490', 0),
(60, 57, 'fiverrscript_dotcom_orderdelivered', 23, '1437462594', 0),
(61, 56, 'fiverrscript_dotcom_orderdelivered', 27, '1437462656', 0),
(62, 56, 'fiverrscript_dotcom_orderupdate', 26, '1437462700', 0),
(63, 56, 'fiverrscript_dotcom_orderdelivered', 26, '1437462713', 0),
(64, 56, 'fiverrscript_dotcom_orderdelivered', 25, '1437462819', 0),
(65, 51, 'fiverrscript_dotcom_orderfeedback', 25, '1437462900', 1),
(66, 52, 'fiverrscript_dotcom_orderfeedback', 24, '1437463400', 1),
(67, 51, 'fiverrscript_dotcom_orderfeedback', 23, '1437463601', 1),
(68, 53, 'fiverrscript_dotcom_neworder', 60, '1437804880', 0),
(69, 59, 'fiverrscript_dotcom_orderdelivered', 60, '1437804980', 0),
(70, 53, 'fiverrscript_dotcom_orderfeedback', 60, '1437805036', 1),
(71, 51, 'fiverrscript_dotcom_neworder', 59, '1437805147', 0),
(72, 53, 'fiverrscript_dotcom_neworder', 58, '1437805169', 0),
(73, 60, 'fiverrscript_dotcom_orderdelivered', 58, '1437805235', 0),
(74, 60, 'fiverrscript_dotcom_orderdelivered', 59, '1437805308', 0),
(75, 51, 'fiverrscript_dotcom_orderfeedback', 59, '1437805427', 0),
(76, 53, 'fiverrscript_dotcom_orderfeedback', 58, '1437805597', 1),
(77, 52, 'fiverrscript_dotcom_neworder', 57, '1437805709', 0),
(78, 61, 'fiverrscript_dotcom_orderdelivered', 57, '1437805815', 0),
(79, 52, 'fiverrscript_dotcom_orderfeedback', 57, '1437805863', 1),
(80, 48, 'fiverrscript_dotcom_neworder', 55, '1437806039', 0),
(81, 62, 'fiverrscript_dotcom_orderdelivered', 55, '1437806154', 0),
(82, 48, 'fiverrscript_dotcom_orderfeedback', 55, '1437806349', 0),
(83, 53, 'fiverrscript_dotcom_neworder', 56, '1437806413', 0),
(84, 62, 'fiverrscript_dotcom_orderdelivered', 56, '1437806480', 0),
(85, 53, 'fiverrscript_dotcom_orderfeedback', 56, '1437807994', 1),
(86, 53, 'fiverrscript_dotcom_neworder', 54, '1437811460', 0),
(87, 51, 'fiverrscript_dotcom_neworder', 53, '1437811473', 0),
(88, 63, 'fiverrscript_dotcom_orderdelivered', 54, '1437811514', 0),
(89, 53, 'fiverrscript_dotcom_orderfeedback', 54, '1437811596', 0),
(90, 63, 'fiverrscript_dotcom_orderdelivered', 53, '1437811701', 0),
(91, 51, 'fiverrscript_dotcom_orderfeedback', 53, '1437812608', 1),
(92, 53, 'fiverrscript_dotcom_neworder', 52, '1437813203', 0),
(93, 46, 'fiverrscript_dotcom_neworder', 51, '1437813271', 0),
(94, 51, 'fiverrscript_dotcom_neworder', 50, '1437813297', 0),
(95, 46, 'fiverrscript_dotcom_neworder', 49, '1437814064', 0),
(96, 58, 'fiverrscript_dotcom_neworder', 48, '1437814083', 0),
(97, 51, 'fiverrscript_dotcom_neworder', 47, '1437814094', 0),
(98, 53, 'fiverrscript_dotcom_neworder', 46, '1437814131', 0),
(99, 58, 'fiverrscript_dotcom_neworder', 45, '1437814148', 0),
(100, 49, 'fiverrscript_dotcom_neworder', 44, '1437814191', 0),
(101, 46, 'fiverrscript_dotcom_neworder', 43, '1437814236', 0),
(102, 49, 'fiverrscript_dotcom_neworder', 42, '1437814283', 0),
(103, 58, 'fiverrscript_dotcom_neworder', 41, '1437814295', 0),
(104, 51, 'fiverrscript_dotcom_neworder', 40, '1437814307', 0),
(105, 58, 'fiverrscript_dotcom_neworder', 39, '1437814348', 0),
(106, 46, 'fiverrscript_dotcom_neworder', 38, '1437814363', 0),
(107, 52, 'fiverrscript_dotcom_neworder', 37, '1437814402', 0),
(108, 46, 'fiverrscript_dotcom_neworder', 36, '1437814417', 0),
(109, 53, 'fiverrscript_dotcom_neworder', 35, '1437817241', 0),
(110, 49, 'fiverrscript_dotcom_neworder', 34, '1437972231', 0),
(111, 51, 'fiverrscript_dotcom_neworder', 33, '1437972244', 0),
(112, 58, 'fiverrscript_dotcom_neworder', 32, '1437972277', 0),
(113, 46, 'fiverrscript_dotcom_neworder', 31, '1437972295', 0),
(114, 51, 'fiverrscript_dotcom_neworder', 30, '1437972318', 0),
(115, 48, 'fiverrscript_dotcom_neworder', 29, '1437972352', 0),
(116, 49, 'fiverrscript_dotcom_neworder', 28, '1437972365', 0),
(117, 73, 'fiverrscript_dotcom_orderdelivered', 35, '1437972518', 0),
(118, 68, 'fiverrscript_dotcom_orderdelivered', 46, '1437972574', 0),
(119, 65, 'fiverrscript_dotcom_orderdelivered', 52, '1437972599', 0),
(120, 72, 'fiverrscript_dotcom_orderdelivered', 36, '1437972653', 0),
(121, 71, 'fiverrscript_dotcom_orderdelivered', 38, '1437972693', 0),
(122, 69, 'fiverrscript_dotcom_orderdelivered', 43, '1437972716', 0),
(123, 67, 'fiverrscript_dotcom_orderdelivered', 49, '1437972750', 0),
(124, 65, 'fiverrscript_dotcom_orderdelivered', 51, '1437972776', 0),
(125, 65, 'fiverrscript_dotcom_orderdelivered', 50, '1437972829', 0),
(126, 67, 'fiverrscript_dotcom_orderdelivered', 47, '1437972864', 0),
(127, 70, 'fiverrscript_dotcom_orderdelivered', 40, '1437972908', 0),
(128, 72, 'fiverrscript_dotcom_orderdelivered', 37, '1437972966', 0),
(129, 67, 'fiverrscript_dotcom_orderdelivered', 48, '1437973047', 0),
(130, 68, 'fiverrscript_dotcom_orderdelivered', 45, '1437973080', 0),
(131, 70, 'fiverrscript_dotcom_orderdelivered', 41, '1437973103', 0),
(132, 71, 'fiverrscript_dotcom_orderdelivered', 39, '1437973124', 0),
(133, 70, 'fiverrscript_dotcom_orderdelivered', 42, '1437973178', 0),
(134, 69, 'fiverrscript_dotcom_orderdelivered', 44, '1437973207', 0),
(135, 75, 'fiverrscript_dotcom_orderdelivered', 28, '1437973293', 0),
(136, 73, 'fiverrscript_dotcom_orderdelivered', 34, '1437973328', 0),
(137, 73, 'fiverrscript_dotcom_orderdelivered', 33, '1437973364', 0),
(138, 74, 'fiverrscript_dotcom_orderdelivered', 30, '1437973383', 0),
(139, 75, 'fiverrscript_dotcom_orderdelivered', 29, '1437973421', 0),
(140, 74, 'fiverrscript_dotcom_orderdelivered', 32, '1437973464', 0),
(141, 74, 'fiverrscript_dotcom_orderdelivered', 31, '1437973498', 0),
(142, 53, 'fiverrscript_dotcom_orderfeedback', 35, '1437973644', 1),
(143, 53, 'fiverrscript_dotcom_orderfeedback', 46, '1437973852', 1),
(144, 53, 'fiverrscript_dotcom_orderfeedback', 52, '1437973930', 1),
(145, 46, 'fiverrscript_dotcom_orderfeedback', 36, '1437974024', 1),
(146, 51, 'fiverrscript_dotcom_orderfeedback', 50, '1437974105', 1),
(147, 52, 'fiverrscript_dotcom_orderfeedback', 37, '1437974221', 1),
(148, 58, 'fiverrscript_dotcom_orderfeedback', 48, '1437974274', 1),
(149, 49, 'fiverrscript_dotcom_orderfeedback', 44, '1437974334', 1),
(150, 48, 'fiverrscript_dotcom_orderfeedback', 29, '1437974420', 1),
(151, 58, 'fiverrscript_dotcom_orderfeedback', 32, '1437974528', 1),
(152, 46, 'fiverrscript_dotcom_orderfeedback', 31, '1437974585', 1),
(153, 51, 'fiverrscript_dotcom_orderfeedback', 33, '1437974629', 1),
(154, 51, 'fiverrscript_dotcom_orderfeedback', 30, '1437974680', 1),
(155, 49, 'fiverrscript_dotcom_orderfeedback', 28, '1437974749', 1),
(156, 49, 'fiverrscript_dotcom_orderfeedback', 34, '1437974792', 1),
(157, 49, 'fiverrscript_dotcom_orderfeedback', 42, '1437974826', 1),
(158, 58, 'fiverrscript_dotcom_orderfeedback', 39, '1437974882', 1),
(159, 58, 'fiverrscript_dotcom_orderfeedback', 45, '1437974964', 1),
(160, 58, 'fiverrscript_dotcom_orderfeedback', 41, '1437975015', 1),
(161, 51, 'fiverrscript_dotcom_orderfeedback', 40, '1437975035', 1),
(162, 46, 'fiverrscript_dotcom_orderfeedback', 49, '1437975116', 1),
(163, 46, 'fiverrscript_dotcom_orderfeedback', 38, '1437975169', 1),
(164, 51, 'fiverrscript_dotcom_orderfeedback', 47, '1437975217', 1),
(165, 46, 'fiverrscript_dotcom_orderfeedback', 43, '1437975334', 1),
(166, 46, 'fiverrscript_dotcom_orderfeedback', 51, '1437975457', 1),
(167, 51, 'fiverrscript_dotcom_neworder', 64, '1438154320', 0),
(168, 53, 'fiverrscript_dotcom_neworder', 66, '1438154398', 0),
(169, 49, 'fiverrscript_dotcom_neworder', 71, '1438154468', 0),
(170, 58, 'fiverrscript_dotcom_neworder', 79, '1438154497', 0),
(171, 51, 'fiverrscript_dotcom_neworder', 77, '1438154522', 0),
(172, 58, 'fiverrscript_dotcom_neworder', 84, '1438154551', 0),
(173, 58, 'fiverrscript_dotcom_neworder', 86, '1438154583', 0),
(174, 46, 'fiverrscript_dotcom_neworder', 67, '1438154611', 0),
(175, 66, 'fiverrscript_dotcom_neworder', 73, '1438154638', 0),
(176, 53, 'fiverrscript_dotcom_neworder', 80, '1438154666', 0),
(177, 46, 'fiverrscript_dotcom_neworder', 83, '1438154721', 0),
(178, 58, 'fiverrscript_dotcom_neworder', 72, '1438154743', 0),
(179, 46, 'fiverrscript_dotcom_neworder', 75, '1438154768', 0),
(180, 51, 'fiverrscript_dotcom_neworder', 97, '1438154793', 0),
(181, 66, 'fiverrscript_dotcom_neworder', 65, '1438154825', 0),
(182, 53, 'fiverrscript_dotcom_neworder', 98, '1438154848', 0),
(183, 66, 'fiverrscript_dotcom_neworder', 78, '1438154869', 0),
(184, 58, 'fiverrscript_dotcom_neworder', 82, '1438154892', 0),
(185, 66, 'fiverrscript_dotcom_neworder', 85, '1438154912', 0),
(186, 48, 'fiverrscript_dotcom_neworder', 100, '1438154964', 0),
(187, 58, 'fiverrscript_dotcom_neworder', 63, '1438154993', 0),
(188, 49, 'fiverrscript_dotcom_neworder', 68, '1438155026', 0),
(189, 49, 'fiverrscript_dotcom_neworder', 90, '1438155054', 0),
(190, 58, 'fiverrscript_dotcom_neworder', 88, '1438155078', 0),
(191, 52, 'fiverrscript_dotcom_neworder', 99, '1438155105', 0),
(192, 46, 'fiverrscript_dotcom_neworder', 62, '1438155135', 0),
(193, 49, 'fiverrscript_dotcom_neworder', 61, '1438155164', 0),
(194, 49, 'fiverrscript_dotcom_neworder', 81, '1438155200', 0),
(195, 46, 'fiverrscript_dotcom_neworder', 92, '1438155222', 0),
(196, 52, 'fiverrscript_dotcom_neworder', 94, '1438155248', 0),
(197, 58, 'fiverrscript_dotcom_neworder', 95, '1438155273', 0),
(198, 58, 'fiverrscript_dotcom_neworder', 101, '1438155299', 0),
(199, 46, 'fiverrscript_dotcom_neworder', 69, '1438155327', 0),
(200, 58, 'fiverrscript_dotcom_neworder', 91, '1438155353', 0),
(201, 51, 'fiverrscript_dotcom_neworder', 96, '1438155377', 0),
(202, 46, 'fiverrscript_dotcom_neworder', 102, '1438155399', 0),
(203, 48, 'fiverrscript_dotcom_neworder', 70, '1438155427', 0),
(204, 51, 'fiverrscript_dotcom_neworder', 74, '1438155452', 0),
(205, 49, 'fiverrscript_dotcom_neworder', 76, '1438155487', 0),
(206, 46, 'fiverrscript_dotcom_neworder', 87, '1438155518', 0),
(207, 53, 'fiverrscript_dotcom_neworder', 89, '1438155543', 0),
(208, 51, 'fiverrscript_dotcom_neworder', 93, '1438155567', 0),
(209, 89, 'fiverrscript_dotcom_orderdelivered', 73, '1438155605', 0),
(210, 92, 'fiverrscript_dotcom_orderdelivered', 65, '1438155628', 0),
(211, 87, 'fiverrscript_dotcom_orderdelivered', 78, '1438155646', 0),
(212, 84, 'fiverrscript_dotcom_orderdelivered', 85, '1438155659', 0),
(213, 92, 'fiverrscript_dotcom_orderdelivered', 64, '1438156136', 0),
(214, 87, 'fiverrscript_dotcom_orderdelivered', 77, '1438156494', 0),
(215, 78, 'fiverrscript_dotcom_orderdelivered', 97, '1438157684', 0),
(216, 80, 'fiverrscript_dotcom_orderdelivered', 93, '1438157721', 0),
(217, 82, 'fiverrscript_dotcom_orderdelivered', 89, '1438157770', 0),
(218, 78, 'fiverrscript_dotcom_orderdelivered', 98, '1438157796', 0),
(219, 85, 'fiverrscript_dotcom_orderdelivered', 82, '1438157842', 1),
(220, 92, 'fiverrscript_dotcom_orderdelivered', 63, '1438157854', 0),
(221, 82, 'fiverrscript_dotcom_orderdelivered', 88, '1438157871', 0),
(222, 79, 'fiverrscript_dotcom_orderdelivered', 95, '1438157890', 0),
(223, 81, 'fiverrscript_dotcom_orderdelivered', 91, '1438157910', 0),
(224, 83, 'fiverrscript_dotcom_orderdelivered', 87, '1438157963', 0),
(225, 76, 'fiverrscript_dotcom_orderdelivered', 102, '1438157979', 0),
(226, 90, 'fiverrscript_dotcom_orderdelivered', 69, '1438158003', 0),
(227, 81, 'fiverrscript_dotcom_orderdelivered', 92, '1438158021', 0),
(228, 93, 'fiverrscript_dotcom_orderdelivered', 62, '1438158039', 0),
(229, 91, 'fiverrscript_dotcom_orderdelivered', 66, '1438158109', 0),
(230, 89, 'fiverrscript_dotcom_orderdelivered', 71, '1438158202', 0),
(231, 86, 'fiverrscript_dotcom_orderdelivered', 79, '1438158229', 0),
(232, 84, 'fiverrscript_dotcom_orderdelivered', 84, '1438158261', 0),
(233, 83, 'fiverrscript_dotcom_orderdelivered', 86, '1438158279', 0),
(234, 91, 'fiverrscript_dotcom_orderdelivered', 67, '1438158312', 0),
(235, 85, 'fiverrscript_dotcom_orderdelivered', 83, '1438158329', 0),
(236, 88, 'fiverrscript_dotcom_orderdelivered', 75, '1438158345', 0),
(237, 86, 'fiverrscript_dotcom_orderdelivered', 80, '1438158381', 1),
(238, 89, 'fiverrscript_dotcom_orderdelivered', 72, '1438158409', 1),
(239, 77, 'fiverrscript_dotcom_orderdelivered', 100, '1438158443', 0),
(240, 90, 'fiverrscript_dotcom_orderdelivered', 68, '1438158471', 0),
(241, 81, 'fiverrscript_dotcom_orderdelivered', 90, '1438158484', 0),
(242, 93, 'fiverrscript_dotcom_orderdelivered', 61, '1438158504', 0),
(243, 85, 'fiverrscript_dotcom_orderdelivered', 81, '1438158515', 0),
(244, 87, 'fiverrscript_dotcom_orderdelivered', 76, '1438158538', 0),
(245, 77, 'fiverrscript_dotcom_orderdelivered', 99, '1438158579', 0),
(246, 80, 'fiverrscript_dotcom_orderdelivered', 94, '1438158615', 0),
(247, 76, 'fiverrscript_dotcom_orderdelivered', 101, '1438158642', 0),
(248, 79, 'fiverrscript_dotcom_orderdelivered', 96, '1438158688', 0),
(249, 88, 'fiverrscript_dotcom_orderdelivered', 74, '1438158694', 0),
(250, 90, 'fiverrscript_dotcom_orderdelivered', 70, '1438158720', 0),
(251, 66, 'fiverrscript_dotcom_orderfeedback', 73, '1438346231', 0),
(252, 66, 'fiverrscript_dotcom_orderfeedback', 65, '1438346339', 0),
(253, 58, 'fiverrscript_dotcom_orderfeedback', 63, '1438346405', 1),
(254, 48, 'fiverrscript_dotcom_orderfeedback', 70, '1438346617', 1),
(255, 51, 'fiverrscript_dotcom_orderfeedback', 74, '1438346721', 1),
(256, 51, 'fiverrscript_dotcom_orderfeedback', 96, '1438346936', 1),
(257, 58, 'fiverrscript_dotcom_orderfeedback', 101, '1438347078', 1),
(258, 52, 'fiverrscript_dotcom_orderfeedback', 94, '1438347155', 1),
(259, 66, 'fiverrscript_dotcom_orderfeedback', 78, '1438347254', 0),
(260, 52, 'fiverrscript_dotcom_orderfeedback', 99, '1438347337', 1),
(261, 49, 'fiverrscript_dotcom_orderfeedback', 76, '1438347436', 1),
(262, 49, 'fiverrscript_dotcom_orderfeedback', 81, '1438347503', 1),
(263, 49, 'fiverrscript_dotcom_orderfeedback', 61, '1438347589', 1),
(264, 49, 'fiverrscript_dotcom_orderfeedback', 90, '1438347659', 1),
(265, 49, 'fiverrscript_dotcom_orderfeedback', 68, '1438347727', 1),
(266, 66, 'fiverrscript_dotcom_orderfeedback', 85, '1438347787', 0),
(267, 58, 'fiverrscript_dotcom_orderfeedback', 88, '1438347911', 1),
(268, 46, 'fiverrscript_dotcom_orderfeedback', 67, '1438348070', 1),
(269, 48, 'fiverrscript_dotcom_orderfeedback', 100, '1438348179', 0),
(270, 53, 'fiverrscript_dotcom_orderfeedback', 98, '1438348328', 1),
(271, 53, 'fiverrscript_dotcom_orderfeedback', 89, '1438348422', 1),
(272, 49, 'fiverrscript_dotcom_orderfeedback', 71, '1438348489', 1),
(273, 53, 'fiverrscript_dotcom_orderfeedback', 66, '1438348578', 1),
(274, 51, 'fiverrscript_dotcom_orderfeedback', 64, '1438348701', 1),
(275, 46, 'fiverrscript_dotcom_orderfeedback', 75, '1438348824', 1),
(276, 46, 'fiverrscript_dotcom_orderfeedback', 83, '1438348939', 1),
(277, 51, 'fiverrscript_dotcom_orderfeedback', 93, '1438349011', 1),
(278, 51, 'fiverrscript_dotcom_orderfeedback', 97, '1438349078', 1),
(279, 51, 'fiverrscript_dotcom_orderfeedback', 77, '1438349136', 1),
(280, 58, 'fiverrscript_dotcom_orderfeedback', 86, '1438349280', 1),
(281, 46, 'fiverrscript_dotcom_orderfeedback', 92, '1438349345', 1),
(282, 58, 'fiverrscript_dotcom_orderfeedback', 95, '1438349421', 1),
(283, 58, 'fiverrscript_dotcom_orderfeedback', 84, '1438349480', 1),
(284, 58, 'fiverrscript_dotcom_orderfeedback', 91, '1438349528', 1),
(285, 46, 'fiverrscript_dotcom_orderfeedback', 62, '1438349594', 1),
(286, 46, 'fiverrscript_dotcom_orderfeedback', 87, '1438349690', 1),
(287, 46, 'fiverrscript_dotcom_orderfeedback', 69, '1438349774', 1),
(288, 46, 'fiverrscript_dotcom_orderfeedback', 102, '1438349861', 1),
(289, 58, 'fiverrscript_dotcom_orderfeedback', 79, '1438349913', 1),
(290, 46, 'fiverrscript_dotcom_neworder', 103, '1439531499', 0),
(291, 46, 'fiverrscript_dotcom_neworder', 104, '1439531542', 0),
(292, 46, 'fiverrscript_dotcom_neworder', 105, '1439531575', 0),
(293, 46, 'fiverrscript_dotcom_neworder', 106, '1439531604', 0),
(294, 46, 'fiverrscript_dotcom_neworder', 107, '1439531632', 0),
(295, 46, 'fiverrscript_dotcom_neworder', 108, '1439531655', 0),
(296, 46, 'fiverrscript_dotcom_neworder', 109, '1439531680', 0),
(297, 46, 'fiverrscript_dotcom_neworder', 110, '1439531703', 0),
(298, 46, 'fiverrscript_dotcom_neworder', 111, '1439531727', 0),
(299, 46, 'fiverrscript_dotcom_neworder', 112, '1439531751', 0),
(300, 46, 'fiverrscript_dotcom_neworder', 113, '1439531787', 0),
(301, 91, 'fiverrscript_dotcom_orderdelivered', 103, '1439531916', 0),
(302, 69, 'fiverrscript_dotcom_orderdelivered', 104, '1439531932', 0),
(303, 67, 'fiverrscript_dotcom_orderdelivered', 105, '1439531946', 0),
(304, 77, 'fiverrscript_dotcom_orderdelivered', 106, '1439531968', 0),
(305, 77, 'fiverrscript_dotcom_orderdelivered', 107, '1439531987', 0),
(306, 90, 'fiverrscript_dotcom_orderdelivered', 108, '1439532007', 0),
(307, 75, 'fiverrscript_dotcom_orderdelivered', 109, '1439532024', 0),
(308, 83, 'fiverrscript_dotcom_orderdelivered', 110, '1439532048', 0),
(309, 74, 'fiverrscript_dotcom_orderdelivered', 111, '1439532074', 0),
(310, 82, 'fiverrscript_dotcom_orderdelivered', 112, '1439532089', 0),
(311, 93, 'fiverrscript_dotcom_orderdelivered', 113, '1439532437', 0),
(312, 46, 'fiverrscript_dotcom_orderfeedback', 113, '1440222032', 1),
(313, 46, 'fiverrscript_dotcom_orderfeedback', 103, '1440222100', 1),
(314, 46, 'fiverrscript_dotcom_orderfeedback', 104, '1440222145', 1),
(315, 46, 'fiverrscript_dotcom_orderfeedback', 105, '1440222432', 1),
(316, 46, 'fiverrscript_dotcom_orderfeedback', 106, '1440222486', 1),
(317, 46, 'fiverrscript_dotcom_orderfeedback', 107, '1440222540', 1),
(318, 46, 'fiverrscript_dotcom_orderfeedback', 108, '1440222602', 1),
(319, 46, 'fiverrscript_dotcom_orderfeedback', 109, '1440222645', 1),
(320, 46, 'fiverrscript_dotcom_orderfeedback', 110, '1440222680', 1),
(321, 46, 'fiverrscript_dotcom_orderfeedback', 111, '1440222728', 1),
(322, 46, 'fiverrscript_dotcom_orderfeedback', 112, '1440222784', 1),
(323, 66, 'fiverrscript_dotcom_neworder', 114, '1440404818', 0),
(324, 94, 'fiverrscript_dotcom_orderdelivered', 114, '1440571045', 0),
(325, 66, 'fiverrscript_dotcom_orderupdate', 114, '1440594302', 0),
(326, 94, 'fiverrscript_dotcom_orderupdate', 114, '1440654707', 0),
(327, 66, 'fiverrscript_dotcom_orderupdate', 114, '1440660636', 0),
(328, 673, 'scriptolution_buyer_requirements', 2, '1577684614', 0),
(329, 673, 'scriptolution_buyer_requirements', 3, '1577685287', 0),
(330, 694, 'fiverrscript_dotcom_neworder', 3, '1582547082', 0),
(331, 673, 'scriptolution_buyer_requirements', 4, '1582549927', 0),
(332, 694, 'fiverrscript_dotcom_neworder', 4, '1584625950', 0),
(333, 694, 'fiverrscript_dotcom_orderupdate', 4, '1584626051', 0),
(334, 694, 'fiverrscript_dotcom_orderupdate', 3, '1584626338', 0),
(335, 694, 'fiverrscript_dotcom_orderupdate', 4, '1584709920', 1),
(336, 673, 'scriptolution_buyer_requirements', 5, '1589182615', 1),
(337, 673, 'scriptolution_buyer_requirements', 6, '1589182688', 1),
(338, 673, 'scriptolution_buyer_requirements', 7, '1589189021', 1),
(339, 673, 'scriptolution_buyer_requirements', 8, '1589189138', 0),
(340, 673, 'scriptolution_buyer_requirements', 9, '1589259912', 0),
(341, 694, 'fiverrscript_dotcom_neworder', 9, '1589259974', 0),
(342, 673, 'fiverrscript_dotcom_orderupdate', 9, '1589260083', 0),
(343, 673, 'fiverrscript_dotcom_orderdelivered', 9, '1589260099', 0),
(344, 694, 'fiverrscript_dotcom_orderfeedback', 9, '1589260257', 0),
(345, 694, 'fiverrscript_dotcom_neworder', 2, '1589382093', 1),
(346, 694, 'fiverrscript_dotcom_orderupdate', 2, '1589382180', 1),
(347, 694, 'fiverrscript_dotcom_orderupdate', 2, '1589385059', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE `inbox` (
  `MID` bigint(20) NOT NULL,
  `MSGTO` bigint(20) NOT NULL DEFAULT '0',
  `MSGFROM` bigint(20) NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `PID` bigint(20) NOT NULL DEFAULT '0',
  `FID` bigint(20) NOT NULL DEFAULT '0',
  `time` varchar(20) NOT NULL DEFAULT '',
  `unread` char(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inbox`
--

INSERT INTO `inbox` (`MID`, `MSGTO`, `MSGFROM`, `message`, `PID`, `FID`, `time`, `unread`) VALUES
(1, 694, 673, 'Hi', 2918, 0, '1582547303', '0'),
(2, 673, 694, 'thank you for the order', 0, 0, '1589260438', '0');

-- --------------------------------------------------------

--
-- Table structure for table `inbox2`
--

CREATE TABLE `inbox2` (
  `MID` bigint(20) NOT NULL,
  `MSGTO` bigint(20) NOT NULL DEFAULT '0',
  `MSGFROM` bigint(20) NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `OID` bigint(20) NOT NULL DEFAULT '0',
  `FID` bigint(20) NOT NULL DEFAULT '0',
  `time` varchar(20) NOT NULL DEFAULT '',
  `start` bigint(1) NOT NULL DEFAULT '0',
  `action` varchar(100) NOT NULL,
  `cancel` bigint(1) NOT NULL DEFAULT '0',
  `ctime` varchar(20) NOT NULL,
  `CID` bigint(20) NOT NULL DEFAULT '0',
  `reject` bigint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inbox2`
--

INSERT INTO `inbox2` (`MID`, `MSGTO`, `MSGFROM`, `message`, `OID`, `FID`, `time`, `start`, `action`, `cancel`, `ctime`, `CID`, `reject`) VALUES
(1, 694, 673, 'xvdsfgdfgbfdgfhgnh', 3, 0, '1582547082', 1, '', 0, '', 0, 0),
(2, 694, 673, 'Test 1', 4, 1085, '1584625950', 1, '', 0, '1584625950', 0, 0),
(3, 694, 673, 'Test 2', 4, 1086, '1584626051', 0, '', 0, '1584626051', 0, 0),
(4, 694, 673, 'bhvhkbhk,bhi', 3, 1087, '1584626337', 0, '', 0, '1584626337', 0, 0),
(5, 694, 673, 'test', 4, 1088, '1584709920', 0, '', 0, '1584709920', 0, 0),
(6, 694, 673, 'test case', 9, 1089, '1589259974', 1, '', 0, '1589259974', 0, 0),
(7, 673, 694, 'Thank you for the order..', 9, 0, '1589260083', 0, '', 0, '1589260083', 0, 0),
(8, 673, 694, 'final delivery', 9, 1090, '1589260099', 0, 'delivery', 0, '1589260099', 0, 0),
(9, 694, 673, 'jgh kjkjg kjgkjfk f uyfiuyf iufugkjhgkjh gkjg', 2, 1091, '1589382092', 1, '', 0, '1589382092', 0, 0),
(10, 694, 673, 'nbf ghfvj jhgf hdhgfgfshgf djty dfjytdutrdutyduyt yduyt dtdydyiuyfiuyouy iuyfiuyfy fuitrtduytdueruytvuytvyut uiyiuyr', 2, 1092, '1589382180', 0, '', 0, '1589382180', 0, 0),
(11, 694, 673, 'asdlhn kljdhvhsdjkg hsfd', 2, 1093, '1589385059', 0, '', 0, '1589385059', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `inbox_reports`
--

CREATE TABLE `inbox_reports` (
  `RID` bigint(20) NOT NULL,
  `MID` bigint(20) NOT NULL DEFAULT '0',
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `time` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `invites_code`
--

CREATE TABLE `invites_code` (
  `code` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `USERID` bigint(20) NOT NULL,
  `email` varchar(80) NOT NULL DEFAULT '',
  `pemail` varchar(100) NOT NULL,
  `username` varchar(80) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `pwd` varchar(50) NOT NULL,
  `funds` decimal(9,2) NOT NULL,
  `afunds` decimal(9,2) NOT NULL,
  `withdrawn` decimal(9,2) NOT NULL,
  `used` decimal(9,2) NOT NULL,
  `fullname` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `scriptolutionuserslogan` varchar(100) NOT NULL DEFAULT '',
  `rating` float NOT NULL DEFAULT '0',
  `ratingcount` bigint(10) NOT NULL DEFAULT '0',
  `profileviews` int(20) NOT NULL DEFAULT '0',
  `addtime` varchar(20) NOT NULL DEFAULT '',
  `lastlogin` varchar(20) NOT NULL DEFAULT '',
  `verified` char(1) NOT NULL DEFAULT '0',
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `profilepicture` varchar(100) NOT NULL DEFAULT '',
  `remember_me_key` varchar(32) DEFAULT NULL,
  `remember_me_time` datetime DEFAULT NULL,
  `ip` varchar(20) NOT NULL,
  `lip` varchar(20) NOT NULL,
  `aemail` varchar(100) NOT NULL,
  `country` varchar(2) NOT NULL DEFAULT 'US',
  `toprated` int(1) NOT NULL DEFAULT '0',
  `level` bigint(1) NOT NULL DEFAULT '1',
  `scriptolutionbankinfo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`USERID`, `email`, `pemail`, `username`, `password`, `pwd`, `funds`, `afunds`, `withdrawn`, `used`, `fullname`, `description`, `scriptolutionuserslogan`, `rating`, `ratingcount`, `profileviews`, `addtime`, `lastlogin`, `verified`, `status`, `profilepicture`, `remember_me_key`, `remember_me_time`, `ip`, `lip`, `aemail`, `country`, `toprated`, `level`, `scriptolutionbankinfo`) VALUES
(673, 'budhycor@madhurebba.tv', 'budhycor@madhurebba.tv', 'fatrin99', '0741e486c65cf491f77f60e69dbaa788', 'fatrin99', 0.00, 0.00, 0.00, 0.00, 'Fatrin Budiman', 'I\'m fatrin, from indonesian I\'m professional designer while many years ago. I\'d be happy to assist you in fiverr. You will certainly enjoy with me. :)', 'I do not offer cheap price, but the best quality', 0, 0, 0, '1524055258', '1589381131', '1', '1', '673.png', NULL, NULL, '36.76.181.245', '103.132.25.198', '', 'ID', 0, 1, ''),
(694, 'rrrjobwork@madhurebba.tv', '', 'rahulraval', 'd4972cd412900f3612770fa9690ce8cd', 'rahulraval', 0.00, 0.00, 0.00, 0.00, '', '', '', 0, 0, 0, '1533286010', '1582550757', '1', '1', '', NULL, NULL, '42.108.194.231', '122.170.35.174', '', 'US', 0, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `members_passcode`
--

CREATE TABLE `members_passcode` (
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `code` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `members_verifycode`
--

CREATE TABLE `members_verifycode` (
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `code` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members_verifycode`
--

INSERT INTO `members_verifycode` (`USERID`, `code`) VALUES
(673, '8SKEU1524055258'),
(694, 'U7AfE1533286010');

-- --------------------------------------------------------

--
-- Table structure for table `offerscriptolution`
--

CREATE TABLE `offerscriptolution` (
  `SCRIPTOLUTIONOFID` bigint(20) NOT NULL,
  `REQUESTID` bigint(20) NOT NULL DEFAULT '0',
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `scriptolutionmsg` text,
  `PID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `PID` bigint(20) NOT NULL DEFAULT '0',
  `time_added` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `stime` varchar(20) DEFAULT NULL,
  `price` varchar(20) NOT NULL DEFAULT '0',
  `cltime` varchar(20) DEFAULT NULL,
  `IID` bigint(20) NOT NULL,
  `late` bigint(1) NOT NULL DEFAULT '0',
  `scriptolution_proc_fees2` decimal(9,2) NOT NULL DEFAULT '0.00',
  `scriptolution_totalwfees2` decimal(9,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OID`, `USERID`, `PID`, `time_added`, `status`, `stime`, `price`, `cltime`, `IID`, `late`, `scriptolution_proc_fees2`, `scriptolution_totalwfees2`) VALUES
(2, 673, 2918, '1577684614', 1, '1589382092', '5', NULL, 242, 0, 1.00, 6.00),
(3, 673, 2918, '1577685287', 1, '1582547082', '5', NULL, 243, 0, 1.00, 6.00),
(4, 673, 2918, '1582549927', 1, '1584625950', '5', NULL, 247, 0, 1.00, 6.00),
(5, 673, 2917, '1589182615', 0, NULL, '5', NULL, 263, 0, 1.00, 6.00),
(6, 673, 2917, '1589182688', 0, NULL, '5', NULL, 263, 0, 1.00, 6.00),
(7, 673, 2917, '1589189021', 0, NULL, '5', NULL, 264, 0, 1.00, 6.00),
(8, 673, 2917, '1589189138', 0, NULL, '5', NULL, 264, 0, 1.00, 6.00),
(9, 673, 2917, '1589259912', 5, '1589259974', '5', '1589260257', 265, 0, 1.00, 6.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `IID` bigint(20) NOT NULL,
  `PID` bigint(20) NOT NULL DEFAULT '0',
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `multi` bigint(5) NOT NULL DEFAULT '0',
  `EID` bigint(20) NOT NULL DEFAULT '0',
  `EID2` bigint(20) NOT NULL DEFAULT '0',
  `EID3` bigint(20) NOT NULL DEFAULT '0',
  `totalprice` bigint(20) NOT NULL DEFAULT '0',
  `ctp` decimal(9,2) DEFAULT NULL,
  `scriptolutionbuy` bigint(1) NOT NULL DEFAULT '0',
  `scriptolution_proc_fee` decimal(9,2) NOT NULL DEFAULT '0.00',
  `scriptolution_proc_fees` decimal(9,2) NOT NULL DEFAULT '0.00',
  `scriptolution_totalwfees` decimal(9,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`IID`, `PID`, `USERID`, `multi`, `EID`, `EID2`, `EID3`, `totalprice`, `ctp`, `scriptolutionbuy`, `scriptolution_proc_fee`, `scriptolution_proc_fees`, `scriptolution_totalwfees`) VALUES
(1, 20, 2, 0, 0, 0, 0, 5, 1.00, 0, 0.00, 0.00, 0.00),
(2, 20, 2, 0, 0, 0, 0, 5, 1.00, 0, 0.00, 0.00, 0.00),
(3, 68, 5, 0, 0, 0, 0, 5, 1.00, 0, 0.00, 0.00, 0.00),
(4, 69, 6, 0, 0, 0, 0, 5, 1.00, 0, 0.00, 0.00, 0.00),
(5, 84, 5, 0, 34, 35, 36, 3900, 13.00, 0, 0.00, 0.00, 0.00),
(6, 63, 21, 0, 0, 0, 0, 300, 1.00, 0, 0.00, 0.00, 0.00),
(7, 16, 21, 0, 0, 0, 0, 300, 1.00, 0, 0.00, 0.00, 0.00),
(8, 74, 11, 0, 17, 0, 0, 1500, 5.00, 0, 0.00, 0.00, 0.00),
(9, 73, 11, 8, 0, 0, 0, 4800, 1.00, 0, 0.00, 0.00, 0.00),
(10, 16, 21, 2, 0, 0, 0, 600, 1.00, 0, 0.00, 0.00, 0.00),
(11, 86, 24, 0, 0, 0, 0, 999, 199.80, 0, 0.00, 0.00, 0.00),
(12, 16, 21, 11, 0, 0, 0, 3300, 1.00, 0, 0.00, 0.00, 0.00),
(13, 97, 21, 0, 0, 0, 0, 1000, 200.00, 0, 0.00, 0.00, 0.00),
(14, 86, 35, 0, 0, 0, 0, 999, 199.80, 0, 0.00, 0.00, 0.00),
(15, 86, 21, 0, 0, 0, 0, 999, 199.80, 0, 0.00, 0.00, 0.00),
(16, 108, 40, 0, 0, 0, 0, 400, 80.00, 0, 0.00, 0.00, 0.00),
(17, 108, 40, 0, 0, 0, 0, 400, 80.00, 0, 0.00, 0.00, 0.00),
(18, 109, 41, 0, 0, 0, 0, 2300, 460.00, 0, 0.00, 0.00, 0.00),
(19, 107, 3, 0, 0, 0, 0, 400, 80.00, 0, 0.00, 0.00, 0.00),
(20, 109, 41, 0, 0, 0, 0, 2300, 460.00, 0, 0.00, 0.00, 0.00),
(21, 96, 41, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(22, 107, 3, 0, 0, 0, 0, 400, 80.00, 0, 0.00, 0.00, 0.00),
(23, 81, 3, 0, 0, 0, 0, 900, 3.00, 0, 0.00, 0.00, 0.00),
(24, 81, 3, 0, 27, 28, 0, 2400, 8.00, 0, 0.00, 0.00, 0.00),
(25, 111, 5, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(26, 110, 5, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(27, 116, 43, 0, 0, 0, 0, 10, 2.00, 0, 0.00, 0.00, 0.00),
(28, 117, 43, 0, 0, 0, 0, 10, 2.00, 0, 0.00, 0.00, 0.00),
(29, 117, 43, 0, 0, 0, 0, 10, 2.00, 0, 0.00, 0.00, 0.00),
(30, 111, 5, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(31, 111, 43, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(32, 111, 43, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(33, 105, 42, 0, 0, 0, 0, 400, 80.00, 0, 0.00, 0.00, 0.00),
(34, 120, 54, 0, 0, 0, 0, 150, 30.00, 0, 0.00, 0.00, 0.00),
(35, 120, 54, 0, 0, 0, 0, 150, 30.00, 0, 0.00, 0.00, 0.00),
(36, 124, 54, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(37, 122, 54, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(38, 124, 45, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(39, 122, 45, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(40, 125, 55, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(41, 122, 55, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(42, 124, 45, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(43, 122, 45, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(44, 125, 47, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(45, 121, 47, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(46, 122, 47, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(47, 125, 56, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(48, 122, 56, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(49, 121, 56, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(50, 123, 57, 0, 0, 0, 0, 150, 30.00, 0, 0.00, 0.00, 0.00),
(51, 121, 57, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(52, 124, 59, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(53, 121, 60, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(54, 125, 60, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(55, 123, 61, 0, 0, 0, 0, 150, 30.00, 0, 0.00, 0.00, 0.00),
(56, 124, 62, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(57, 122, 62, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(58, 124, 63, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(59, 121, 63, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(60, 124, 65, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(61, 134, 65, 0, 0, 0, 0, 600, 120.00, 0, 0.00, 0.00, 0.00),
(62, 130, 65, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(63, 133, 67, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(64, 127, 67, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(65, 130, 67, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(66, 125, 68, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(67, 126, 68, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(68, 129, 69, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(69, 133, 69, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(70, 128, 70, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(71, 126, 70, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(72, 130, 70, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(73, 126, 71, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(74, 133, 71, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(75, 132, 72, 0, 0, 0, 0, 600, 120.00, 0, 0.00, 0.00, 0.00),
(76, 133, 72, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(77, 125, 73, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(78, 128, 73, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(79, 131, 73, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(80, 126, 74, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(81, 133, 74, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(82, 130, 74, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(83, 122, 75, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(84, 128, 75, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(85, 133, 76, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(86, 127, 76, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(87, 122, 77, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(88, 132, 77, 0, 0, 0, 0, 600, 120.00, 0, 0.00, 0.00, 0.00),
(89, 125, 78, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(90, 130, 78, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(91, 130, 79, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(92, 126, 79, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(93, 132, 80, 0, 0, 0, 0, 600, 120.00, 0, 0.00, 0.00, 0.00),
(94, 121, 80, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(95, 133, 81, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(96, 126, 81, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(97, 128, 81, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(98, 125, 82, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(99, 127, 82, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(100, 133, 83, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(101, 126, 83, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(102, 136, 84, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(103, 126, 84, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(104, 133, 85, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(105, 127, 85, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(106, 128, 85, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(107, 125, 86, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(108, 126, 86, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(109, 136, 87, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(110, 130, 87, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(111, 128, 87, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(112, 138, 88, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(113, 130, 88, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(114, 136, 89, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(115, 127, 89, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(116, 128, 89, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(117, 122, 90, 0, 0, 0, 0, 300, 60.00, 0, 0.00, 0.00, 0.00),
(118, 138, 90, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(119, 129, 90, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(120, 138, 91, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(121, 125, 91, 0, 0, 0, 0, 500, 100.00, 0, 0.00, 0.00, 0.00),
(122, 136, 92, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(123, 130, 92, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(124, 126, 92, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(125, 138, 93, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(126, 128, 93, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(127, 138, 94, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(128, 138, 96, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(129, 138, 96, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(130, 136, 96, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(131, 136, 97, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(132, 139, 93, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(133, 139, 93, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(134, 140, 82, 0, 0, 0, 0, 1200, 240.00, 0, 0.00, 0.00, 0.00),
(135, 140, 74, 0, 0, 0, 0, 1200, 240.00, 0, 0.00, 0.00, 0.00),
(136, 139, 83, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(137, 140, 75, 0, 0, 0, 0, 1200, 240.00, 0, 0.00, 0.00, 0.00),
(138, 140, 90, 0, 0, 0, 0, 1200, 240.00, 0, 0.00, 0.00, 0.00),
(139, 140, 77, 0, 0, 0, 0, 1200, 240.00, 0, 0.00, 0.00, 0.00),
(140, 140, 67, 0, 0, 0, 0, 1200, 240.00, 0, 0.00, 0.00, 0.00),
(141, 139, 69, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(142, 140, 91, 0, 0, 0, 0, 1200, 240.00, 0, 0.00, 0.00, 0.00),
(143, 136, 98, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(144, 136, 99, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(145, 136, 94, 0, 0, 0, 0, 120, 24.00, 0, 0.00, 0.00, 0.00),
(146, 110, 44, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(147, 139, 5, 0, 0, 0, 0, 200, 40.00, 0, 0.00, 0.00, 0.00),
(148, 130, 5, 0, 0, 0, 0, 100, 20.00, 0, 0.00, 0.00, 0.00),
(149, 253, 154, 0, 0, 0, 0, 9, 1.80, 0, 1.00, 1.00, 10.00),
(150, 575, 174, 0, 0, 0, 0, 35, 7.00, 0, 1.00, 1.00, 36.00),
(151, 575, 174, 0, 0, 0, 0, 35, 7.00, 0, 1.00, 1.00, 36.00),
(152, 663, 193, 0, 0, 0, 0, 30, 6.00, 2, 1.00, 1.00, 31.00),
(153, 671, 225, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(154, 267, 225, 0, 0, 0, 0, 125, 25.00, 0, 1.00, 1.00, 126.00),
(155, 578, 13, 0, 0, 0, 0, 9, 1.80, 0, 1.00, 1.00, 10.00),
(156, 632, 438, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(157, 107, 441, 0, 0, 0, 0, 6, 80.00, 0, 1.00, 1.00, 7.00),
(158, 107, 441, 0, 0, 0, 0, 6, 80.00, 0, 1.00, 1.00, 7.00),
(159, 107, 441, 0, 0, 0, 0, 6, 80.00, 0, 1.00, 1.00, 7.00),
(160, 2817, 2, 0, 0, 0, 0, 25, 3.00, 0, 1.00, 1.00, 26.00),
(161, 2129, 236, 0, 0, 0, 0, 20, 4.00, 0, 1.00, 1.00, 21.00),
(162, 656, 236, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(163, 656, 236, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(164, 659, 236, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(165, 540, 445, 0, 0, 0, 0, 9, 1.80, 0, 1.00, 1.00, 10.00),
(166, 2432, 450, 0, 0, 0, 0, 10, 2.00, 0, 1.00, 1.00, 11.00),
(167, 707, 451, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(168, 2826, 453, 0, 0, 0, 0, 10, 2.00, 0, 1.00, 1.00, 11.00),
(169, 688, 460, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(170, 2108, 471, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(171, 717, 476, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(172, 2849, 484, 0, 0, 0, 0, 6, 1.20, 0, 1.00, 1.00, 7.00),
(173, 2849, 490, 0, 0, 0, 0, 6, 1.20, 0, 1.00, 1.00, 7.00),
(174, 520, 495, 0, 0, 0, 0, 8, 1.60, 0, 1.00, 1.00, 9.00),
(175, 2870, 569, 0, 0, 0, 0, 2, 0.40, 0, 1.00, 1.00, 3.00),
(176, 2108, 589, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(177, 2888, 598, 0, 0, 0, 0, 4, 0.80, 0, 1.00, 1.00, 5.00),
(178, 2888, 598, 0, 0, 0, 0, 4, 0.80, 0, 1.00, 1.00, 5.00),
(179, 685, 605, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(180, 685, 605, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(181, 2108, 605, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(182, 685, 605, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(183, 675, 628, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(184, 1560, 630, 0, 0, 0, 0, 2, 0.40, 0, 1.00, 1.00, 3.00),
(185, 2359, 644, 0, 0, 0, 0, 9, 1.80, 0, 1.00, 1.00, 10.00),
(186, 668, 653, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(187, 2243, 658, 0, 0, 0, 0, 9, 1.80, 0, 1.00, 1.00, 10.00),
(188, 522, 665, 0, 0, 0, 0, 9, 1.80, 0, 1.00, 1.00, 10.00),
(189, 2910, 666, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(190, 2870, 668, 0, 0, 0, 0, 4, 0.80, 0, 1.00, 1.00, 5.00),
(191, 2870, 668, 0, 0, 0, 0, 4, 0.80, 0, 1.00, 1.00, 5.00),
(192, 2870, 668, 0, 0, 0, 0, 4, 0.80, 0, 1.00, 1.00, 5.00),
(193, 2870, 668, 0, 0, 0, 0, 4, 0.80, 0, 1.00, 1.00, 5.00),
(194, 2870, 668, 0, 0, 0, 0, 4, 0.80, 0, 1.00, 1.00, 5.00),
(195, 2870, 668, 0, 0, 0, 0, 4, 0.80, 0, 1.00, 1.00, 5.00),
(196, 2072, 669, 0, 0, 0, 0, 9, 1.80, 0, 1.00, 1.00, 10.00),
(197, 886, 13, 0, 0, 0, 0, 2, 0.40, 0, 1.00, 1.00, 3.00),
(198, 254, 670, 0, 0, 0, 0, 8, 1.60, 0, 1.00, 1.00, 9.00),
(199, 692, 674, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(200, 2051, 687, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(201, 688, 692, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(202, 2411, 695, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(203, 562, 699, 0, 0, 0, 0, 10, 2.00, 0, 1.00, 1.00, 11.00),
(204, 2108, 713, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(205, 2673, 715, 0, 0, 0, 0, 9, 1.80, 0, 1.00, 1.00, 10.00),
(206, 2108, 716, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(207, 668, 717, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(208, 650, 723, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(209, 2108, 725, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(210, 646, 726, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(211, 646, 726, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(212, 684, 728, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(213, 671, 733, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(214, 2910, 572, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(215, 688, 734, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(216, 2108, 741, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(217, 2823, 743, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(218, 655, 744, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(219, 655, 744, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(220, 2821, 743, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(221, 2821, 743, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(222, 2821, 743, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(223, 2814, 743, 0, 0, 0, 0, 15, 2.00, 0, 1.00, 1.00, 16.00),
(224, 2814, 743, 0, 0, 0, 0, 15, 2.00, 0, 1.00, 1.00, 16.00),
(225, 2814, 743, 0, 0, 0, 0, 15, 2.00, 0, 1.00, 1.00, 16.00),
(226, 2814, 743, 0, 0, 0, 0, 15, 2.00, 0, 1.00, 1.00, 16.00),
(227, 2814, 743, 0, 0, 0, 0, 15, 2.00, 0, 1.00, 1.00, 16.00),
(228, 1727, 743, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(229, 2916, 743, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(230, 641, 749, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(231, 688, 776, 0, 0, 0, 0, 3, 0.60, 0, 1.00, 1.00, 4.00),
(232, 2812, 781, 0, 0, 0, 0, 15, 2.00, 0, 1.00, 1.00, 16.00),
(233, 2816, 17, 0, 0, 0, 0, 15, 3.00, 0, 1.00, 1.00, 16.00),
(234, 2911, 821, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(235, 1100, 240, 0, 0, 0, 0, 2, 0.40, 0, 1.00, 1.00, 3.00),
(236, 2916, 240, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(237, 2918, 673, 0, 0, 0, 0, 0, NULL, 0, 0.00, 0.00, 0.00),
(238, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(239, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(240, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(241, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(242, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(243, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(244, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(245, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(246, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(247, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(248, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(249, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(250, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(251, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(252, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(253, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(254, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(255, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(256, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(257, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(258, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(259, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(260, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(261, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(262, 2918, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(263, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(264, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(265, 2917, 673, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00),
(266, 2917, 112, 0, 0, 0, 0, 5, 1.00, 0, 1.00, 1.00, 6.00);

-- --------------------------------------------------------

--
-- Table structure for table `packs`
--

CREATE TABLE `packs` (
  `ID` bigint(20) NOT NULL,
  `pprice` bigint(10) NOT NULL,
  `pcom` bigint(10) NOT NULL,
  `l1` int(1) NOT NULL DEFAULT '1',
  `l2` int(1) NOT NULL DEFAULT '1',
  `l3` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `packs`
--

INSERT INTO `packs` (`ID`, `pprice`, `pcom`, `l1`, `l2`, `l3`) VALUES
(1, 5, 20, 1, 1, 1),
(2, 10, 20, 1, 1, 1),
(3, 15, 20, 1, 1, 1),
(4, 20, 20, 1, 1, 1),
(5, 25, 20, 1, 1, 1),
(6, 30, 20, 1, 1, 1),
(7, 35, 20, 1, 1, 1),
(8, 40, 20, 1, 1, 1),
(9, 45, 20, 1, 1, 1),
(10, 50, 20, 1, 1, 1),
(11, 55, 20, 1, 1, 1),
(12, 60, 20, 1, 1, 1),
(13, 65, 20, 1, 1, 1),
(14, 70, 20, 1, 1, 1),
(15, 75, 20, 1, 1, 1),
(16, 80, 20, 1, 1, 1),
(17, 85, 20, 1, 1, 1),
(18, 90, 20, 1, 1, 1),
(19, 95, 20, 1, 1, 1),
(20, 100, 20, 1, 1, 1),
(21, 510, 20, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `ID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `OID` bigint(20) NOT NULL DEFAULT '0',
  `time` varchar(20) DEFAULT NULL,
  `price` varchar(20) NOT NULL DEFAULT '0',
  `t` bigint(1) NOT NULL DEFAULT '0',
  `PAYPAL` bigint(20) NOT NULL,
  `cancel` bigint(1) NOT NULL DEFAULT '0',
  `wd` bigint(20) NOT NULL DEFAULT '0',
  `IID` bigint(20) NOT NULL DEFAULT '0',
  `fiverrscriptdotcom_balance` bigint(20) NOT NULL DEFAULT '0',
  `fiverrscriptdotcom_available` bigint(20) NOT NULL DEFAULT '0',
  `fiverrscriptdotcom_stripe` bigint(20) NOT NULL DEFAULT '0',
  `fiverrscriptdotcom_stripe_user` varchar(200) NOT NULL DEFAULT '',
  `scriptolution_proc_fees3` decimal(9,2) NOT NULL DEFAULT '0.00',
  `scriptolution_totalwfees3` decimal(9,2) NOT NULL DEFAULT '0.00',
  `fiverrscriptdotcom_local` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`ID`, `USERID`, `OID`, `time`, `price`, `t`, `PAYPAL`, `cancel`, `wd`, `IID`, `fiverrscriptdotcom_balance`, `fiverrscriptdotcom_available`, `fiverrscriptdotcom_stripe`, `fiverrscriptdotcom_stripe_user`, `scriptolution_proc_fees3`, `scriptolution_totalwfees3`, `fiverrscriptdotcom_local`) VALUES
(1, 673, 4, '1582549927', '5', 1, 0, 0, 0, 247, 1, 0, 0, '', 1.00, 6.00, 0),
(2, 673, 5, '1589182615', '5', 1, 0, 0, 0, 263, 1, 0, 0, '', 1.00, 6.00, 0),
(3, 673, 6, '1589182688', '5', 1, 0, 0, 0, 263, 1, 0, 0, '', 1.00, 6.00, 0),
(4, 673, 7, '1589189021', '5', 1, 0, 0, 0, 264, 1, 0, 0, '', 1.00, 6.00, 0),
(5, 673, 8, '1589189138', '5', 1, 0, 0, 0, 264, 1, 0, 0, '', 1.00, 6.00, 0),
(6, 673, 9, '1589259912', '5', 1, 0, 0, 0, 265, 1, 0, 0, '', 1.00, 6.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `paypal_table`
--

CREATE TABLE `paypal_table` (
  `id` int(11) NOT NULL,
  `payer_id` varchar(60) DEFAULT NULL,
  `payment_date` varchar(50) DEFAULT NULL,
  `txn_id` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `payer_email` varchar(75) DEFAULT NULL,
  `payer_status` varchar(50) DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `memo` tinytext,
  `item_name` varchar(127) DEFAULT NULL,
  `item_number` varchar(127) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `mc_gross` decimal(9,2) DEFAULT NULL,
  `mc_currency` char(3) DEFAULT NULL,
  `address_name` varchar(255) NOT NULL DEFAULT '',
  `address_street` varchar(255) NOT NULL DEFAULT '',
  `address_city` varchar(255) NOT NULL DEFAULT '',
  `address_state` varchar(255) NOT NULL DEFAULT '',
  `address_zip` varchar(255) NOT NULL DEFAULT '',
  `address_country` varchar(255) NOT NULL DEFAULT '',
  `address_status` varchar(255) NOT NULL DEFAULT '',
  `payer_business_name` varchar(255) NOT NULL DEFAULT '',
  `payment_status` varchar(255) NOT NULL DEFAULT '',
  `pending_reason` varchar(255) NOT NULL DEFAULT '',
  `reason_code` varchar(255) NOT NULL DEFAULT '',
  `txn_type` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `paypal_table2`
--

CREATE TABLE `paypal_table2` (
  `id` int(11) NOT NULL,
  `payer_id` varchar(60) DEFAULT NULL,
  `payment_date` varchar(50) DEFAULT NULL,
  `txn_id` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `payer_email` varchar(75) DEFAULT NULL,
  `payer_status` varchar(50) DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `memo` tinytext,
  `item_name` varchar(127) DEFAULT NULL,
  `item_number` varchar(127) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `mc_gross` decimal(9,2) DEFAULT NULL,
  `mc_currency` char(3) DEFAULT NULL,
  `address_name` varchar(255) NOT NULL DEFAULT '',
  `address_street` varchar(255) NOT NULL DEFAULT '',
  `address_city` varchar(255) NOT NULL DEFAULT '',
  `address_state` varchar(255) NOT NULL DEFAULT '',
  `address_zip` varchar(255) NOT NULL DEFAULT '',
  `address_country` varchar(255) NOT NULL DEFAULT '',
  `address_status` varchar(255) NOT NULL DEFAULT '',
  `payer_business_name` varchar(255) NOT NULL DEFAULT '',
  `payment_status` varchar(255) NOT NULL DEFAULT '',
  `pending_reason` varchar(255) NOT NULL DEFAULT '',
  `reason_code` varchar(255) NOT NULL DEFAULT '',
  `txn_type` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `PID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `gtitle` text NOT NULL,
  `gtags` text NOT NULL,
  `gdesc` text NOT NULL,
  `ginst` text NOT NULL,
  `category` bigint(20) NOT NULL DEFAULT '0',
  `days` bigint(10) NOT NULL DEFAULT '0',
  `youtube` varchar(200) NOT NULL,
  `feat` bigint(1) NOT NULL DEFAULT '0',
  `scriptolution_add_multiple` bigint(3) NOT NULL DEFAULT '0',
  `time_added` varchar(20) DEFAULT NULL,
  `date_added` date NOT NULL DEFAULT '0000-00-00',
  `active` char(1) NOT NULL DEFAULT '',
  `last_viewed` varchar(20) NOT NULL DEFAULT '',
  `rating` float NOT NULL DEFAULT '0',
  `rcount` bigint(20) NOT NULL DEFAULT '0',
  `viewcount` bigint(20) NOT NULL DEFAULT '0',
  `pip` varchar(20) NOT NULL,
  `p1` varchar(20) NOT NULL,
  `p2` varchar(20) NOT NULL,
  `p3` varchar(20) NOT NULL,
  `price` bigint(10) NOT NULL DEFAULT '0',
  `rev` bigint(20) NOT NULL DEFAULT '0',
  `ctp` decimal(9,2) NOT NULL DEFAULT '0.00',
  `short` varchar(200) NOT NULL,
  `scriptolutionhasextras` int(1) NOT NULL DEFAULT '0',
  `scriptolutionjoblocation` varchar(200) NOT NULL DEFAULT '',
  `scriptolutioncity` varchar(100) NOT NULL DEFAULT '',
  `scriptolutionstate` varchar(100) NOT NULL DEFAULT '',
  `scriptolutioncountry` varchar(100) NOT NULL DEFAULT '',
  `iurl` text NOT NULL,
  `ifile` bigint(20) NOT NULL DEFAULT '0',
  `scriptolutionship1` bigint(10) NOT NULL,
  `scriptolutionship1to` varchar(2) NOT NULL,
  `scriptolutionship2` bigint(10) NOT NULL,
  `price2` bigint(10) NOT NULL,
  `price3` bigint(10) NOT NULL,
  `ctp2` decimal(9,2) NOT NULL,
  `ctp3` decimal(9,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`PID`, `USERID`, `gtitle`, `gtags`, `gdesc`, `ginst`, `category`, `days`, `youtube`, `feat`, `scriptolution_add_multiple`, `time_added`, `date_added`, `active`, `last_viewed`, `rating`, `rcount`, `viewcount`, `pip`, `p1`, `p2`, `p3`, `price`, `rev`, `ctp`, `short`, `scriptolutionhasextras`, `scriptolutionjoblocation`, `scriptolutioncity`, `scriptolutionstate`, `scriptolutioncountry`, `iurl`, `ifile`, `scriptolutionship1`, `scriptolutionship1to`, `scriptolutionship2`, `price2`, `price3`, `ctp2`, `ctp3`) VALUES
(2913, 673, 'I Will Do Interior Design For Your Room', 'interiordesign graphicdesign interior design 3ddesign sketchup 3dmax', 'I\'m Graphic Design &amp;amp; Interior Design with 10 years of experience using sketchup, v-ray and photoshop. I can produce professional renderings for your project/design, using sketchup+vray&lt;span style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 14px; vertical-align: baseline; background: 0px 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-weight: 400; letter-spacing: normal; text-transform: none;&quot;&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;Please take in consideration:&lt;/p&gt;&lt;p&gt; &lt;br&gt;&lt;/p&gt;&lt;li style=&quot;margin: 0px 0px 0px 1.5em; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: 0px 0px; list-style: disc outside none;&quot;&gt;I can do the background and post production of any render, using Photoshop. please ask for it first,if you want it.&lt;/li&gt;&lt;li style=&quot;margin: 0px 0px 0px 1.5em; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: 0px 0px; list-style: disc outside none;&quot;&gt; For any project, i\'m always going to need a minimum of 3 days to finish it. If you need it before those 3 days its going to add 10$ per day.&lt;/li&gt;&lt;li style=&quot;margin: 0px 0px 0px 1.5em; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: 0px 0px; list-style: disc outside none;&quot;&gt;The price of the gig will depend on the complexity of the model you want me to make. No gig its going to cost 5$, Modeling and rendering requires lots of work and time.&lt;/li&gt;&lt;br&gt;&lt;/span&gt;', 'Please, contact me first before making an offer, it is important for me to know the work and the requirement that you need before to make a deal with you. Thank you!', 2, 3, '', 0, 0, '1524055876', '2018-04-18', '0', '', 0, 0, 341, '110.227.229.153', '2913-1.jpg', '', '', 6, 0, 1.20, '14467', 0, '', '', '', '', '', 0, 0, '', 0, 0, 0, 0.00, 0.00),
(2917, 694, 'quality transcript audio and video', 'Transcription ', '&lt;p&gt;Hello,&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;I am Rahul,&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;I can quality transcript any audio / video having English-Hindi-Gujarati Language&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;Thanking you&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;Regards:&lt;/p&gt;&lt;p&gt;Rahul&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Note: Confirm before ordering &lt;/strong&gt;&lt;/p&gt;', 'Audio / Video', 129, 2, '', 0, 0, '1533286382', '2018-08-03', '1', '', 100, 1, 372, '42.108.210.207', '2917-1.png', '', '', 5, 25, 1.00, '10718', 0, '', '', '', '', '', 0, 0, '', 0, 0, 0, 0.00, 0.00),
(2918, 694, 'quality translate from English-Hindi-Gujarati', 'Gujarati TranslationHindi TranslationEnglish to Hindi TranslationEnglish to Gujarati Translation', '&lt;p&gt;Hello,&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;I am Rahul,&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;I am able to quality translate your document form English-Hindi-Gujarati to English-Hindi-Gujarati.&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;NO TRANSLATOR WILL BE USED.&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;Thanking You&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;Regards:&lt;/p&gt;&lt;p&gt;Rahul&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Note: Confirm before ordering&lt;/strong&gt;&lt;/p&gt;', 'Document which is to be translated\r\nThe rate is for 350 words only', 123, 2, '', 0, 0, '1533287221', '2018-08-03', '1', '', 0, 0, 406, '2402:3a80:e75:a241:3', '2918-1.png', '', '', 5, 15, 1.00, '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <title>ta', 0, '', '', '', '', '', 0, 0, '', 0, 0, 0, 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `RID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `PID` bigint(20) NOT NULL DEFAULT '0',
  `OID` bigint(20) NOT NULL DEFAULT '0',
  `RATER` bigint(20) NOT NULL DEFAULT '0',
  `time_added` varchar(20) DEFAULT NULL,
  `good` bigint(1) NOT NULL DEFAULT '0',
  `bad` bigint(1) NOT NULL DEFAULT '0',
  `comment` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`RID`, `USERID`, `PID`, `OID`, `RATER`, `time_added`, `good`, `bad`, `comment`) VALUES
(1, 694, 2917, 9, 673, '1589260257', 1, 0, 'thank you for quick delivery..\r\nIt is absolutely a perfect service');

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

CREATE TABLE `referrals` (
  `RID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `REFERRED` bigint(20) NOT NULL DEFAULT '0',
  `money` decimal(9,2) NOT NULL,
  `time_added` varchar(20) DEFAULT NULL,
  `ip` text NOT NULL,
  `status` bigint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scriptolutionrequests`
--

CREATE TABLE `scriptolutionrequests` (
  `REQUESTID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `scriptolutiondesc` text,
  `scriptolutioncategory` bigint(20) NOT NULL DEFAULT '0',
  `scriptolutiondays` bigint(10) NOT NULL DEFAULT '0',
  `time_added` varchar(20) DEFAULT NULL,
  `active` bigint(1) NOT NULL DEFAULT '1',
  `pip` varchar(20) DEFAULT NULL,
  `scriptolutionprice` decimal(9,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scriptolution_launch`
--

CREATE TABLE `scriptolution_launch` (
  `LID` bigint(20) NOT NULL,
  `scriptolutionemail` varchar(80) NOT NULL,
  `time_added` varchar(20) DEFAULT NULL,
  `invited` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scriptolution_local`
--

CREATE TABLE `scriptolution_local` (
  `BID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `PID` bigint(20) NOT NULL DEFAULT '0',
  `IID` bigint(20) NOT NULL DEFAULT '0',
  `pprice` bigint(20) NOT NULL DEFAULT '0',
  `time_added` varchar(20) DEFAULT NULL,
  `pname` text NOT NULL,
  `pdate` text NOT NULL,
  `padditional` text NOT NULL,
  `processed` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `scriptolution_local`
--

INSERT INTO `scriptolution_local` (`BID`, `USERID`, `PID`, `IID`, `pprice`, `time_added`, `pname`, `pdate`, `padditional`, `processed`) VALUES
(1, 54, 120, 35, 150, '1437123643', 'prashanth ', '17/7/2015', 'Account number: 31851220223\r\nSBI bank', 1),
(2, 54, 124, 36, 300, '1437123773', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(3, 54, 122, 37, 300, '1437123899', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(4, 45, 124, 38, 300, '1437123996', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(5, 45, 122, 39, 300, '1437124040', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(6, 55, 125, 40, 500, '1437124385', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(7, 55, 122, 41, 300, '1437125134', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(8, 45, 124, 42, 300, '1437125235', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(9, 45, 122, 43, 300, '1437125280', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(10, 47, 125, 44, 500, '1437125411', 'prashanth ', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(11, 47, 121, 45, 200, '1437125450', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(12, 47, 122, 46, 300, '1437125493', 'prashanth', '17/7/2015', 'Account no. 31851220223\r\nSBI bank', 1),
(13, 56, 125, 47, 500, '1437199003', 'prashanth', '17/7/2015', 'SBI', 1),
(14, 56, 122, 48, 300, '1437199834', 'prashanth', '17/7/2015', 'SBI bank', 1),
(15, 56, 121, 49, 200, '1437199873', 'prashanth', '17/7/2015', 'SBI bank', 1),
(16, 57, 123, 50, 150, '1437201002', 'prashanth', '17/7/2015', 'SBI bank', 1),
(17, 57, 121, 51, 200, '1437201073', 'prashanth', '18/7/2015', 'SBI bank', 1),
(18, 59, 124, 52, 300, '1437464372', 'prashanth', '20/7/2015', 'SBI bank', 1),
(19, 60, 121, 53, 200, '1437464556', 'prashanth', '20/7/2015', 'SBI bank', 1),
(20, 60, 125, 54, 500, '1437464604', 'prashanth ', '20/7/2015', 'SBI bank', 1),
(21, 61, 123, 55, 150, '1437464693', 'prashanth', '20/7/2015', 'SBI bank', 1),
(22, 62, 124, 56, 300, '1437464788', 'prashanth ', '20/7/2015', 'SBI bank', 1),
(23, 62, 122, 57, 300, '1437464861', 'prashanth ', '20/7/2015', 'SBI bank', 1),
(24, 63, 124, 58, 300, '1437464942', 'prashanth', '20/7/2015', 'SBI bank', 1),
(25, 63, 121, 59, 200, '1437464974', 'prashanth', '20/7/2015', 'SBI bank', 1),
(26, 65, 124, 60, 300, '1437727474', 'prashanth', '24/7/2015', 'SBIbank', 1),
(27, 65, 134, 61, 600, '1437727517', 'prashanth', '24/7/2015', 'SBIbank', 1),
(28, 65, 130, 62, 100, '1437727560', 'prashanth', '24/7/2015', 'SBIbank', 1),
(29, 67, 133, 63, 300, '1437727645', 'prashanth', '24/7/2015', 'SBIbank', 1),
(30, 67, 127, 64, 300, '1437727679', 'prashanth', '24/7/2015', 'SBIbank', 1),
(31, 67, 130, 65, 100, '1437727709', 'prashanth', '24/7/2015', 'SBIbank', 1),
(32, 68, 125, 66, 500, '1437727781', 'prashanth', '24/7/2015', 'SBIbank', 1),
(33, 68, 126, 67, 120, '1437727806', 'prashanth', '24/7/2015', 'SBIbank', 1),
(34, 69, 129, 68, 100, '1437727908', 'prashanth', '24/7/2015', 'SBIbank', 1),
(35, 69, 133, 69, 300, '1437727941', 'prashanth', '24/7/2015', 'SBIbank', 1),
(36, 70, 128, 70, 100, '1437728014', 'prashanth', '24/7/2015', 'SBIbank', 1),
(37, 70, 126, 71, 120, '1437728051', 'prashanth', '24/7/2015', 'SBIbank', 1),
(38, 70, 130, 72, 100, '1437728092', 'prashanth', '24/7/2015', 'SBIbank', 1),
(39, 71, 126, 73, 120, '1437729882', 'prashanth', '24/7/2015', 'SBIbank', 1),
(40, 71, 133, 74, 300, '1437729915', 'prashanth', '24/7/2015', 'SBIbank', 1),
(41, 72, 132, 75, 600, '1437732007', 'prashanth', '24/7/2015', 'SBIbank', 1),
(42, 72, 133, 76, 300, '1437732099', 'prashanth', '24/7/2015', 'SBI bank', 1),
(43, 73, 125, 77, 500, '1437732658', 'prashanth', '24/7/2015', 'SBIbank', 1),
(44, 73, 128, 78, 100, '1437732696', 'prashanth', '24/7/2015', 'SBI bank', 1),
(45, 73, 131, 79, 300, '1437732745', 'prashanth', '24/7/2015', 'SBIbank', 1),
(46, 74, 126, 80, 120, '1437802933', 'prashanth', '25/7/2015', 'SBI bank', 1),
(47, 74, 133, 81, 300, '1437802974', 'prashanth', '25/7/2015', 'SBIbank', 1),
(48, 74, 130, 82, 100, '1437803006', 'prashanth', '25/7/2015', 'SBIbank', 1),
(49, 75, 122, 83, 300, '1437803338', 'prashanth', '25/7/2015', 'SBIbank', 1),
(50, 75, 128, 84, 100, '1437803384', 'prashanth', '25/7/2015', 'SBIbank', 1),
(51, 76, 133, 85, 300, '1437979444', 'prashanth', '27/7/2015', 'SBIbank', 1),
(52, 76, 127, 86, 300, '1437979520', 'prashanth', '27/7/2015', 'SBI bank', 1),
(53, 77, 122, 87, 300, '1437981598', 'prashanth', '27/7/2015', 'SBIbank', 1),
(54, 77, 132, 88, 600, '1437981634', 'prashanth', '27/7/2015', 'SBIbank', 1),
(55, 78, 125, 89, 500, '1437982574', 'prashanth', '27/7/2015', 'SBI bank', 1),
(56, 78, 130, 90, 100, '1437982607', 'prashanth', '27/7/2015', 'SBIbank', 1),
(57, 79, 130, 91, 100, '1437988269', 'prashanth', '27/7/2015', 'SBIbank', 1),
(58, 79, 126, 92, 120, '1437988319', 'prashanth', '27/7/2015', 'SBIbank', 1),
(59, 80, 132, 93, 600, '1437988650', 'prashanth', '27/7/2015', 'SBIbank', 1),
(60, 80, 121, 94, 200, '1437988702', 'prashanth', '27/7/2015', 'SBIbank', 1),
(61, 81, 133, 95, 300, '1437988915', 'prashanth', '27/7/2015', 'SBIbank', 1),
(62, 81, 126, 96, 120, '1437988952', 'prashanth', '27/7/2015', 'SBIbank', 1),
(63, 81, 128, 97, 100, '1437988990', 'prashanth', '27/7/2015', 'SBIbank', 1),
(64, 82, 125, 98, 500, '1437989301', 'prashanth', '27/7/2015', 'SBIbank', 1),
(65, 82, 127, 99, 300, '1437989356', 'prashanth', '27/7/2015', 'SBIbank', 1),
(66, 83, 133, 100, 300, '1437991996', 'prashanth', '27/7/2015', 'SBIbank', 1),
(67, 83, 126, 101, 120, '1437992029', 'prashanth', '27/7/2015', 'SBIbank', 1),
(68, 84, 136, 102, 120, '1438061022', 'prashanth', '28/7/2015', 'SBIbank', 1),
(69, 84, 126, 103, 120, '1438061090', 'prashanth', '28/7/2015', 'SBIbank', 1),
(70, 85, 133, 104, 300, '1438061195', 'prashanth', '28/7/2015', 'SBIbank', 1),
(71, 85, 127, 105, 300, '1438061252', 'prashanth', '28/7/2015', 'SBIbank', 1),
(72, 85, 128, 106, 100, '1438061474', 'prashanth', '28/7/2015', 'SBIbank', 1),
(73, 86, 125, 107, 500, '1438061835', 'prashanth', '28/7/2015', 'SBIbank', 1),
(74, 86, 126, 108, 120, '1438061883', 'prashanth', '28/7/2015', 'SBIbank', 1),
(75, 87, 136, 109, 120, '1438063674', 'prashanth', '27/7/2015', 'SBIbank', 1),
(76, 87, 130, 110, 100, '1438063706', 'prashanth', '28/7/2015', 'SBIbank', 1),
(77, 87, 128, 111, 100, '1438063785', 'prashanth', '28/7/2015', 'SBIbank', 1),
(78, 88, 138, 112, 100, '1438151808', 'prashanth', '29/7/2015', 'sbi bank', 1),
(79, 88, 130, 113, 100, '1438151881', 'prashanth', '29/7/2015', 'sbi bank', 1),
(80, 89, 136, 114, 120, '1438152001', 'prashanth', '29/7/2015', 'sbi bank', 1),
(81, 89, 127, 115, 300, '1438152049', 'prashanth', '29/7/2015', 'sbi bank', 1),
(82, 89, 128, 116, 100, '1438152091', 'prashanth', '29/7/2015', 'sbi bank', 1),
(83, 90, 122, 117, 300, '1438152202', 'prashanth', '29/7/2015', 'sbi bank', 1),
(84, 90, 138, 118, 100, '1438152261', 'prashanth', '29/7/2015', 'sbi bank', 1),
(85, 90, 129, 119, 100, '1438152324', 'prashanth', '29/7/2015', 'sbi bank', 1),
(86, 91, 138, 120, 100, '1438152436', 'prashanth', '29/7/2015', 'sbi', 1),
(87, 91, 125, 121, 500, '1438152467', 'prashanth', '29/7/2015', 'sbi', 1),
(88, 92, 136, 122, 120, '1438152600', 'prashanth', '28/7/2015', 'sbi', 1),
(89, 92, 130, 123, 100, '1438152629', 'prashanth', '29/7/2015', 'sbi', 1),
(90, 92, 126, 124, 120, '1438152693', 'prashanth', '29/7/2015', 'sbi', 1),
(91, 93, 138, 125, 100, '1438152800', 'prashanth', '29/7/2015', 'sbi', 1),
(92, 93, 128, 126, 100, '1438152832', 'prashanth', '29/7/2015', 'sbi', 1),
(93, 93, 139, 133, 200, '1438857150', 'prashanth', '6/8/2015', 'SBI bank', 1),
(94, 82, 140, 134, 1200, '1438860042', 'prashanth', '6/8/2015', 'SBI bank', 1),
(95, 74, 140, 135, 1200, '1438860098', 'prashanth', '6/8/2015', 'SBI', 1),
(96, 83, 139, 136, 200, '1438860170', 'prashanth', '6/8/2015', 'SBI', 1),
(97, 75, 140, 137, 1200, '1438860228', 'prashanth', '6/8/2015', 'SBI', 1),
(98, 90, 140, 138, 1200, '1438860279', 'prashanth', '6/8/2015', 'SBI', 1),
(99, 77, 140, 139, 1200, '1438860331', 'prashanth', '6/8/2015', 'SBI', 1),
(100, 77, 140, 139, 1200, '1438860350', 'prashanth', '6/8/2015', 'SBI', 1),
(101, 67, 140, 140, 1200, '1438860395', 'prashanth', '6/8/2015', 'SBI', 1),
(102, 69, 139, 141, 200, '1438860444', 'prashanth', '6/8/2015', 'SBI', 1),
(103, 91, 140, 142, 1200, '1438860499', 'prashanth', '6/8/2015', 'SBI', 1),
(104, 99, 136, 144, 120, '1439675150', 'Claude EDWIGES', '08/15/2015', 'Please would like to pay with Paypal\r\ncould you make it possible. I am living in France', 0),
(105, 99, 136, 144, 120, '1439675150', 'Claude EDWIGES', '08/15/2015', 'Please would like to pay with Paypal\r\ncould you make it possible. I am living in France', 0),
(106, 99, 136, 144, 120, '1439675233', 'Claude EDWIGES', '08/15/2015', 'My email: cedwiges@ifmjob.com', 0),
(107, 94, 136, 145, 120, '1440230796', 'EDWIGES', '08/22/2015', 'Payment by paypal on pay@madhurebba.com \r\nmy paypal account is cedwiges@ifmjob.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `static`
--

CREATE TABLE `static` (
  `ID` bigint(30) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `static`
--

INSERT INTO `static` (`ID`, `title`, `value`) VALUES
(1, 'Terms Of Use', '<p style=\"text-align: justify;\">\r\n	Welcome to GreatFilmJobs.com! GreatFilmJobs.com is a marketplace platform for services performed by its users mainly focused on Film &amp; TV industries. It is important to read the following information if you continue to browse and use this website, especially if you intend to access or buy or sell or rent or hire any service or product.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	If you agree to abide by the Terms and Conditions mentioned along with our General Guidelines and Terms and Conditions then it will help in building a strong relation between the team of GreatFilmJobs and its users.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>By using the Site, opening an account or by clicking to accept or agree to the Terms of Service when this option is made available to you, you accept and agree to be bound and abide by these Terms of Service and our Privacy Policy, found&nbsp;</strong><a href=\"http://www.greatfilmjobs.com/privacy_policy\"><strong>here,</strong></a><strong>&nbsp;incorporated herein by reference.</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	If you do not agree to the terms of this agreement or are not satisfied with the service, you can give us your valuable suggestions in the mail id mentioned in the contact details.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	Please Read Carefully Before Using This Website:</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Madhu Rebba Design, Inc.&nbsp;</strong>maintains this site for information and communication purposes. This webpage contains the Terms of Use governing your access to and use of the www.GreatFilmJobs.com (the &ldquo;Website&rdquo; or &ldquo;Site&rdquo;). If you do not accept these Terms of Use or you do not meet or comply with their provisions, you may not use the Website.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	This Site is offered and available to users who are 18 years of age or older. If you are under 18 you may not use this Site or the GreatFilmJobs services. By using this Site, you represent and warrant that you are of legal age to form a binding contract with the Company and meet all of the foregoing eligibility requirements. If you do not meet all of these requirements, you must not access or use the Site.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>&nbsp; &nbsp; &nbsp; A. TERMS APPLICABLE TO ALL USERS</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Micro Jobs or generally called Gigs</strong>&nbsp;are services offered on GreatFilmJobs.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Micro Jobs</strong>&nbsp;are often referred as&nbsp;<strong>Gigs</strong>&nbsp;on this document</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Sellers</strong>&nbsp;are users who offer and perform services through Gigs on GreatFilmJobs.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Buyers</strong>&nbsp;are users who purchase services on GreatFilmJobs.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Gig Page</strong>&nbsp;is where the seller can describe their Micro Job and the Job&rsquo;s terms, and the buyer can purchase the Gig and create an order.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Gig Extras</strong>&nbsp;are additional services offered on top of the Seller&rsquo;s Micro Job for an additional price defined by the Seller.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Gig Multiples</strong>&nbsp;are additional quantities of unique orders from the seller&rsquo;s Gigs.​</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Custom Offers</strong>&nbsp;are exclusive proposals that a seller can create in response to specific requirements of a buyer.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Custom Orders</strong>&nbsp;are requests made by a buyer to receive a Custom Offer from a seller.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Orders</strong>&nbsp;are the formal agreement between a buyer and seller after a purchase was made from the seller&rsquo;s Gig Page.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Order Page</strong>&nbsp;is where buyers and sellers communicate with each other in connection with an ordered Gig.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Disputes</strong>&nbsp;are disagreements experienced during an order between a buyer and seller on GreatFilmJobs.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Revenues</strong>&nbsp;is the money sellers earn from completed orders.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Available Balance</strong>&nbsp;is cleared revenue from completed orders for sellers to withdraw or use to purchase Gigs.</li>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Shopping Balance</strong>&nbsp;is shopping credit collected from cancelled orders or GreatFilmJobs promotions to be used for purchasing Gigs.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>1. Overview</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	YOUR USE OF THIS WEBSITE IS EXPRESSLY CONDITIONED UPON YOUR ACCEPTING AND AGREEING TO THESE TERMS OF USE.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	For users who are not registered with this Website, your use of the Website will be deemed to be acceptance of the Terms of Use, Section A.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	For users who are registered with the Website, your use of the Website shall be subject to (i) certain designated terms (see Section B below) in addition to those terms applicable to all users and (ii) shall be further conditioned on your [clicking the &quot;I AGREE TO THE TERMS OF USE&quot; button at the end of these Terms of Use].</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	IF THESE TERMS OF USE ARE NOT COMPLETELY ACCEPTABLE TO YOU, YOU MUST IMMEDIATELY TERMINATE YOUR USE OF THIS WEBSITE.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs on GreatFilmJobs may be offered at a base starting price of $3. Some Gigs are offered at a base price of more than $3 as determined by the seller.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Buyers pay GreatFilmJobs in advance to create an order.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Orders are purchased through the Order button found on a seller&rsquo;s Gig page or through a Custom Offer.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers must fulfil their orders, and may not cancel orders on a regular basis or without cause. Cancelling orders will affect sellers&rsquo; reputation and status.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers gain account statuses (Levels) based on their performance and reputation. Advanced levels provide their owners with benefits, including offering services for higher prices through Gig Extras, or selling their Gig in multiples.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Users may not offer or accept payments using any method other than placing an order through GreatFilmJobs.com.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Buyers are granted all rights for the delivered work, unless otherwise specified by the seller on their Gig page. Note: some Gigs charge additional payments (through Gig Extras) for Commercial Use License. See our &ldquo;Ownership&rdquo; and &ldquo;Commercial Use License&rdquo; sections below for more information.</li>\r\n	<li style=\"text-align: justify;\">\r\n		GreatFilmJobs retains the right to use all published delivered works for GreatFilmJobs marketing and promotion purposes.</li>\r\n	<li style=\"text-align: justify;\">\r\n		We care about your privacy. You can read our Privacy Policy&nbsp;<a href=\"http://greatfilmjobs.com/presales/index.php?option=com_k2&amp;view=item&amp;layout=item&amp;id=130&amp;Itemid=521&amp;lang=en\">here</a>. The Privacy Policy is a part of these Terms of Service and incorporated herein by reference.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>SELLERS</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Basics</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers create Gigs on GreatFilmJobs to allow buyers to purchase their services.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers may also offer Custom Offers to buyers in addition to their Gigs.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Each order you sell and successfully complete, accredits your account with a net revenue of 80% of the purchase amount.</li>\r\n	<li style=\"text-align: justify;\">\r\n		GreatFilmJobs accredits sellers once an order is completed. See our&nbsp;&quot;Orders&quot;&nbsp;section below for a definition of a completed order.</li>\r\n	<li style=\"text-align: justify;\">\r\n		If an order is cancelled (for any reason), the funds paid will be refunded to the buyer&rsquo;s Shopping Balance.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Revenues are only made available for withdrawal from the Revenue page following a safety clearance period of 14 days after the order is marked as complete. Top Rated Sellers are eligible to withdraw revenue following a safety clearance period of 7 days after the order is marked as complete.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers may not promote their Gigs or any GreatFilmJobs content via the AdWords platform.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers may withdraw their revenues using one of&nbsp; GreatFilmJobs&rsquo;s withdrawal options.</li>\r\n	<li style=\"text-align: justify;\">\r\n		The seller&#39;s rating is calculated based on the order reviews posted by buyers. High ratings allow sellers to obtain advanced seller levels (see Levels below).</li>\r\n	<li style=\"text-align: justify;\">\r\n		For security concerns, GreatFilmJobs may temporarily disable a seller&rsquo;s ability to withdraw revenue to prevent fraudulent or illicit activity. This may come as a result of security issues, improper behaviour reported by buyers, or associating multiple GreatFilmJobs accounts to a single withdrawal provider.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Gigs</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers are allowed to post a select amount of active Gigs based on their Level status.\r\n		<ul>\r\n			<li>\r\n				30 Gigs for sellers without a Level status.</li>\r\n			<li>\r\n				40 Gigs for Level 1 sellers.</li>\r\n			<li>\r\n				50 Gigs for Level 2 sellers.</li>\r\n			<li>\r\n				60 Gigs for Top Rated sellers.</li>\r\n		</ul>\r\n	</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs created on GreatFilmJobs are&nbsp;User Generated Content.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs may be removed by GreatFilmJobs for violations to these Terms of Service, which may include (but are not limited to) the following violations and/or materials:\r\n		<ul>\r\n			<li>\r\n				Illegal or Fraudulent services</li>\r\n			<li>\r\n				Copyright Infringement, Trademark Infringement, and violation of a third party&#39;s terms of service reported through our Intellectual Property Claims Policy</li>\r\n			<li>\r\n				Adult oriented services, Pornographic, Inappropriate/Obscene</li>\r\n			<li>\r\n				Intentional copies of Gigs</li>\r\n			<li>\r\n				Spam, Nonsense, or Violent Gigs</li>\r\n			<li>\r\n				Gigs misleading to buyers</li>\r\n			<li>\r\n				Reselling of regulated goods</li>\r\n			<li>\r\n				Services that extend beyond 30 days of service duration</li>\r\n		</ul>\r\n	</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs that are removed for violations mentioned above, may result in the suspension of the seller&rsquo;s account.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs that are removed for violations are not eligible to be restored or edited.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs may be removed from our Search feature due to poor performance and/or user misconduct.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs may include pre-approved website URLs contained within the Gigs description and requirements box. Gigs containing websites promoting content, which violates GreatFilmJobs&rsquo; Terms of Service, will be removed.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs are required to have an appropriate Gig image related to the service offered. An option to upload two additional Gig images are available to all sellers.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs may contain an approved Gigs Video uploaded through Youtube.com.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Statements on the Gigs Page that undermine or circumvent these Terms of Service is prohibited.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Eligible Gigs and sellers may price their Gigs at a base price beyond $3.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Gig Extras</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs Extras are additional services offered on top of the Seller&rsquo;s Gig for an additional price defined by the Seller.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gig Extras may be removed for violations of our Terms of Service. For specific terms, please see the Gigs section above for a list of services that violate our Terms of Service. Gigs are subject to be removed due to violations found in Gig Extras.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Services offered through Gig Extras must be related to the base service and part of the deliverables on the order.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gig Extras may cover different categories of services that are components to a higher quality delivered service.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers have the option to extend the duration of an order for each Gigs Extra that is added to the order. This is to cover the time needed to complete the extra service.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Levels</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	GreatFilmJobs is all about helping sellers leverage their skills. We seek to empower top performing sellers with helpful tools to grow their business. Sellers who invest in self-promotion may achieve greater customer satisfaction. And, if they deliver on time and maintain high quality and ratings, GreatFilmJobs may reward them with new statuses, special opportunities, benefits, and tools that come with it.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		GreatFilmJobs sellers can gain account Levels based on their activity, performance and reputation.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Advancement in Levels are updated periodically by an automated system.</li>\r\n	<li style=\"text-align: justify;\">\r\n		The current Levels a seller can achieve are, Level 1, 2, and Top Rated.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers who cannot maintain their high quality service, experience a severe drop in ratings, or stop delivering on time risk losing their seller status and the benefits that come with it. For example, late deliveries, warnings to the seller&rsquo;s account and cancellations can cause a seller to move to a different Level.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Advanced levels provide their owners with additional benefits, including offering Gigs for higher prices through Gig Extras, or selling their Gig in multiples.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Top Rated Sellers</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		Top Rated Sellers are chosen manually by GreatFilmJobs editors based on seniority, volume of sales, extremely high rating, exceptional customer care and community leadership. Top Rated Sellers gain access to more extensive features than previous levels, including exclusive access to beta features and VIP support.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Top Rated eligibility is constantly evaluated by GreatFilmJobs to ensure that the quality standards of the Top Rated selection is kept. Top Rated Sellers who cannot maintain their high quality service through a severe drop in ratings, stop delivering on time, or violate our Terms of Service risk losing their Top Rated status and the benefits that come with it.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Seller Features</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	GreatFilmJobs sellers have access to several exclusive features that help customize the way their services can be offered.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Custom Offer</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers can also send Custom Offers addressing specific requirements of a buyer. Custom Offers are defined by the seller with the exact description of the service, the price and the time expected to deliver the service.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Custom Offers are sent from the conversation page.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>GreatFilmJobs Anywhere</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		GreatFilmJobs Anywhere is a feature that allows sellers to send Custom Offers outside of GreatFilmJobs.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Services offered through GreatFilmJobs Anywhere must comply with our Terms of Service.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Users accessing and purchasing from a GreatFilmJobs Anywhere offer that are not already members of GreatFilmJobs, will be required to register with GreatFilmJobs to create an order.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers are required to deliver proof of completion of services in the order page. Please see our Orders section for further details.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Communication for handling orders should be performed on GreatFilmJobs, through the order page. Users who engage and communicate off of GreatFilmJobs will not be protected by our Terms of Service.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Shipping Physical Deliverables</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	Some of the services on GreatFilmJobs are delivered physically (arts and crafts, collectable items, etc.). For these types of Gigs, sellers may decide to add shipping charges. Sellers can add shipping charges for local shipping (within the same country) and for international shipping (anywhere else).</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs that include shipping costs must have physical deliverables sent to Buyers.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Shipping costs added to a Gigs only pertains to the cost sellers require to ship physical items to Buyers.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Important: Buyers who purchase Gigs that require physical delivery, will be asked to provide a shipping address.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Sellers are responsible for all shipping arrangements once the buyer provides the shipping address.</li>\r\n	<li style=\"text-align: justify;\">\r\n		GreatFilmJobs does not handle or guarantee shipping, tracking, quality, and condition of items or their delivery and shall not be responsible or liable for any damages or other problems resulting from shipping.</li>\r\n	<li style=\"text-align: justify;\">\r\n		A tracking number is a great way to avoid disputes related to shipping. We require entering the tracking number if available in the order page when delivering your work.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Printing Services</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		Some of the services on GreatFilmJobs can be printed and physically delivered (Business Cards, Canvas/Poster Prints, T-Shirts, Flyers, Stationery, etc.).</li>\r\n	<li style=\"text-align: justify;\">\r\n		Important: Buyers who use the Printing Services that require physical delivery, will be asked to provide a shipping address.</li>\r\n	<li style=\"text-align: justify;\">\r\n		For the Printing Services are powered by VistaPrint and subject to&nbsp;<a href=\"http://www.vistaprint.com/customer-care/terms-of-use.aspx\">VistaPrint terms of use</a>, who shall be responsible for packing shipping, tracking, quality, and condition of items or their delivery. GreatFilmJobs does not handle or guarantee shipping, tracking, quality, and condition of items or their delivery and shall not be responsible or liable for any damages or other problems resulting from shipping. Users can contact GreatFilmJobs&rsquo;s customer support department for assistance&nbsp;<a href=\"http://greatfilmjobs.com/presales/index.php?option=com_fss&amp;view=main&amp;Itemid=1447&amp;lang=en\">here</a>.</li>\r\n	<li style=\"text-align: justify;\">\r\n		You can use the Printing Services for delivered work, to which you own all right, title, and interest. Such delivered work must not contain any libellous or otherwise illegal content, and does not actually or potentially infringe or misappropriate the copyright, trademark, or proprietary or intellectual property right of any person. You can report any claims of copyright infringement (DMCA notices) or trademark infringement in accordance with our Intellectual Property claims procedures.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Upon completion of a Printing Order, Buyer will receive a confirmation email containing a Printing Order ID as well as the specific details of the Printing Order.</li>\r\n	<li style=\"text-align: justify;\">\r\n		By using the Printing Services you hereby grant to GreatFilmJobs and VistaPrint, a non-exclusive, worldwide, royalty-free sub-license to edit, modify, adapt, translate, exhibit, publish, transmit, copy, prepare derivative works from, distribute, perform, display and use any delivered work in order to perform the Printing Services.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Users can contact GreatFilmJobs &#39;s customer support department for assistance&nbsp;withdrawal providers.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Revenues are only made available for withdrawal from the Revenue page following a safety clearance period of 14 days after the order is marked as complete. Top Rated Sellers are eligible to withdraw revenue following a safety clearance period of 7 days after the order is marked as complete.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Withdrawals can only be made in the amount available to you.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Withdrawal fees vary depending on the&nbsp;withdrawal provider / method.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	Withdrawals are final and cannot be undone. We will not be able to refund or change this process once it has begun.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Withdrawal Fees</strong><br />\r\n	&nbsp;</p>\r\n<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 500px\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				<strong style=\"text-align: justify;\">PROVIDER</strong></td>\r\n			<td style=\"text-align: center;\">\r\n				<strong style=\"text-align: justify;\">FEE</strong></td>\r\n			<td>\r\n				<strong style=\"text-align: justify;\">SERVICE AVAILABILITY</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				<strong style=\"text-align: justify;\">PayPal</strong></td>\r\n			<td>\r\n				2% of the sum withdrawal amount up to $1</td>\r\n			<td>\r\n				For a list of PayPal services by country&nbsp;<a href=\"http://paypal.com/worldwide\" style=\"text-align: justify;\" target=\"_blank\">click here</a></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	Important notice regarding fees:</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	The fees listed above are PayPal&#39;s. These are not fees charged by GreatFilmJobs.</p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>BUYERS</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Basics</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		You may not offer direct payments to sellers using payment systems outside of the GreatFilmJobs Order system..</li>\r\n	<li style=\"text-align: justify;\">\r\n		GreatFilmJobs retains the right to use all publically published delivered works for GreatFilmJobs marketing and promotional purposes.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Buyers may request a specific service from the Post a Request feature found from the Shopping dashboard. Services requested on GreatFilmJobs must be an allowed service on GreatFilmJobs.</li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Purchasing</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		Buyers pay GreatFilmJobs to create an order from a seller&rsquo;s Gigs page or Custom Offer, using the Order Now button.</li>\r\n	<li style=\"text-align: justify;\">\r\n		In addition buyers can request a Custom Order which addresses specific buyer requirements, and receive a Custom Offer from sellers through the site or through GreatFilmJobs Anywhere.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Gigs may be purchased using one of the following payment methods: Credit Card, PayPal or GreatFilmJobs Credit.</li>\r\n	<li style=\"text-align: justify;\">\r\n		Processing fees are added at the time of purchase where a buyer can review and accept the total amount requested to pay. These fees cover payment processing and administrative fees. As of September 2016, the current fees assessed to the total purchase amount are $1. When purchasing from your seller&#39;s balance (i.e. out of your earned revenues) or buyer&#39;s shopping balance (resulting from any credits or refunds) you will not be charged a processing fee. Funds returned to your balance from cancelled orders will not include processing fees paid.</li>\r\n	<li style=\"text-align: justify;\">\r\n		If you have funds in your account balance, either from your Shopping or available Revenue balance, it will be automatically applied to your next purchase, but only in the event that your balance covers the entire purchase amount.</li>\r\n	<li style=\"text-align: justify;\">\r\n		You may not offer sellers to pay, or make payment using any method other than through the GreatFilmJobs.com site. In case you have been asked to use an alternative payment method, please report it immediately to Cus');
INSERT INTO `static` (`ID`, `title`, `value`) VALUES
(2, 'Privacy Policy | Copyright Info', '<p style=\"text-align: center;\">\r\n	<strong>www.GreatFilmJobs.com</strong><br />\r\n	Effective and Last Updated: 5th&nbsp;September 2016&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	This website is owned and operated by&nbsp;<strong>Madhu Rebba Design, Inc.&nbsp;</strong>&nbsp;We are committed to protecting the privacy of our users- buyers, sellers and visitors (&ldquo;Users&rdquo;) while they interact with the content, products and services on this site, http://www.GreatFilmJobs.com (the &ldquo;Site&rdquo;).&nbsp; This Privacy Policy applies to the Site only. It does not apply to other websites to which we link.&nbsp; Because we gather certain types of information about our users, we want you to understand what information we collect about you, how we collect it, how that information is used, and how you can control our disclosure of it. By accessing and/or using the Site and its related sites, applications, services, goods and/or registering for a GreatFilmJobs account, you consent to the terms and conditions of this privacy policy, including to our collection, use, disclosure, processing and retention of your personal information. You can also learn how to limit sharing of information in this policy. You agree that your use of the Site signifies your assent to this Privacy Policy. If you do not agree with this Privacy Policy, please do not use the Site.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>1)&nbsp; Information Collected</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	We collect two types of information from you: i) information that you voluntarily provide to us (e.g. through a voluntary registration process, sign-ups or emails); and ii) information that is derived through automated tracking mechanisms.</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Voluntary Registration Information.</strong></li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	In order to fully access this Site, you must first complete the registration process, during which we will collect personal information about you. The information will include your name, address, phone number, location, user name, education, qualification, Paypal or Alertpay or payza username, Payout details or Bank details, date of birth&nbsp;&nbsp; and email address. We do not collect personally identifiable information about you except when you specifically provide such information to us on a voluntary basis.&nbsp;&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	By registering with us, you consent to the use and method of disclosure as described in this Privacy Policy.</p>\r\n<p style=\"text-align: justify;\">\r\n	Once you register, your username and additional information regarding your activity is made public and is visible to all Users of the Site. This information includes photos you upload, your published portfolio, Gig information, ratings, and additional information you may choose to add to your profile.</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Voluntary Information for Services and Features</strong></li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	We also collect personally identifiable information when you choose to use certain other features of the Site, including:&nbsp;i) making purchases, ii) consenting to receive email or text messages about upcoming promotions or events, iii) consenting to receive email, iv) participating in our forum, iv) commenting on articles, and others. When you choose to use these additional features, we require you to provide your &ldquo;Contact Information&rdquo; in addition to other personal information that may be required to complete a transaction such as your phone number, billing and shipping addresses and credit card information.&nbsp; Occasionally, we may also request information such as your shopping preferences and demographics which will help us better serve you and our others users in the future.</p>\r\n<ul>\r\n	<li style=\"text-align: justify;\">\r\n		<strong>Cookies</strong></li>\r\n</ul>\r\n<p style=\"text-align: justify;\">\r\n	Our site uses &quot;cookies&quot; and other tracking technologies.&nbsp; Cookies enable us to serve secure pages to our users without asking them to sign in repeatedly.&nbsp; Most browsers allow you to control cookies, including whether or not to accept them and how to remove them. If a user&#39;s system is idle for a defined time, the cookie will expire, forcing the user to sign in again to continue their session. This prevents unauthorised access to the user&#39;s information while they are away from their computer.</p>\r\n<p style=\"text-align: justify;\">\r\n	You may set most browsers to notify you if you receive a cookie, or you may choose to block cookies with your browser, but please note that if you choose to erase or block your cookies, you will need to re-enter your original user ID and password to gain access to certain parts of the Site.</p>\r\n<p style=\"text-align: justify;\">\r\n	Third-Party Cookies:&nbsp; In the course of serving advertisements to this site, our third-party advertisers may place or recognise a unique &quot;cookie&quot; on your browser.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>2)&nbsp; Referrals</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	You may choose to invite friends to join the&nbsp;<strong>www.GreatFilmJobs.com&nbsp;</strong>by sending invitation emails via our invite feature.<strong>www.GreatFilmJobs.com&nbsp;</strong>stores the email addresses you provide so that the respondents may be added to your social network, confirm orders/purchases and also to send reminders of the invitations.&nbsp;<strong>www.GreatFilmJobs.com&nbsp;</strong>does not sell these email addresses or use them to send any other communication besides invitations and invitation reminders. Recipients of invitations may contact&nbsp;<strong>www.GreatFilmJobs.com&nbsp;</strong>to request removal of their information from our database. &nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>3)&nbsp; How We Use Your Information</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>www.GreatFilmJobs.com&nbsp;</strong>only uses your personal information for the original purposes it was given. Your personal information will not be sold or otherwise transferred to unaffiliated third parties without your approval at the time of collection.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>www.GreatFilmJobs.com&nbsp;</strong>will not disclose, use, give or sell any personal information to third parties for any purposes other than to our suppliers and other third parties who need to know in order to deliver services on behalf of&nbsp;<strong>www.GreatFilmJobs.com&nbsp;</strong>unless required to do so by law. Further,&nbsp;<strong>www.GreatFilmJobs.com&nbsp;</strong>reserves the right to contact you regarding matters relevant to the underlying service provided and/or the information collected.</p>\r\n<p style=\"text-align: justify;\">\r\n	Please note that personally identifiable information is used only to provide you with a more enjoyable, convenient online experience and to help us identify and/or provide information, products or services that may be of interest to you. We use your personally identifiable information to support and enhance your use of the Site and its features, including without limitation: set up your account, verify or re-issue a password, log your activity and contact you from time to time fulfilling your order; providing customer service; tracking email invitations you send; and otherwise supporting your use of the Site. The information helps us improve our services to you, customize your browsing experience and inform you about additional products, services or promotions from GreatFilmJobs that may be of interest to you. In addition, this information helps us track any fraudulent activities and other inappropriate activities and monitor content integrity. Should you ever deactivate your account with us, we will keep your information on file, but only use it to comply with regulatory requirements</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>www.GreatFilmJobs.com&nbsp;</strong>may use your personal information for target advertising toward you based on things such as region, gender, interests, goals, habits, etc.</p>\r\n<p style=\"text-align: justify;\">\r\n	We may permit certain trusted third parties to track usage, analyse data such as the source address that a page request is coming from, your IP address or domain name, the date and time of the page request, the referring Web site (if any) and other parameters in the URL. This is collected in order to better understand our Web site usage, and enhance the performance of services to maintain and operate the Site and certain features on the Site. We may use third parties to host the Site; operate various features available on the Site; send emails; analyse data; provide search results and links and assist in fulfilling your orders.</p>\r\n<p style=\"text-align: justify;\">\r\n	Also, we may share personally identifiable or other information with our parent, subsidiaries, divisions, and affiliates.</p>\r\n<p style=\"text-align: justify;\">\r\n	We may transfer personally identifiable information as an asset in connection with a proposed or actual merger or sale (including any transfers made as part of an insolvency or bankruptcy proceeding) involving all or part of our business or as part of a corporate reorganisation, stock sale or other change in control.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>www.GreatFilmJobs.com&nbsp;</strong>may disclose Contact Information in special cases where we have reason to believe that disclosing this information is necessary to identify, contact or bring legal action against someone who may be violating our terms and conditions of use or may be causing injury or interference with our rights, property, our customers or anyone who could be harmed by such activities.</p>\r\n<p style=\"text-align: justify;\">\r\n	We may combine your personal information with information we collect automatically or obtain from other companies and use it to improve and personalize our services, content and advertising. If you do not wish to receive marketing communications from us, you can opt-out through the link attached to each communication or by sending an email to&nbsp;<span id=\"cloak96943\"><a href=\"mailto:info@GreatFilmJobs.com\">info@GreatFilmJobs.com</a></span>.</p>\r\n<p style=\"text-align: justify;\">\r\n	WE ARE NOT LIABLE OR RESPONSIBLE FOR THE PERSONALLY IDENTIFIABLE OR OTHER INFORMATION YOU CHOOSE TO SUBMIT IN FORUMS SUCH AS A BULLETIN BOARD, CHAT ROOM OR ANY OTHER PUBLICLY ACCESSIBLE AREA OF THE SITE.</p>\r\n<p style=\"text-align: justify;\">\r\n	You will receive notice when your personally identifiable information might be provided to any third party for any reason other than as set forth in this Privacy Policy, and you will have an opportunity to request that we not share such information.</p>\r\n<p style=\"text-align: justify;\">\r\n	We use non-identifying and aggregate information to better design our website and for business and administrative purposes. We may also use or share with third parties for any purpose aggregated data that contains no personally identifiable information.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>4) How We Protect Your Information</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	We are committed to protecting the information we receive from you. We take appropriate security measures to protect your information against unauthorised access to or unauthorised alteration, disclosure or destruction of data. To prevent unauthorised access, maintain data accuracy, and ensure the correct use of information, we maintain appropriate physical, electronic, and managerial procedures to safeguard and secure the information and data stored on our system. While no computer system is completely secure, we believe the measures we have implemented reduce the likelihood of security problems to a level appropriate to the type of data involved.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>5) Third Party Advertising</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	Advertisements appearing on this Site may be delivered to you by&nbsp;<strong>www.GreatFilmJobs.com&nbsp;</strong>or one of our Web advertising partners. Our Web advertising partners may set cookies. Doing this allows the advertising partners to recognise your computer each time they send you an advertisement. In this way, they may compile information about where you, or others who are using your computer, saw their advertisements and determine which advertisements are clicked. This information allows an advertising partner to deliver targeted advertisements that they believe will be of most interest to you.&nbsp;<strong>www.GreatFilmJobs.com&nbsp;</strong>does not have access to or control of the cookies that may be placed by the third party advertising servers of ad partners.&nbsp;&nbsp;&nbsp;<br />\r\n	<br />\r\n	This privacy statement covers the use of cookies by&nbsp;<strong>www.GreatFilmJobs.com&nbsp;</strong>and does not cover the use of cookies by any of its advertisers. &nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>6)&nbsp; Accessing and Updating Your Personal Information and Preferences</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	For members with user accounts:&nbsp;We provide mechanisms for updating and correcting your personal information for many of our services.&nbsp; You may modify or remove any of your personal information at any time by logging into your account and accessing features such as edit and account. &nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	For members without user accounts:&nbsp;We provide mechanisms for updating and correcting your personal information for many of our services.&nbsp; If you are a registered user, you may access and update your registration information and your preferences to receive email or other communications from us by sending an email to&nbsp;info(a)GreatFilmJobs.com.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>7)&nbsp; Email Choice/Opt-out</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	For members with user accounts:&nbsp;If you no longer wish to receive updates or notifications may opt-out of receiving these communications by changing your &ldquo;email notification&rdquo; settings in your &ldquo;account settings.&rdquo; &nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	For members without user accounts:&nbsp;If any user who receives an email from the Site and would prefer not to receive such communications in the future, [he or she] can do so by following the instructions in the emails.&nbsp; In addition, you may send an email to&nbsp;info(a)GreatFilmJobs.com. We will make commercially reasonable efforts to implement your opt-out requests promptly, but you may still receive communications from us for up to ten business days as we process your request.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>8) Children&#39;s Privacy and Parental Controls</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	We do solicit personal information from children of the age group 15 and above. If you are not 15 or older, you are not authorised to use the Site. Parents should be aware that there are parental control tools available online that can be used to prevent children from submitting information online without parental permission or from accessing material that is harmful to minors.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>9) Disclaimer to Security</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	By consenting to the Terms and Conditions of the Site and hence the Privacy Policy, you consent that no data transmission over the Internet is completely secure. We cannot guarantee or warrant the security of any information you provide to us and you transmit such information to us at your own risk.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>10) Notification of Changes</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>www.GreatFilmJobs.com&nbsp;</strong>reserves the right to change this Privacy Policy from time to time at its sole discretion. If at some point in the future, there is a change to our Privacy Policy, unless we obtain your express consent, such change will only apply to information collected after the revised Privacy Policy took effect. Your continued use of the Site indicates your assent to the Privacy Policy as posted.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>11) Enforcement&nbsp;</strong>- We constantly update our compliance with our Privacy Policy. We also adhere to several self-regulatory frameworks. Whenever there are complaints, we will contact the concerned person who made the complaint to follow up. Appropriate regulatory authorities and action is taken as needed.</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>12)&nbsp; CONTACT INFORMATION:</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	If you have any questions or concerns regarding this Privacy Policy please contact:</p>\r\n<p style=\"text-align: justify;\">\r\n	Madhu Rebba Design, Inc.,<br />\r\n	4270 Vineyard Cir, Weston,<br />\r\n	Florida, 33332, USA<br />\r\n	<strong>email: info(a)Greatfilmjobs.com</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>COPYRIGHT INFO</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	All rights are reserved</p>\r\n<p style=\"text-align: justify;\">\r\n	No part of this website may be reproduced in any form, by electronic or any other means, without written permission from GreatFilmJobs.com</p>\r\n<p style=\"text-align: justify;\">\r\n	GreatFilmJobs.com is owned by Madhu Rebba Design, Inc.</p>\r\n<p style=\"text-align: justify;\">\r\n	All products, partner logos and company names mentioned here are registered trademarks of their respective owners</p>\r\n<p style=\"text-align: justify;\">\r\n	<strong>Terms of Use</strong></p>\r\n<p style=\"text-align: justify;\">\r\n	This site content is provided by GreatFilmJobs.com and it&rsquo;s users, and should be used for informational purposes only. By using the site or downloading materials from the site, you agree to abide by the terms and conditions. If you do not agree to abide by the rules and regulations then it&rsquo;s a request not to download any material from the site.</p>\r\n<p style=\"text-align: justify;\">\r\n	In anyway, you agree not to</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; Interrupt or attempt to interrupt the operation of the site</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; Intrude or attempt to intrude</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; Post any obscene, defamatory or annoying materials</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; Obscure any materials, including this notice, already posted on the site</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; Use the site or any contents thereof to defame, breach the rights of any person, intimidate, annoy or otherwise cause nuisance</p>\r\n<p style=\"text-align: justify;\">\r\n	Any such activity will lead to cancellation of membership(s) and concerned authorities will be notified accordingly.</p>\r\n<p style=\"text-align: justify;\">\r\n	GreatFilmJobs.com authorizes to view and download the information (&quot;Materials&quot;) at this Web site (&quot;Site&quot;) only for personal and non-commercial use.</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; You agree to abide by all additional restrictions displayed on the Site</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; The content keeps on changing from time to time. Please keep visiting the site as frequently as possible in order to keep yourself updated</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; This Site, including all Materials, is a copyright and protected by worldwide copyright laws and treaty provisions. You agree to comply by all copyright laws worldwide in your use of this Site and to prevent any unauthorized copying of the Materials</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; GreatFilmJobs.com does not grant any implied right to you under any patents, trademarks, copyrights. You can reach out to us for more information.</p>\r\n<p style=\"text-align: justify;\">\r\n	&middot; &nbsp; &nbsp; &nbsp; &nbsp; The information and material in this site may include inaccuracies or typographical errors. Changes are periodically made to the site/services and to the information therein. GreatFilmJobs.com may make improvements and/or changes in the site/services at any time.</p>\r\n<p style=\"text-align: justify;\">\r\n	You specifically agree that GreatFilmJobs.com is not responsible or liable for any threatening, defamatory, obscene, offensive or illegal content or conduct of any other party or any infringement of another&#39;s rights, including intellectual property rights. You specifically agree that GreatFilmJobs.com is not responsible for any content sent using and/or included in this site by any third party.</p>\r\n<p style=\"text-align: justify;\">\r\n	GreatFilmJobs.com will not be liable for any direct, indirect, punitive, incidental, special, consequential damages or any damages &nbsp;including, without limitation, damages for loss of use, data or profits, arising out of or in any way connected with the use or performance of this site/services, with the delay or inability to use this site/services or related services, the provision of or failure to provide services, or for any information, products, services and material obtained through this site, or otherwise arising out of the use of this site/services, whether based on contract, tort, negligence, strict liability or otherwise, even if GreatFilmJobs.com has been advised of the possibility of damages. If you are dissatisfied with any portion of this site/services, or with any of these terms of use, your valuable advises and suggestions are always welcome.</p>\r\n<p style=\"text-align: justify;\">\r\n	The content is subject to the laws of the Republic of India and the court of Secunderabad, India shall have the exclusive jurisdiction on any dispute that may arise out of the use of this site.</p>\r\n<p style=\"text-align: justify;\">\r\n	Please proceed only if you accept all the conditions enumerated herein above, out of your will and consent.</p>\r\n'),
(3, 'About Us', '<p style=\"margin: 0cm 0cm 7.5pt; color: rgb(106, 106, 106); font-family: Arial, Helvetica, sans-serif; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-align: justify;\">\r\n	<span style=\"font-size: 10.5pt; font-family: Arial, sans-serif;\">Our founding team of Art Directors, Production Designers and Engineers created GreatFilmJobs in the year 2015. We had started serving the Film industry since two decades, when technologies were primitive.&nbsp;Through this journey of Art Direction &amp; Production Design we had to do many jobs such as erecting micro to large sets for Feature films, making sculptures, building TV Studios, Talk show mini sets &amp; Reality show grand sets, Hydraulic sets, Graphics etc. There were also many micro jobs involved in this field such as picking up good locations, accounting, making a short personalized animation video, getting hand- made props ready for the shoot etc, consuming time, efforts, man power and turns to be expensive.</span></p>\r\n<p style=\"margin: 0px 0px 10px; color: rgb(106, 106, 106); font-family: Arial, Helvetica, sans-serif; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-align: justify;\">\r\n	<span style=\"font-size: 10.5pt; font-family: Arial, sans-serif;\">&nbsp;Art Direction / Production Design needs a lot of expertise in almost all the fields in that we come across in our daily life. In fact, we couldn&rsquo;t imagine the heights of requirements movie making has in the fields other than Art Direction, like digital works, software, training, after effects, sound, photography etc. In reality movie making is all about artificial creation of realistic world on screen. Eventually, we took our necessity as a challenge and added to our interest in the web, we created GreatFilmJobs.com, a portal mainly dedicated to the Global Feature Film &amp; TV Industries, a world within.</span></p>\r\n<p style=\"margin: 0cm 0cm 7.5pt; color: rgb(106, 106, 106); font-family: Arial, Helvetica, sans-serif; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-align: justify;\">\r\n	<span style=\"font-size: 10.5pt; font-family: Arial, sans-serif;\">Our goal is to save time, money and efforts of art directors, artists, architects, game developers, visual effects studios, TV studios, Film production houses and creative professionals around the world and instead let them add their own personality to their creations by selling services in GreatFilmJobs.com, which can be a lifesaver in a time crunch!</span></p>\r\n<p style=\"margin: 0cm 0cm 7.5pt; color: rgb(106, 106, 106); font-family: Arial, Helvetica, sans-serif; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-align: justify;\">\r\n	<span style=\"font-size: 10.5pt; font-family: Arial, sans-serif;\">GreatFilmJobs is our first trial of serving the industry to a larger extent. This is a platform built by suggestions that our users want and need, where the talented can buy and sell services- A new way to freelance. A one stop shop for Films- making- short films &amp; feature films. This way, GreatFilmJobs is inclined to serve all. Although GreatFilmJobs is specifically started to serve the film industry. We tried and are still trying to add as many services as possible to meet the requirements. The services or the micro jobs that are available are going to be numerous and simple that a common man also can buy these services from the portal.</span></p>\r\n<p style=\"margin: 0cm 0cm 7.5pt; color: rgb(106, 106, 106); font-family: Arial, Helvetica, sans-serif; font-size: 14px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-align: justify;\">\r\n	<span style=\"font-size: 10.5pt; font-family: Arial, sans-serif;\">Our mission is the same as it was when we started: To provide the Film &amp; TV Industry the services required for filming and also a chance to many talented artists a chance of freelancing, a chance to make a living and a chance to serve &amp; join Film industry.</span></p>\r\n'),
(4, 'Featured', '<p>\r\n	Any Gig can be featured for 30 days on Home page for $10.</p>\r\n'),
(5, 'Contact Us', '<p>\r\n	<a href=\"http://greatfilmjobs.com/support/index.php?option=com_contact&amp;view=contact&amp;id=1&amp;Itemid=1192&amp;lang=en\">Click here to Contact us</a></p>\r\n'),
(6, 'Job Levels', '<p>\r\n	3 Job Levels</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `wants`
--

CREATE TABLE `wants` (
  `WID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `want` text NOT NULL,
  `category` bigint(20) NOT NULL DEFAULT '0',
  `time_added` varchar(20) DEFAULT NULL,
  `date_added` date NOT NULL DEFAULT '0000-00-00',
  `active` char(1) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_requests`
--

CREATE TABLE `withdraw_requests` (
  `WID` bigint(20) NOT NULL,
  `USERID` bigint(20) NOT NULL DEFAULT '0',
  `time_added` varchar(20) DEFAULT NULL,
  `ap` bigint(1) NOT NULL DEFAULT '0',
  `bank` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrators`
--
ALTER TABLE `administrators`
  ADD PRIMARY KEY (`ADMINID`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `advertisements`
--
ALTER TABLE `advertisements`
  ADD PRIMARY KEY (`AID`);

--
-- Indexes for table `archive`
--
ALTER TABLE `archive`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `USERID` (`USERID`,`AID`);

--
-- Indexes for table `bans_ips`
--
ALTER TABLE `bans_ips`
  ADD UNIQUE KEY `ip` (`ip`);

--
-- Indexes for table `bans_words`
--
ALTER TABLE `bans_words`
  ADD UNIQUE KEY `word` (`word`);

--
-- Indexes for table `bookmarks`
--
ALTER TABLE `bookmarks`
  ADD PRIMARY KEY (`BID`),
  ADD UNIQUE KEY `USERID` (`USERID`,`PID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`CATID`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `extras`
--
ALTER TABLE `extras`
  ADD PRIMARY KEY (`EID`);

--
-- Indexes for table `featured`
--
ALTER TABLE `featured`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`FID`);

--
-- Indexes for table `fiverrscript_dotcom_notity`
--
ALTER TABLE `fiverrscript_dotcom_notity`
  ADD PRIMARY KEY (`NID`);

--
-- Indexes for table `inbox`
--
ALTER TABLE `inbox`
  ADD PRIMARY KEY (`MID`);

--
-- Indexes for table `inbox2`
--
ALTER TABLE `inbox2`
  ADD PRIMARY KEY (`MID`);

--
-- Indexes for table `inbox_reports`
--
ALTER TABLE `inbox_reports`
  ADD PRIMARY KEY (`RID`),
  ADD UNIQUE KEY `MID` (`MID`,`USERID`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`USERID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `members_passcode`
--
ALTER TABLE `members_passcode`
  ADD PRIMARY KEY (`USERID`);

--
-- Indexes for table `members_verifycode`
--
ALTER TABLE `members_verifycode`
  ADD PRIMARY KEY (`USERID`);

--
-- Indexes for table `offerscriptolution`
--
ALTER TABLE `offerscriptolution`
  ADD PRIMARY KEY (`SCRIPTOLUTIONOFID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OID`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`IID`);

--
-- Indexes for table `packs`
--
ALTER TABLE `packs`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `paypal_table`
--
ALTER TABLE `paypal_table`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `txn_id` (`txn_id`),
  ADD KEY `txn_id_2` (`txn_id`);

--
-- Indexes for table `paypal_table2`
--
ALTER TABLE `paypal_table2`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `txn_id` (`txn_id`),
  ADD KEY `txn_id_2` (`txn_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`PID`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`RID`);

--
-- Indexes for table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`RID`);

--
-- Indexes for table `scriptolutionrequests`
--
ALTER TABLE `scriptolutionrequests`
  ADD PRIMARY KEY (`REQUESTID`);

--
-- Indexes for table `scriptolution_launch`
--
ALTER TABLE `scriptolution_launch`
  ADD PRIMARY KEY (`LID`),
  ADD UNIQUE KEY `scriptolutionemail` (`scriptolutionemail`);

--
-- Indexes for table `scriptolution_local`
--
ALTER TABLE `scriptolution_local`
  ADD PRIMARY KEY (`BID`);

--
-- Indexes for table `static`
--
ALTER TABLE `static`
  ADD PRIMARY KEY (`ID`);
ALTER TABLE `static` ADD FULLTEXT KEY `value` (`value`);

--
-- Indexes for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  ADD PRIMARY KEY (`WID`),
  ADD UNIQUE KEY `USERID` (`USERID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrators`
--
ALTER TABLE `administrators`
  MODIFY `ADMINID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `advertisements`
--
ALTER TABLE `advertisements`
  MODIFY `AID` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `archive`
--
ALTER TABLE `archive`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bookmarks`
--
ALTER TABLE `bookmarks`
  MODIFY `BID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `CATID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=220;

--
-- AUTO_INCREMENT for table `extras`
--
ALTER TABLE `extras`
  MODIFY `EID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213;

--
-- AUTO_INCREMENT for table `featured`
--
ALTER TABLE `featured`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `FID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1094;

--
-- AUTO_INCREMENT for table `fiverrscript_dotcom_notity`
--
ALTER TABLE `fiverrscript_dotcom_notity`
  MODIFY `NID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=348;

--
-- AUTO_INCREMENT for table `inbox`
--
ALTER TABLE `inbox`
  MODIFY `MID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `inbox2`
--
ALTER TABLE `inbox2`
  MODIFY `MID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `inbox_reports`
--
ALTER TABLE `inbox_reports`
  MODIFY `RID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `USERID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=695;

--
-- AUTO_INCREMENT for table `offerscriptolution`
--
ALTER TABLE `offerscriptolution`
  MODIFY `SCRIPTOLUTIONOFID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `IID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=267;

--
-- AUTO_INCREMENT for table `packs`
--
ALTER TABLE `packs`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `paypal_table`
--
ALTER TABLE `paypal_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `paypal_table2`
--
ALTER TABLE `paypal_table2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `PID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2919;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `RID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `RID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scriptolutionrequests`
--
ALTER TABLE `scriptolutionrequests`
  MODIFY `REQUESTID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scriptolution_launch`
--
ALTER TABLE `scriptolution_launch`
  MODIFY `LID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scriptolution_local`
--
ALTER TABLE `scriptolution_local`
  MODIFY `BID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `static`
--
ALTER TABLE `static`
  MODIFY `ID` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  MODIFY `WID` bigint(20) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
